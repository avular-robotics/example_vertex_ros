// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 August 20
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the base64 encoding and decoding.
 ****************************************************************************/
#pragma once

#include <creos/utils_global.hpp>
#include <cstddef>
#include <cstdint>
#include <span>
#include <string>
#include <vector>

namespace creos {

/**
 * @brief Encodes data to base64.
 *
 * @param data The data to encode.
 * @return std::string The base64 encoded data.
 */
std::string CREOS_UTILS_API base64_encode(const std::span<const std::byte>& data);

inline std::string CREOS_UTILS_API base64_encode(const std::span<const uint8_t>& data) {
    return base64_encode(std::span(reinterpret_cast<const std::byte*>(data.data()), data.size()));
}

/**
 * @brief Decodes base64 encoded data.
 *
 * @param data The base64 encoded data.
 * @return std::vector<std::byte> The decoded data.
 */
std::vector<std::byte> CREOS_UTILS_API base64_decode(const std::string_view& data);

}  // namespace creos
