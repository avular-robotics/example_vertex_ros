// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 August 20
 * Author: Robbert-Jan de Jager
 *
 * Helper tools for working with URLs.
 ****************************************************************************/
#pragma once

#include <creos/utils_global.hpp>
#include <string>
#include <string_view>
#include <unordered_map>

namespace creos {

/**
 * @brief Encodes a string to be used in a URL.
 *
 * @param value The string to encode.
 * @return std::string The encoded string.
 */
std::string CREOS_UTILS_API url_encode(const std::string_view& value);

/**
 * @brief Decodes a string from a URL.
 *
 * @param value The string to decode.
 * @return std::string The decoded string.
 */
std::string CREOS_UTILS_API url_decode(const std::string_view& value);

/**
 * @brief Creates a query string from a map of parameters.
 *
 * @param parameters The map of parameters.
 * @return std::string The query string.
 */
std::string CREOS_UTILS_API create_query(const std::unordered_map<std::string, std::string>& parameters);

/**
 * @brief Parses a query string into a map of parameters.
 *
 * @param query The query string.
 * @return std::unordered_map<std::string, std::string> The map of parameters.
 */
std::unordered_map<std::string, std::string> CREOS_UTILS_API parse_query(const std::string_view& query);

}  // namespace creos
