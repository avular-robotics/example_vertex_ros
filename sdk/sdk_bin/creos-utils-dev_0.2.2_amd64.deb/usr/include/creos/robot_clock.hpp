// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 30
 * Author: Robbert-Jan de Jager
 *
 * Definition of the Robot Clock. The robot clock is a standard c++ clock
 * object used to represent robot time. In normal operation it will behave
 * identical to std::chrono::system_clock, but in simulation it will contain
 * simulation time.
 ****************************************************************************/
#pragma once

#include <chrono>
#include <creos/utils_global.hpp>
#include <cstdint>
#include <nlohmann/json.hpp>

namespace creos {

/**
 * @brief The clock that represents the robot time.
 *
 * The robot clock is a representation of the time source of the time on the robot.
 * In normal operation it behaves identically to std::chrono::system_clock, while
 * in simulation it will return the simulated time.
 */
class CREOS_UTILS_API RobotClock {
public:
    using duration = typename std::chrono::nanoseconds;
    using rep = typename duration::rep;
    using period = typename duration::period;
    using time_point = typename std::chrono::time_point<RobotClock, duration>;

    static_assert(duration::min() < duration::zero(), "a clock's minimum duration cannot be less than its epoch");

    static constexpr bool is_steady = false;

    /**
     * @brief Construct a time_point from a time_t
     */
    static time_point from_time_t(std::time_t t) noexcept;

    /**
     * @brief Return the current time
     */
    static time_point now() noexcept;
};

inline void to_json(nlohmann::json& j, const RobotClock::time_point& p) {
    j = nlohmann::json(p.time_since_epoch().count());
}

inline void from_json(const nlohmann::json& j, RobotClock::time_point& p) {
    p = RobotClock::time_point(RobotClock::duration(j.get<RobotClock::rep>()));
}

static_assert(std::chrono::is_clock_v<RobotClock>);

}  // namespace creos
