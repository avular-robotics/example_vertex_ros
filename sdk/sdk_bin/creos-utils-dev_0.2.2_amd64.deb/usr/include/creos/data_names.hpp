// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 November 08
 * Author: Robbert-Jan de Jager
 *
 * Implementation of helper methods to create names for data sources/sinks.
 ****************************************************************************/
#pragma once

#include <creos/enum.hpp>
#include <string>
#include <string_view>

namespace creos {

/**
 * @brief Get the name of a named data source.
 *
 * Example:
 * @code
 * enum class Lidar3dId { kFront };
 * auto name = getNamedDataSourceName("interface", kFront);
 * // name = "interface/front"
 * @endcode
 *
 * @tparam T The type of the name.
 * @param data_source The name of the data source.
 * @param name The identifier of the specific data source.
 */
template <typename T>
inline std::string getNamedDataSourceName(const std::string_view& data_source, const T& name) {
    std::string data_source_str{data_source};
    data_source_str.push_back('/');
    data_source_str.append(creos::to_string(name));
    return data_source_str;
}
}  // namespace creos
