// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 3
 * Author: Niels Rood
 *
 * @file DataKind declarations shared between the Agent and the Client.
 ****************************************************************************/
#pragma once

#include <cstdint>
#include <nlohmann/json.hpp>
#include <string>

namespace creos {

/**
 * @brief The kind of data that is published or subscribed to.
 * The data kind is used to determine how the data is handled.
 * For example, sensor data may be dropped as having the latest data is more
 * important than having all the data.
 */
enum class DataKind {
    kUnknown,         ///< Unknown data kind.
    kHighRateSensor,  ///< High rate (> 100Hz) sensor data.
    kLowRateSensor,   ///< Low rate (< 100Hz) sensor data.
    kEvent,           ///< Event data.
    kControlData,     ///< Data for real-time control.
    kRequest,         ///< Data for a request.
    kResponse,        ///< Data for a response.
    kStateData,       ///< Data that represents the state of the system.
};

NLOHMANN_JSON_SERIALIZE_ENUM(DataKind, {
                                           {DataKind::kUnknown, "Unknown"},
                                           {DataKind::kHighRateSensor, "HighRateSensor"},
                                           {DataKind::kLowRateSensor, "LowRateSensor"},
                                           {DataKind::kEvent, "Event"},
                                           {DataKind::kControlData, "ControlData"},
                                           {DataKind::kRequest, "Request"},
                                           {DataKind::kResponse, "Response"},
                                           {DataKind::kStateData, "StateData"},
                                       })

}  // namespace creos
