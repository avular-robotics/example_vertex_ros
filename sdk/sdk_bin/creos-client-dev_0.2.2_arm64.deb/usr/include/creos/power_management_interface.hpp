// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 23
 * Author: Bram Tertoolen
 *
 * Header file for power management interface
 ****************************************************************************/
#pragma once

#include <creos/client_global.hpp>
#include <creos/messages/enter_low_power_mode.hpp>
#include <creos/messages/interface_info.hpp>
#include <creos/robot_clock.hpp>

namespace creos {

/**
 * @brief The interface for querying and managing the power state of an Avular robot.
 */
class CREOS_CLIENT_API IPowerManagementInterface {
public:
    static constexpr char name[] = "power_management";
    static constexpr unsigned version = 1;

    virtual ~IPowerManagementInterface() = default;

    /**
     * @brief Enter low power mode.
     * @qualifier Origin
     *
     * This function will put the robot in a low power mode.
     *
     * @param timeout_ms The time in milliseconds to wait for the robot to enter low power mode.
     * @throws creos::TimeoutError if the robot does not enter low power mode within the timeout.
     * @throws creos::UnsupportedError if the robot does not support entering low power mode.
     * @throws creos::Exception if any error occurred while sending the command.
     */
    virtual void enterLowPowerMode(int timeout_ms = 5000) = 0;

    /**
     * @brief Enter low power mode.
     * @qualifier Origin
     *
     * This function will put the robot in a low power mode which will wake up after a certain time.
     *
     * @param wake_up_time The time at which the robot should exit low power mode.
     * @param timeout_ms The time in milliseconds to wait for the robot to enter low power mode.
     * @throws creos::TimeoutError if the robot does not enter low power mode within the timeout.
     * @throws creos::UnsupportedError if the robot does not support entering low power mode.
     * @throws creos::Exception if any error occurred while sending the command.
     */
    virtual void enterLowPowerMode(const creos::RobotClock::time_point& wake_up_time, int timeout_ms = 5000) = 0;

    /**
     * @brief Exit low power mode.
     * @qualifier Origin
     *
     * This function will exit the robot from low power mode.
     *
     * @param timeout_ms The time in milliseconds to wait for the robot to respond to the command.
     * @throws creos::TimeoutError if the robot does not respond within the timeout.
     * @throws creos::UnsupportedError if the robot does not support exiting low power mode.
     * @throws creos::Exception if any other error occurred while sending the command.
     */
    virtual void exitLowPowerMode(int timeout_ms = 5000) = 0;

    /**
     * @brief Shutdown the robot.
     * @qualifier Origin
     *
     * This function will shutdown the robot.
     *
     * @param timeout_ms The time in milliseconds to wait for the robot to respond to the command.
     * @throws creos::TimeoutError if the robot does not respond within the timeout.
     * @throws creos::UnsupportedError if the robot does not support shutting down.
     * @throws creos::Exception if any other error occurred while sending the command.
     */
    virtual void shutdown(int timeout_ms = 5000) = 0;

    /**
     * @brief Reboot the robot.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * This function will reboot the robot.
     *
     * @param timeout_ms The time in milliseconds to wait for the robot to respond to the command.
     * @throws creos::TimeoutError if the robot does not respond within the timeout.
     * @throws creos::UnsupportedError if the robot does not support rebooting.
     * @throws creos::Exception if any other error occurred while sending the command.
     */
    virtual void reboot(int timeout_ms = 10000) = 0;
};

}  // namespace creos
