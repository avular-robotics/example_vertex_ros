// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 August 21
 * Author: Robbert-Jan de Jager
 *
 * Declaration of the ISetpointControlInterface class.
 ****************************************************************************/
#pragma once

#include <creos/client_global.hpp>
#include <creos/messages/command.hpp>
#include <creos/messages/control_source.hpp>
#include <creos/messages/interface_info.hpp>
#include <creos/messages/state_reference.hpp>
#include <creos/messages/twist.hpp>
#include <creos/subscription.hpp>

namespace creos {

/**
 * @brief The interface for sending control setpoints to an Avular robot.
 */
class CREOS_CLIENT_API ISetpointControlInterface {
public:
    static constexpr char name[] = "setpoint_control";
    static constexpr unsigned version = 1;

    virtual ~ISetpointControlInterface() = default;

    /**
     * @brief Publish a velocity command to the robot.
     * @qualifier Origin
     *
     * This function will publish a velocity command to the robot.
     *
     * @param message The velocity command to publish.
     * @throws creos::UnsupportedError if the robot does not support sending velocity commands.
     * @throws creos::PublicationError if an error occurs while publishing the velocity command.
     */
    virtual void publishVelocityCommand(const creos_messages::Twist& cmd_vel) = 0;

    /**
     * @brief Set the control source of the robot.
     * @qualifier Origin
     *
     * @param source The control source to set.
     * @param timeout_ms The timeout in milliseconds.
     * @throws creos::UnsupportedError if the robot does not support setting the control source.
     * @throws creos::PublicationError if an error occurs while setting the control source.
     * @throws creos::TimeoutError if the control source could not be set within the timeout.
     * @throws creos::ServiceCallError if the control source could not be set.
     */
    virtual void setControlSource(const creos_messages::ControlSource& source, int timeout_ms = 5000) = 0;

    /**
     * @brief Subscribe to the current control source of the robot.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * @param callback The callback to call when the control source changes.
     * @return The current control source of the robot.
     * @throws creos::UnsupportedError if the robot does not support getting the control source.
     * @throws creos::Exception if any other error occurred while setting the control source.
     */
    virtual SubscriptionId subscribeToCurrentControlSource(
        const std::function<void(const creos_messages::ControlSource&)>& callback) = 0;

    /**
     * @brief Get the current control source of the robot.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * @param timeout_ms The timeout in milliseconds.
     * @return The current control source of the robot.
     * @throws creos::UnsupportedError if the robot does not support getting the control source.
     * @throws creos::TimeoutError if the control source could not be retrieved within the timeout.
     * @throws creos::Exception if any other error occurred while getting the data.
     */
    virtual creos_messages::ControlSource getCurrentControlSource(int timeout_ms = 1500) = 0;

    /**
     * @brief Send a command to the robot to trigger a one-time action.
     * @qualifier Vertex
     *
     * @param command The command to send.
     * @param timeout_ms The timeout in milliseconds.
     * @throws creos::ServiceCallError if the command is not accepted.
     * @throws creos::UnsupportedError if the robot does not support commands.
     * @throws creos::TimeoutError if the robot does not respond within the timeout.
     */
    virtual void sendCommand(const creos_messages::Command command, int timeout_ms = 5000) = 0;

    /**
     * @brief Send a command with timestamp to the robot to trigger a one-time action.
     * @qualifier Vertex
     *
     * @param command The command to send with a timestamp.
     * @param timeout_ms The timeout in milliseconds.
     * @throws creos::ServiceCallError if the command is not accepted.
     * @throws creos::UnsupportedError if the robot does not support commands.
     * @throws creos::TimeoutError if the robot does not respond within the timeout.
     */
    virtual void sendCommand(const creos_messages::CommandStamped command, int timeout_ms = 5000) = 0;

    /**
     * @brief Publish a state reference to the robot.
     * @qualifier Vertex
     *
     * @param state_reference The state reference to publish.
     * @throws creos::UnsupportedError if the robot does not support state references.
     * @throws creos::PublicationError if an error occurs while publishing the state reference.
     * @throws creos::TimeoutError if the state reference could not be set within the timeout.
     */
    virtual void publishStateReference(const creos_messages::StateReference& state_reference) = 0;
};
}  // namespace creos
