// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 June 25
 * Author: Robbert-Jan de Jager
 *
 * @file This file declares objects related to subscriptions.
 ****************************************************************************/
#pragma once

namespace creos {

/**
 * @brief This type holds an subscription ID.
 */
class SubscriptionId {
    static constexpr int kInvalidId{-1};

public:
    SubscriptionId() = default;

    explicit SubscriptionId(int id) : id_(id) {}

    std::strong_ordering operator<=>(const SubscriptionId& other) const { return id_ <=> other.id_; }

    bool operator==(const SubscriptionId& other) const { return id_ == other.id_; }

    /**
   * @brief Check if the subscription ID is valid.
   */
    operator bool() const { return id_ != kInvalidId; }

    /**
   * @brief Get the internal subscription ID.
   */
    int getId() const { return id_; }

private:
    int id_{kInvalidId};
};

}  // namespace creos

template <>
struct std::hash<creos::SubscriptionId> {
    std::size_t operator()(const creos::SubscriptionId& id) const { return std::hash<int>{}(id.getId()); }
};
