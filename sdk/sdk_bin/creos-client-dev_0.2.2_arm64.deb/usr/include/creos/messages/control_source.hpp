// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 23
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the control source message.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief Control source message containing the control source of the robot
 */
enum class ControlSource {
    kDisabled,    ///< The robot is disabled
    kManual,      ///< The robot is controlled manually
    kAutonomous,  ///< The robot is controlled autonomously
    kUser,        ///< The robot is controlled by a user
};

}  // namespace creos_messages
