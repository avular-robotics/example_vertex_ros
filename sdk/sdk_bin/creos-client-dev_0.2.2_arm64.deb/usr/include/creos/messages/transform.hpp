// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 9
 * Author: Niels Rood
 *
 * @file The Transform message contains a transformation between two coordinate frames.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief The Transform message contains a transformation between two coordinate frames.
 *
 * The Transform is defined is defined in terms of a translation and a rotation. The translation is the vector from
 * the source frame to the target frame. The rotation is a quaternion.
 */
struct Transform {
    /**
     * @brief The frame id of the source frame
     */
    std::string frame_id;

    /**
     * @brief The frame id of the target frame
     */
    std::string child_frame_id;

    /**
     * @brief The translation from the source frame to the target frame
     */
    Vector3d translation = {0, 0, 0};

    /**
     * @brief The rotation quaternion from the source frame to the target frame
     */
    Quaterniond rotation = {0, 0, 0, 1};

    /**
     * @brief Compare two Transform messages
     */
    auto operator<=>(const Transform& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Transform, frame_id, child_frame_id, translation, rotation)

/**
 * @brief The TransformStamped message contains a transformation between two coordinate frames with a timestamp.
 */
struct TransformStamped : public Transform {
    /**
     * @brief The timestamp of the transform
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Compare two TransformStamped messages
     */
    auto operator<=>(const TransformStamped& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(TransformStamped, frame_id, child_frame_id, translation, rotation, timestamp)

/**
 * @brief The TransformStampedList message contains a list of transformations between two coordinate frames.
 *
 * Each transform defines its own timestamp.
 */
struct TransformStampedList {
    /**
     * @brief The list of transformations
     */
    std::vector<TransformStamped> transforms;

    /**
     * @brief Compare two TransformStampedList messages
     */
    auto operator<=>(const TransformStampedList& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(TransformStampedList, transforms)

}  // namespace creos_messages
