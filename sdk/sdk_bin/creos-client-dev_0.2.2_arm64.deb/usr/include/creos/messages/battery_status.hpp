// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 November 01
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the BatteryStatus message.
 ****************************************************************************/
#pragma once

#include <array>
#include <compare>
#include <cstdint>
#include <nlohmann/json.hpp>

#include "generic.hpp"

namespace creos_messages {
/**
 * @brief BatteryStatus message contains the current battery state
 */
struct BatteryStatus {

    enum State {
        kUnknown,      ///< The state is unknown
        kOffline,      ///< The battery is offline or not connected
        kCharging,     ///< The battery is charging
        kDischarging,  ///< The battery is discharging
        kBalancing,    ///< The battery is balancing between cells
        kError,        ///< The battery is in an error state
    };

    struct Alerts {
        bool cell_under_voltage : 1 = false;             ///< A cell has been undercharged
        bool cell_over_voltage : 1 = false;              ///< A cell has been overcharged
        bool over_current_charging : 1 = false;          ///< Too much current is provided while charging
        bool over_current_discharging : 1 = false;       ///< Too much current is drawn while discharging
        bool overload_discharging : 1 = false;           ///< Overload while discharging.
        bool latched_overload_discharging : 1 = false;   ///< Overload while discharging has occurred in the past
        bool short_circuit : 1 = false;                  ///< A short circuit has been detected
        bool latched_short_circuit : 1 = false;          ///< short circuit has occurred in the past
        bool over_temperature_charging : 1 = false;      ///< The battery is too hot while charging
        bool over_temperature_discharging : 1 = false;   ///< The battery is too hot while discharging
        bool under_temperature_charging : 1 = false;     ///< The battery is too cold while charging
        bool under_temperature_discharging : 1 = false;  ///< The battery is too cold while discharging
        bool afe_alert : 1 = false;                      ///< AFE alert (Analog Front End)
        bool precharge_timeout : 1 = false;  ///< Timeout during the precharge phase (balancing multiple batteries)
        bool overcharge : 1 = false;         ///< The battery has been charged too much

        /**
         * @brief Compare two BatteryStatus::Alerts messages
         */
        auto operator<=>(const Alerts& other) const = default;
    };

    float voltage = 0.0f;  ///< The current voltage of the battery pack [V], NaN if not available
    float state_of_charge =
        0.0f;  ///< The current state of charge of the battery pack (0.0 - 1.0), NaN if not available
    float state_of_health = 0.0f;  ///< How healthy is the battery pack (0.0 - 1.0), NaN if not available
    float temperature = 0.0f;      ///< The current temperature of the battery pack [°C], NaN if not available
    State state = kUnknown;        ///< The current state of the battery pack
    Alerts alerts;                 ///< The current alerts of the battery pack

    /**
     * @brief Compare two BatteryStatus messages
     */
    auto operator<=>(const BatteryStatus& other) const = default;
};

namespace detail {
enum class BatteryAlertFlags : uint32_t {
    kCellUnderVoltage = 0x1,
    kCellOverVoltage = 0x2,
    kOverCurrentCharge = 0x4,
    kOverCurrentDischarge = 0x8,
    kOverloadDischarge = 0x10,
    kOverloadDischargeLatch = 0x20,
    kShortCircuit = 0x40,
    kShortCircuitLatch = 0x80,
    kOverTemperatureCharge = 0x100,
    kOverTemperatureDischarge = 0x200,
    kUnderTemperatureCharge = 0x400,
    kUnderTemperatureDischarge = 0x800,
    kAfeAlert = 0x1000,

    kPrechargeTimeout = 0x40000,
    kOvercharge = 0x100000,
};

inline constexpr bool isSet(uint32_t flags, BatteryAlertFlags flag) {
    return (static_cast<uint32_t>(flag) & flags) != 0;
}

inline constexpr void addFlag(uint32_t& flags, BatteryAlertFlags flag, bool value) {
    if (value) {
        flags |= static_cast<uint32_t>(flag);
    }
}

}  // namespace detail

inline void to_json(nlohmann::json& j, const BatteryStatus::Alerts& alerts) {
    using namespace detail;

    uint32_t flags = 0;
    addFlag(flags, BatteryAlertFlags::kCellUnderVoltage, alerts.cell_under_voltage);
    addFlag(flags, BatteryAlertFlags::kCellOverVoltage, alerts.cell_over_voltage);
    addFlag(flags, BatteryAlertFlags::kOverCurrentCharge, alerts.over_current_charging);
    addFlag(flags, BatteryAlertFlags::kOverCurrentDischarge, alerts.over_current_discharging);
    addFlag(flags, BatteryAlertFlags::kOverloadDischarge, alerts.overload_discharging);
    addFlag(flags, BatteryAlertFlags::kOverloadDischargeLatch, alerts.latched_overload_discharging);
    addFlag(flags, BatteryAlertFlags::kShortCircuit, alerts.short_circuit);
    addFlag(flags, BatteryAlertFlags::kShortCircuitLatch, alerts.latched_short_circuit);
    addFlag(flags, BatteryAlertFlags::kOverTemperatureCharge, alerts.over_temperature_charging);
    addFlag(flags, BatteryAlertFlags::kOverTemperatureDischarge, alerts.over_temperature_discharging);
    addFlag(flags, BatteryAlertFlags::kUnderTemperatureCharge, alerts.under_temperature_charging);
    addFlag(flags, BatteryAlertFlags::kUnderTemperatureDischarge, alerts.under_temperature_discharging);
    addFlag(flags, BatteryAlertFlags::kAfeAlert, alerts.afe_alert);
    addFlag(flags, BatteryAlertFlags::kPrechargeTimeout, alerts.precharge_timeout);
    addFlag(flags, BatteryAlertFlags::kOvercharge, alerts.overcharge);

    j = flags;
}

inline void from_json(const nlohmann::json& j, BatteryStatus::Alerts& alerts) {
    using namespace detail;
    uint32_t flags = j.get<uint32_t>();
    alerts.cell_under_voltage = isSet(flags, BatteryAlertFlags::kCellUnderVoltage);
    alerts.cell_over_voltage = isSet(flags, BatteryAlertFlags::kCellOverVoltage);
    alerts.over_current_charging = isSet(flags, BatteryAlertFlags::kOverCurrentCharge);
    alerts.over_current_discharging = isSet(flags, BatteryAlertFlags::kOverCurrentDischarge);
    alerts.overload_discharging = isSet(flags, BatteryAlertFlags::kOverloadDischarge);
    alerts.latched_overload_discharging = isSet(flags, BatteryAlertFlags::kOverloadDischargeLatch);
    alerts.short_circuit = isSet(flags, BatteryAlertFlags::kShortCircuit);
    alerts.latched_short_circuit = isSet(flags, BatteryAlertFlags::kShortCircuitLatch);
    alerts.over_temperature_charging = isSet(flags, BatteryAlertFlags::kOverTemperatureCharge);
    alerts.over_temperature_discharging = isSet(flags, BatteryAlertFlags::kOverTemperatureDischarge);
    alerts.under_temperature_charging = isSet(flags, BatteryAlertFlags::kUnderTemperatureCharge);
    alerts.under_temperature_discharging = isSet(flags, BatteryAlertFlags::kUnderTemperatureDischarge);
    alerts.afe_alert = isSet(flags, BatteryAlertFlags::kAfeAlert);
    alerts.precharge_timeout = isSet(flags, BatteryAlertFlags::kPrechargeTimeout);
    alerts.overcharge = isSet(flags, BatteryAlertFlags::kOvercharge);
}

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(BatteryStatus, voltage, state_of_charge, state_of_health, temperature, state, alerts)

}  // namespace creos_messages
