// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 December 12
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the QueryAttachment message.
 ****************************************************************************/
#pragma once

#include <array>
#include <compare>
#include <nlohmann/json.hpp>

namespace creos_messages::detail {
/**
 * @brief QueryReplyAttachment message holds additional information that is attached to a query.
 */
struct QueryReplyAttachment {

    std::string data_type;  ///< The type of the data
    int data_kind;          ///< The kind of the data
    bool is_error;          ///< Whether the data is an error

    /**
     * @brief Compare two QueryReplyAttachment messages
     */
    auto operator<=>(const QueryReplyAttachment& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(QueryReplyAttachment, data_type, data_kind, is_error)

/**
 * @brief QueryRequestAttachment message holds additional information that is attached to a query.
 */
struct QueryRequestAttachment {
    std::string request_type;   ///< The type of the request
    std::string response_type;  ///< The type of the response

    /**
     * @brief Compare two QueryRequestAttachment messages
     */
    auto operator<=>(const QueryRequestAttachment& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(QueryRequestAttachment, request_type, response_type);

}  // namespace creos_messages::detail
