// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 08
 * Author: Bram Tertoolen
 *
 * @file Message containing GNSS data of the robot
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>
#include <string>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief A coordinate in the GNSS system
 */
struct GnssCoordinate {
    /**
     * @brief latitude [degrees]
     * Positive values are north of the equator, negative values are south of the equator
     */
    double latitude = 0.0;
    /**
     * @brief longitude [degrees]
     * Positive values are east of the prime meridian, negative values are west of the prime meridian
     */
    double longitude = 0.0;
    /**
     * @brief altitude [m]
     * NaN if no altitude is available
     */
    double altitude = 0.0;  // [m] NaN if no altitude is available

    /**
     * @brief Compare two GnssCoordinate messages
     */
    auto operator<=>(const GnssCoordinate& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(GnssCoordinate, latitude, longitude, altitude)

/**
 * @brief The GNSS message contains the GNSS data of the robot
 */
struct GnssPosition {
    enum CovarianceType {
        kInvalidCovariance = -1,  ///< The covariance of the GNSS sensor is invalid
        kUnknown = 0,             ///< The covariance of the GNSS sensor is unknown
        kApproximated = 1,        ///< The covariance of the GNSS sensor is approximated
        kDiagonalKnown = 2,       ///< The covariance of the GNSS sensor is diagonal and known
        kKnown = 3                ///< The covariance of the GNSS sensor is known
    };

    GnssCoordinate coordinate;
    Matrixd<3, 3> covariance;
    CovarianceType position_covariance_type = kInvalidCovariance;

    /**
     * @brief Compare two GnssPosition messages
     */
    auto operator<=>(const GnssPosition& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(GnssPosition, coordinate, covariance, position_covariance_type)

/**
 * @brief The heading of the GNSS sensor
 */
struct GnssHeading {

    double heading = 0.0;             ///< The heading of the GNSS sensor [rad]
    double heading_covariance = 0.0;  ///< The covariance of the heading of the GNSS sensor [rad^2]

    /**
     * @brief Compare two GnssHeading messages
     */
    auto operator<=>(const GnssHeading& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(GnssHeading, heading, heading_covariance)

/**
 * @brief The GNSS message contains the GNSS data of the robot
 */
struct Gnss {

    struct Service {
        bool gps : 1 = false;      ///< The GNSS sensor is connected to GPS satellites
        bool glonass : 1 = false;  ///< The GNSS sensor is connected to GLONASS satellites
        bool beidou : 1 = false;   ///< The GNSS sensor is connected to Beidou satellites
        bool galileo : 1 = false;  ///< The GNSS sensor is connected to Galileo satellites

        /**
         * @brief Compare two Service messages
         */
        auto operator<=>(const Service& other) const = default;
    };

    enum Augmentation {
        kInvalidStatus = -2,              ///< The GNSS sensor has an invalid status
        kNoAugmentationFix = -1,          ///< The GNSS sensor has no fix
        kUnaugmentedFix = 0,              ///< The GNSS sensor has an unaugmented fix
        kSatelliteBasedAugmentation = 1,  ///< The GNSS sensor has a satellite based augmentation
        kGroundBasedAugmentation = 2      ///< The GNSS sensor has a ground based augmentation
    };

    enum FixStatus {
        kNoFix = -1,    ///< The GNSS sensor has no fix
        k2DFix = 0,     ///< The GNSS sensor has a 2D fix
        k3DFix = 1,     ///< The GNSS sensor has a 3D fix
        kRTKFloat = 2,  ///< The GNSS sensor has a RTK float fix
        kRTKFix = 3,    ///< The GNSS sensor has a RTK fix
    };

    /**
     * @brief Timestamp of when sensor data was created / measured
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the GNSS sensor
     */
    std::string frame_id;

    /**
     * @brief The augmentation of the GNSS sensor
     */
    Augmentation augmentation = Augmentation::kInvalidStatus;

    /**
     * @brief The service of the GNSS sensor
     */
    Service service;

    /**
     * @brief The position of the GNSS sensor
     */
    GnssPosition position;

    /**
     * @brief The heading of the GNSS sensor
     */
    GnssHeading heading;

    /**
     * @brief The fix status of the GNSS sensor
     */
    FixStatus fix_status = FixStatus::kNoFix;

    /**
     * @brief The number of visible satellites
     */
    int satellites_visible = 0;

    /**
     * @brief The number of satellites used in the fix
     */
    int satellites_used = 0;

    /**
     * @brief Compare two Gnss messages
     */
    auto operator<=>(const Gnss& other) const = default;
};

namespace detail {
enum class GnssServiceFlags : uint32_t {
    kNone = 0x0,
    kGps = 0x1,
    kGlonass = 0x2,
    kBeidou = 0x4,
    kGalileo = 0x8,
};

inline constexpr bool isSet(uint32_t flags, GnssServiceFlags flag) {
    return (static_cast<uint32_t>(flag) & flags) != 0;
}

inline constexpr void addFlag(uint32_t& flags, GnssServiceFlags flag, bool value) {
    if (value) {
        flags |= static_cast<uint32_t>(flag);
    }
}

}  // namespace detail

inline void to_json(nlohmann::json& j, const Gnss::Service& service) {
    using namespace detail;

    uint32_t flags = 0;
    addFlag(flags, GnssServiceFlags::kGps, service.gps);
    addFlag(flags, GnssServiceFlags::kGlonass, service.glonass);
    addFlag(flags, GnssServiceFlags::kBeidou, service.beidou);
    addFlag(flags, GnssServiceFlags::kGalileo, service.galileo);

    j = flags;
}

inline void from_json(const nlohmann::json& j, Gnss::Service& service) {
    using namespace detail;

    uint32_t flags = j.get<uint32_t>();

    service.gps = isSet(flags, GnssServiceFlags::kGps);
    service.glonass = isSet(flags, GnssServiceFlags::kGlonass);
    service.beidou = isSet(flags, GnssServiceFlags::kBeidou);
    service.galileo = isSet(flags, GnssServiceFlags::kGalileo);
}

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Gnss, timestamp, frame_id, augmentation, service, position, heading, fix_status,
                                   satellites_visible, satellites_used)

}  // namespace creos_messages
