// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 18
 * Author: Robbert-Jan de Jager
 *
 * @file Remote control message containing the remote controller state
 ****************************************************************************/
#pragma once

#include <compare>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>
#include <vector>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief Remote control message containing the remote controller state
 */
struct ControllerState {

    enum ButtonState {
        kLeft = -1,
        kDown = -1,  // Same as left
        kMiddle = 0,
        kReleased = 0,  // Same as middle
        kRight = 1,
        kPressed = 1,  // Same as right
        kUp = 1,       // Same as right
        kLongPress = 2,
    };

    /**
     * @brief Timestamp of the remote controller state
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Axes data of the remote controller
     * @details The axes are represented by floating point numbers.
     * If the axis doesn't self center, the value will be between 0 and 1. If
     * the axis self centers, the value will be between -1 and 1, where -1 is
     * the left or down position and 1 is the right or up position; 0 should be
     * the resting position. If we have a strange axis where the centering
     * position is not in the middle, we will normalize the value so that the
     * most extreme positions are -1 or 1, and the resting position will still
     * be 0. Analog buttons are represented by floating point numbers between 0
     * and 1. Triggers that have a switch at the end of travel are an axis with
     * an additional button.
     *
     * @internal
     * The order of the axes depends on the robot, but the following order is
     * preferred:
     * - Left stick: x, y
     * - Right stick: x, y
     * - Wheels
     * - Analog buttons
     * @endinternal
     *
     * For the Origin, the order is:
     * - Left stick x
     * - Left stick y
     * - Right stick x
     * - Right stick y
     * - Left trigger
     * - Right trigger
     *
     * For drones the order is:
     * - Roll
     * - Pitch
     * - Throttle
     * - Yaw
     * - Wheels
     * - Analog buttons
     * The selected mode for the drone does not impact the order of the axes.
     */
    std::vector<float> axes;

    /**
     * @brief Buttons data of the remote controller
     * @details The buttons are represented by integers, as some buttons can
     * have multiple states. Tactile buttons are 1 for pressed, 0 for released,
     * 2 for long press. Switches are 1 for on and 0 for off. 3-way switches are
     *  -1 for left/down, 0 for middle, and 1 for right/up.
     *
     * @internal
     * The order of the buttons depends on the robot, but the following order is
     * preferred:
     * - Tactile buttons
     * - Switches/3-way switches
     * - d-pad
     * @endinternal
     *
     * For the Origin, the order of the buttons is:
     * - ✕
     * - ◯
     * - △
     * - □
     * - L1
     * - R1
     * - L2
     * - R2
     * - Share
     * - Options
     * - PS
     * - L3
     * - R3
     * - D-pad left
     * - D-pad up
     * - D-pad right
     * - D-pad down
     *
     */
    std::vector<ButtonState> buttons;

    /**
     * @brief Compare two ControllerState messages
     */
    auto operator<=>(const ControllerState& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(ControllerState, timestamp, axes, buttons)

}  // namespace creos_messages
