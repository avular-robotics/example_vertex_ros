// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 18
 * Author: Robbert-Jan de Jager
 *
 * @file Definition of the PointCloud2 message.
 ****************************************************************************/
#pragma once

#include <compare>
#include <creos/enum.hpp>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>
#include <string>
#include <vector>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief The PointCloud2FieldDescription message describes a single field of the point cloud.
 */
struct PointCloud2FieldDescription {
    enum DataType {
        INT8 = 1,
        UINT8 = 2,
        INT16 = 3,
        UINT16 = 4,
        INT32 = 5,
        UINT32 = 6,
        FLOAT32 = 7,
        FLOAT64 = 8,
    };

    /**
     * @brief The name of the field
     */
    std::string name;

    /**
     * @brief The offset of the field
     */
    uint32_t offset = 0;

    /**
     * @brief The datatype of the field
     */
    DataType datatype = INT32;

    /**
     * @brief The number of elements in the field
     */
    uint32_t count = 1;

    /**
     * @brief Compare two PointCloud2FieldDescription messages
     */
    auto operator<=>(const PointCloud2FieldDescription& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(PointCloud2FieldDescription, name, offset, datatype, count)

/**
 * @brief The PointCloud2 message contains a 3D point cloud.
 */
struct PointCloud2 {
    /**
     * @brief Timestamp of the point cloud
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the point cloud
     */
    std::string frame_id;

    /**
     * @brief The width of the point cloud
     */
    uint32_t width = 0;

    /**
     * @brief The height of the point cloud
     */
    uint32_t height = 0;

    /**
     * @brief The fields of the point cloud
     */
    std::vector<PointCloud2FieldDescription> fields;

    /**
     * @brief The is_bigendian field of the point cloud
     */
    bool is_bigendian = false;

    /**
     * @brief The point step of the point cloud
     */
    uint32_t point_step = 0;

    /**
     * @brief The row step of the point cloud
     */
    uint32_t row_step = 0;

    /**
     * @brief The raw data of the point cloud
     */
    std::vector<uint8_t> data;

    /**
     * @brief The point cloud contains no invalid data
     */
    bool is_dense = false;

    /**
     * @brief Compare two PointCloud2 messages
     */
    auto operator<=>(const PointCloud2& other) const = default;
};

inline void to_json(nlohmann::json& j, const PointCloud2& p) {
    j = nlohmann::json{
        {"timestamp", p.timestamp},
        {"width", p.width},
        {"height", p.height},
        {"fields", p.fields},
        {"is_bigendian", p.is_bigendian},
        {"point_step", p.point_step},
        {"row_step", p.row_step},
        {"data", nlohmann::json::binary(p.data)},
        {"is_dense", p.is_dense},
    };
}

inline void from_json(const nlohmann::json& j, PointCloud2& p) {
    j.at("timestamp").get_to(p.timestamp);
    j.at("width").get_to(p.width);
    j.at("height").get_to(p.height);
    j.at("fields").get_to(p.fields);
    j.at("is_bigendian").get_to(p.is_bigendian);
    j.at("point_step").get_to(p.point_step);
    j.at("row_step").get_to(p.row_step);
    p.data = std::move(j.at("data").get_binary());
    j.at("is_dense").get_to(p.is_dense);
}

/**
 * @brief The Lidar3dId enum class contains the different lidar 3D sensors.
 */
enum class Lidar3dId {
    kFront,  ///< The front lidar 3D sensor
};

};  // namespace creos_messages

DEFINE_ENUM_STRING_CONVERSIONS(creos_messages::Lidar3dId, {{creos_messages::Lidar3dId::kFront, "front"}})
