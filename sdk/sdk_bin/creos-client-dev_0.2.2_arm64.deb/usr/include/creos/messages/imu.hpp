// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 23
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the imu message.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/enum.hpp>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief IMU message containing the orientation, angular velocity and linear acceleration
 */
struct Imu {

    /**
     * @brief Timestamp of the IMU message
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the IMU message
     */
    std::string frame_id;

    /**
     * @brief Orientation quaternion in the order (x, y, z, w)
     */
    Quaternionf orientation = {0, 0, 0, 1};

    /**
     * @brief the covariance matrix of the orientation. Row major about x, y, z
     */
    Matrixf<3, 3> orientation_covariance;

    /**
     * @brief Angular velocity in the order (x, y, z) [rad/s]
     */
    Vector3f angular_velocity = {0, 0, 0};

    /**
     * @brief the covariance matrix of the angular velocity. Row major about x, y, z
     */
    Matrixf<3, 3> angular_velocity_covariance;

    /**
     * @brief Linear acceleration in the order (x, y, z) [m/s^2]
     */
    Vector3f linear_acceleration = {0, 0, 0};

    /**
     * @brief the covariance matrix of the linear acceleration. Row major about x, y, z
     */
    Matrixf<3, 3> linear_acceleration_covariance;

    /**
     * @brief Compare two IMU messages
     */
    auto operator<=>(const Imu& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Imu, timestamp, orientation, orientation_covariance, angular_velocity,
                                   angular_velocity_covariance, linear_acceleration, linear_acceleration_covariance);

/**
 * @brief IMU sensor id
 */
enum class ImuId {
    kBody,  ///< IMU sensor on the body of the robot
};

}  // namespace creos_messages

DEFINE_ENUM_STRING_CONVERSIONS(creos_messages::ImuId, {{creos_messages::ImuId::kBody, "body"}})
