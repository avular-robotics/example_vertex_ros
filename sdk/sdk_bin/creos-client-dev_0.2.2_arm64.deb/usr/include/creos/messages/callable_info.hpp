// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 1
 * Author: Niels Rood
 *
 * @file SDK information message containing information about the callable functions
 ****************************************************************************/
#pragma once

#include <compare>
#include <nlohmann/json.hpp>

namespace creos_messages {

/**
 * @brief SDK information message containing information about the callable functions
 */
struct CallableInfo {

    /**
     * @brief Name of the callable function
     */
    std::string name;

    /**
     * @brief Request type of the callable function
     */
    std::string request_type;

    /**
     * @brief Response type of the callable function
     */
    std::string response_type;

    /**
     * @brief Compare two CallableInfo object messages
     */
    auto operator<=>(const CallableInfo& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(CallableInfo, name, request_type, response_type)

}  // namespace creos_messages
