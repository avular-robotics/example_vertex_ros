// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 September 27
 * Author: Niels Rood
 *
 * @file SDK information message containing information about the data sources and sinks
 ****************************************************************************/
#pragma once

#include <compare>
#include <creos/data_kind.hpp>
#include <nlohmann/json.hpp>

namespace creos_messages {

/**
 * @brief SDK information message containing information about the data sources and sinks
 */
struct DataSourceSinkInfo {

    /**
     * @brief Name of the data source or sink
     */
    std::string name;

    /**
     * @brief Type of the data source or sink
     */
    std::string type;

    /**
     * @brief The kind of data that is published or subscribed to
     */
    creos::DataKind data_kind;

    /**
     * @brief Compare two DataSourceSinkInfo messages
     */
    auto operator<=>(const DataSourceSinkInfo& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(DataSourceSinkInfo, name, type, data_kind)

}  // namespace creos_messages
