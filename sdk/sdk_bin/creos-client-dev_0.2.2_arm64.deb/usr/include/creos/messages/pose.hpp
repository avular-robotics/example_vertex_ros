// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 17
 * Author: Robbert-Jan de Jager
 *
 * @file The pose contains a position and orientation.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/messages/generic.hpp>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

namespace creos_messages {

/**
 * @brief The Pose message contains a position and orientation.
 */
struct Pose {
    /**
     * @brief Position of the robot in the world frame
     */
    Point position = {0, 0, 0};

    /**
     * @brief Orientation of the robot in the world frame
     */
    Quaterniond orientation = {0, 0, 0, 1};

    /**
     * @brief Compare two Pose messages
     */
    auto operator<=>(const Pose& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Pose, position, orientation)

/**
 * @brief The PoseWithCovariance message contains a position and orientation with a covariance matrix.
 */
struct PoseWithCovariance : public Pose {
    /**
     * @brief Covariance matrix of the pose
     * The covariance matrix is a 6x6 matrix with the following order:
     * [x, y, z, roll, pitch, yaw]
     */
    Matrixd<6, 6> covariance;

    /**
     * @brief Compare two PoseWithCovariance messages
     */
    auto operator<=>(const PoseWithCovariance& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(PoseWithCovariance, position, orientation, covariance)

/**
 * @brief The PoseWithCovarianceStamped message contains a position and orientation with a covariance matrix and a timestamp.
 */
struct PoseWithCovarianceStamped : public PoseWithCovariance {
    /**
     * @brief Timestamp of the estimated position and orientation
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the estimated position and orientation
     */
    std::string frame_id;

    /**
     * @brief Compare two PoseWithCovarianceStamped messages
     */
    auto operator<=>(const PoseWithCovarianceStamped& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(PoseWithCovarianceStamped, timestamp, position, orientation, covariance)

/**
 * @brief The PoseStamped message contains a position and orientation with a timestamp.
 */
struct PoseStamped : public Pose {
    /**
     * @brief Timestamp of the estimated position and orientation
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the estimated position and orientation
     */
    std::string frame_id;

    /**
     * @brief Compare two PoseStamped messages
     */
    auto operator<=>(const PoseStamped& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(PoseStamped, timestamp, position, orientation)

}  // namespace creos_messages
