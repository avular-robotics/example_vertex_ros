// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 1
 * Author: Niels Rood
 *
 * @file SDK information message containing information about an interface group
 ****************************************************************************/
#pragma once

#include <compare>
#include <nlohmann/json.hpp>

#include "callable_info.hpp"
#include "data_source_sink_info.hpp"

namespace creos_messages {

/**
 * @brief SDK information message containing information about an interface group
 */
struct InterfaceGroupInfo {

    /**
     * @brief Name of the interface group
     */
    std::string name;

    /**
     * @brief Version of the interface group
     */
    unsigned version;

    /**
     * @brief Sinks of the interface group
     */
    std::vector<DataSourceSinkInfo> sinks;

    /**
     * @brief Sources of the interface group
     */
    std::vector<DataSourceSinkInfo> sources;

    /**
     * @brief Callables of the interface group
     */
    std::vector<CallableInfo> callables;

    /**
     * @brief Compare two InterfaceGroupInfo object messages
     */
    auto operator<=>(const InterfaceGroupInfo& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(InterfaceGroupInfo, name, version, sinks, sources, callables)

}  // namespace creos_messages
