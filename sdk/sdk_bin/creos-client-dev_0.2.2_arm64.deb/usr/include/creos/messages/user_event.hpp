// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 16
 * Author: Niels Rood
 *
 * @file Messages for communicating events meant for a robot user.
 ****************************************************************************/
#pragma once

#include <nlohmann/json.hpp>
#include <string>
#include <variant>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief An event meant for a robot user.
 */
struct UserEvent {
    /**
     * @brief The severity of an event
     * This information can be used to filter events based on their importance to the user.
     */
    enum class Severity {
        kTrace,  ///< A trace message, used for debugging purposes.
        kInfo,   ///< An informational message.
        kWarn,   ///< A warning message.
        kError,  ///< An error message.
        kFatal,  ///< A fatal error message.
    };

    /**
     * @brief The (suggested) method to display the message to the user.
     * This information can be used to determine how to display the message to the user. Internal robot systems can
     * suggest how an event should be shown to the user, either as a log message or as a notification.
     */
    enum class DisplayMethod {
        kLog,           ///< The message should be logged.
        kNotification,  ///< The message should be displayed as a notification.
    };

    creos::RobotClock::time_point time;                  ///< The moment in time when the event was generated
    Severity severity = Severity::kInfo;                 ///< The severity of the event
    DisplayMethod display_method = DisplayMethod::kLog;  ///< The method to display the event to the user
    std::string source_id;                               ///< The id of the source that generated the event
    std::string message;                                 ///< The message to display to the user
    std::string component;                               ///< The name of the component that generated the event
};

NLOHMANN_JSON_SERIALIZE_ENUM(UserEvent::Severity, {
                                                      {UserEvent::Severity::kTrace, "trace"},
                                                      {UserEvent::Severity::kInfo, "info"},
                                                      {UserEvent::Severity::kWarn, "warn"},
                                                      {UserEvent::Severity::kError, "error"},
                                                      {UserEvent::Severity::kFatal, "fatal"},
                                                  });

NLOHMANN_JSON_SERIALIZE_ENUM(UserEvent::DisplayMethod, {
                                                           {UserEvent::DisplayMethod::kLog, "log"},
                                                           {UserEvent::DisplayMethod::kNotification, "notification"},
                                                       });

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(UserEvent, time, severity, display_method, message, component)

}  // namespace creos_messages
