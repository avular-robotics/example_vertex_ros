// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 18
 * Author: Robbert-Jan de Jager
 *
 * @file Wheel state message containing the position and velocity of the wheels
 ****************************************************************************/
#pragma once

#include <compare>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>
#include <vector>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief Wheel state message containing the position and velocity of one wheel
 */
struct WheelState {
    /**
     * @brief Position of the wheel [rad]
     */
    float position = 0;

    /**
     * @brief Velocity of the wheel [rad/s]
     */
    float velocity = 0;

    /**
     * @brief Compare two WheelState messages
     */
    auto operator<=>(const WheelState& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(WheelState, position, velocity)

/**
 * @brief Wheel state message containing the position and velocity of the wheels
 */
struct WheelStates {

    /**
     * @brief Timestamp of the remote controller state
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the wheel states
     */
    std::string frame_id;

    /**
     * @brief Wheel states
     * @details The order of the wheels is important. The wheels are ordered starting at the front-right wheel and going clockwise.
     */
    std::vector<WheelState> wheels;

    /// @brief Compare two ControllerState messages
    auto operator<=>(const WheelStates& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(WheelStates, timestamp, frame_id, wheels)

}  // namespace creos_messages
