// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 17
 * Author: Robbert-Jan de Jager
 *
 * @file The twist contains a linear and angular velocity.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/messages/generic.hpp>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

namespace creos_messages {

/**
 * @brief The Twist message contains the linear and angular velocity of the robot.
 */
struct Twist {
    /**
     * @brief Linear velocity of the robot in the world frame [m/s]
     */
    Vector3d linear = {0, 0, 0};

    /**
     * @brief Angular velocity of the robot in the world frame [rad/s]
     */
    Vector3d angular = {0, 0, 0};

    /**
     * @brief Compare two Twist messages
     */
    auto operator<=>(const Twist& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Twist, linear, angular)

/**
 * @brief The TwistWithCovariance message contains the linear and angular velocity of the robot with a covariance matrix.
 */
struct TwistWithCovariance : public Twist {
    /**
     * @brief Covariance matrix of the pose
     * The covariance matrix is a 6x6 matrix with the following order:
     * [x, y, z, roll, pitch, yaw]
     */
    Matrixd<6, 6> covariance;

    /**
     * @brief Compare two TwistWithCovariance messages
     */
    auto operator<=>(const TwistWithCovariance& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(TwistWithCovariance, linear, angular, covariance)

/**
 * @brief The TwistStamped message contains the linear and angular velocity of the robot with a timestamp.
 */
struct TwistStamped : public Twist {
    /**
     * @brief Timestamp of the estimated linear and angular velocity
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the twist
     */
    std::string frame_id;

    /**
     * @brief Compare two TwistStamped messages
     */
    auto operator<=>(const TwistStamped& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(TwistStamped, linear, angular, timestamp, frame_id)

/**
 * @brief The TwistWithCovarianceStamped message contains the linear and angular velocity of the robot with a covariance matrix and a timestamp.
 */
struct TwistWithCovarianceStamped : public TwistWithCovariance {
    /**
     * @brief Timestamp of the estimated linear and angular velocity
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the twist
     */
    std::string frame_id;

    /**
     * @brief Compare two TwistWithCovarianceStamped messages
     */
    auto operator<=>(const TwistWithCovarianceStamped& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(TwistWithCovarianceStamped, linear, angular, covariance, timestamp)

}  // namespace creos_messages
