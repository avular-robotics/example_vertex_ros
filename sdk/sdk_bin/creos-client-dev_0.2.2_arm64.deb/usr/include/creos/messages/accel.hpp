// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 17
 * Author: Robbert-Jan de Jager
 *
 * @file The accel contains a linear and angular acceleration.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/messages/generic.hpp>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

namespace creos_messages {

/**
 * @brief The Accel message contains the linear and angular acceleration of the robot.
 */
struct Accel {
    /**
     * @brief Linear acceleration of the robot in the world frame [m/s²]
     */
    Vector3d linear = {0, 0, 0};

    /**
     * @brief Angular acceleration of the robot in the world frame [rad/s²]
     */
    Vector3d angular = {0, 0, 0};

    /**
     * @brief Compare two Accel messages
     */
    auto operator<=>(const Accel& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Accel, linear, angular)

/**
 * @brief The AccelWithCovariance message contains the linear and angular acceleration of the robot with a covariance matrix.
 */
struct AccelWithCovariance : public Accel {
    /**
     * @brief Covariance matrix of the pose
     * The covariance matrix is a 6x6 matrix with the following order:
     * [x, y, z, roll, pitch, yaw]
     */
    Matrixd<6, 6> covariance;

    /**
     * @brief Compare two AccelWithCovariance messages
     */
    auto operator<=>(const AccelWithCovariance& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(AccelWithCovariance, linear, angular, covariance)

/**
 * @brief The AccelStamped message contains the linear and angular acceleration of the robot with a timestamp.
 */
struct AccelStamped : public Accel {
    /**
     * @brief Timestamp of the estimated linear and angular acceleration
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the accel
     */
    std::string frame_id;

    /**
     * @brief Compare two AccelStamped messages
     */
    auto operator<=>(const AccelStamped& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(AccelStamped, linear, angular, timestamp, frame_id)

/**
 * @brief The AccelWithCovarianceStamped message contains the linear and angular acceleration of the robot with a covariance matrix and a timestamp.
 */
struct AccelWithCovarianceStamped : public AccelWithCovariance {
    /**
     * @brief Timestamp of the estimated linear and angular acceleration
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the accel
     */
    std::string frame_id;

    /**
     * @brief Compare two AccelWithCovarianceStamped messages
     */
    auto operator<=>(const AccelWithCovarianceStamped& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(AccelWithCovarianceStamped, linear, angular, covariance, timestamp)

}  // namespace creos_messages
