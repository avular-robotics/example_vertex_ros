// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 17
 * Author: Robbert-Jan de Jager
 *
 * @file The Odometry message contains the estimated position, orientation and velocity
 * of the robot.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

#include "generic.hpp"
#include "pose.hpp"
#include "twist.hpp"

namespace creos_messages {

/**
 * @brief The Odometry message contains the estimated position, orientation and velocity
 * of the robot.
 */
struct Odometry {
    /**
     * @brief Timestamp of the estimated position, orientation and velocity
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the odometry
     */
    std::string frame_id;

    /**
     * @brief Position and orientation of the robot
     */
    PoseWithCovariance pose;

    /**
     * @brief Linear and angular velocity of the robot
     */
    TwistWithCovariance twist;

    /**
     * @brief Compare two Odometry messages
     */
    auto operator<=>(const Odometry& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Odometry, timestamp, pose, twist)

}  // namespace creos_messages
