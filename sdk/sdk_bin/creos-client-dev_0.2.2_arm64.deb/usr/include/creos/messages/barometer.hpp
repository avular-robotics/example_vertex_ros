// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 23
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the barometer message.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief Barometer message containing the pressure and temperature
 */
struct Barometer {

    /**
     * @brief Timestamp of the magnetic field
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the magnetic field
     */
    std::string frame_id;

    /**
     * @brief Pressure [hPa]
     */
    float pressure = 0;

    /**
     * @brief variance of the pressure
     */
    float variance = 0;

    /**
     * @brief Temperature [°C]
     */
    float temperature = 0;

    /**
     * @brief Compare two Pose messages
     */
    auto operator<=>(const Barometer& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Barometer, timestamp, pressure, variance, temperature)

}  // namespace creos_messages
