// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 31
 * Author: Robbert-Jan de Jager
 *
 * @file Definitions of the system info interface.
 ****************************************************************************/
#pragma once

#include <creos/client_global.hpp>
#include <creos/messages/battery_status.hpp>
#include <creos/messages/system_info.hpp>
#include <creos/subscription.hpp>

namespace creos {

/**
 * @brief The interface for retrieving general system information of an Avular
 * robot.
 */
class CREOS_CLIENT_API ISystemInfoInterface {
public:
    static constexpr char name[] = "system_info";
    static constexpr unsigned version = 1;

    virtual ~ISystemInfoInterface() = default;

    /**
     * @brief Subscribe to system info messages.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * The system info messages contain information about the connected system, like the name and serial number.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError If the robot does not provide this data, or the client and agent are incompatible.
     * @throws creos::SubscriptionError If the subscription failed to be created.
     */
    virtual SubscriptionId subscribeToSystemInfo(
        const std::function<void(const creos_messages::SystemInfo&)>& callback) = 0;

    /**
     * @brief Get the system info.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * The system info contains information about the connected system, like the name and serial number.
     * This function will block until the system info is received.
     *
     * @param timeout_ms The time in milliseconds to wait for the system info.
     * @return creos_messages::SystemInfo The system info.
     * @throws creos::TimeoutError If the system info is not received within the timeout.
     * @throws creos::UnsupportedError If the robot does not provide this data, or the client and agent are incompatible.
     * @throws creos::Exception if any other error occurred while getting the data.
     */
    virtual creos_messages::SystemInfo getSystemInfo(int timeout_ms = 1500) = 0;

    /**
     * @brief Subscribe to battery status updates.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * The battery status contains information about the battery, like the state and alerts.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError If the robot does not provide this data, or the client and agent are incompatible.
     * @throws creos::SubscriptionError If the subscription failed to be created.
     */
    virtual SubscriptionId subscribeToBatteryStatus(
        const std::function<void(const creos_messages::BatteryStatus&)>& callback) = 0;

    /**
     * @brief Get the battery status.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * The battery status contains information about the battery, like the state and alerts.
     * This function will block until the battery status is received.
     *
     * @param timeout_ms The time in milliseconds to wait for the battery status.
     * @return creos_messages::BatteryStatus The battery status.
     * @throws creos::TimeoutError If the battery status is not received within the timeout.
     * @throws creos::UnsupportedError If the robot does not provide this data, or the client and agent are incompatible.
     * @throws creos::Exception if any other error occurred while getting the data.
     */
    virtual creos_messages::BatteryStatus getBatteryStatus(int timeout_ms = 1500) = 0;
};

}  // namespace creos
