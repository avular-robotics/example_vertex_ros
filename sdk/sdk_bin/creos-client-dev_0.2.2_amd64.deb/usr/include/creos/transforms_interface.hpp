// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 11
 * Author: Niels Rood
 *
 * @file Header file for transforms interface
 ****************************************************************************/
#pragma once

#include <creos/client_global.hpp>
#include <creos/messages/transform.hpp>
#include <creos/subscription.hpp>

namespace creos {

/**
 * @brief The interface for retrieving information about the relationships
 * between different coordinate frames used within an Avular robot.
 */
class CREOS_CLIENT_API ITransformsInterface {
public:
    static constexpr char name[] = "transforms";
    static constexpr unsigned version = 1;

    virtual ~ITransformsInterface() = default;

    /**
     * @brief Subscribe to transformation frame messages for static transformations.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * The static transformation frame messages contain the transformation between two coordinate frames that do not
     * change.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError If the robot does not provide this data, or the client and agent are incompatible.
     * @throws creos::SubscriptionError If the subscription failed to be created.
     */
    virtual SubscriptionId subscribeToStaticTransforms(
        const std::function<void(const creos_messages::TransformStampedList&)>& callback) = 0;

    /**
     * @brief Subscribe to transformation frame messages for dynamic transformations.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * The dynamic transformation frame messages contain the transformation between two coordinate frames that change.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError If the robot does not provide this data, or the client and agent are incompatible.
     * @throws creos::SubscriptionError If the subscription failed to be created.
     */
    virtual SubscriptionId subscribeToDynamicTransforms(
        const std::function<void(const creos_messages::TransformStampedList&)>& callback) = 0;
};

}  // namespace creos
