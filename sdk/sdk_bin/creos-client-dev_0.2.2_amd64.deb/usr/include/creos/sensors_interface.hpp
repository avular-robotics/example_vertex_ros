// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 18
 * Author: Robbert-Jan de Jager
 *
 * The interface for the sensors of the Avular Robot.
 ****************************************************************************/
#pragma once

#include <creos/client_global.hpp>
#include <creos/messages/barometer.hpp>
#include <creos/messages/controller_state.hpp>
#include <creos/messages/gnss.hpp>
#include <creos/messages/imu.hpp>
#include <creos/messages/interface_info.hpp>
#include <creos/messages/magnetic_field.hpp>
#include <creos/messages/odometry.hpp>
#include <creos/messages/point_cloud2.hpp>
#include <creos/messages/pose.hpp>
#include <creos/messages/range.hpp>
#include <creos/messages/wheel_state.hpp>
#include <creos/subscription.hpp>

namespace creos {

/**
 * @brief The interface for retrieving sensor data from an Avular robot.
 */
class CREOS_CLIENT_API ISensorsInterface {
public:
    static constexpr char name[] = "sensors";
    static constexpr unsigned version = 1;

    virtual ~ISensorsInterface() = default;

    /**
     * @brief Subscribe to the lidar point cloud data.
     * @qualifier Origin
     *
     * The point cloud is a 3D representation of the environment around the robot.
     *
     * @param lidar_id The id of the lidar to subscribe to.
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide lidar point cloud data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeTo3dLidar(
        const creos_messages::Lidar3dId lidar_id,
        const std::function<void(const creos_messages::PointCloud2&)>& callback) = 0;

    /**
     * @brief Subscribe to the odometry data.
     * @qualifier Origin
     *
     * The odometry data contains the estimated position, orientation and velocity of the robot.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide odometry data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToOdometry(
        const std::function<void(const creos_messages::Odometry&)>& callback) = 0;

    /**
     * @brief Subscribe to the global pose data.
     * @qualifier Vertex
     *
     * The global pose data contains the estimated position and orientation of the robot in the global frame.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide global pose data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToPose(
        const std::function<void(const creos_messages::PoseWithCovarianceStamped&)>& callback) = 0;

    /**
     * @brief Subscribe to the GNSS data.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * The GNSS data contains the global position of the robot.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide GNSS data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToGnss(const std::function<void(const creos_messages::Gnss&)>& callback) = 0;

    /**
     * @brief Subscribe to the remote controller state data.
     * @qualifier Origin
     * @qualifier Vertex
     *
     * The remote controller state data contains the state of the buttons and joysticks of the remote controller.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide remote controller state data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToRemoteController(
        const std::function<void(const creos_messages::ControllerState&)>& callback) = 0;

    /**
     * @brief Subscribe to the wheel state data.
     * @qualifier Origin
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide wheel state data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToWheelState(
        const std::function<void(const creos_messages::WheelStates&)>& callback) = 0;

    /**
     * @brief Subscribe to the magnetic field data.
     * @qualifier Vertex
     *
     * The magnetic field data contains the magnetic field strength and direction around the robot.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide magnetic field data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToMagneticField(
        creos_messages::MagneticFieldId magnetic_field_id,
        const std::function<void(const creos_messages::MagneticField&)>& callback) = 0;

    /**
     * @brief Subscribe to the barometer data.
     * @qualifier Vertex
     *
     * The barometer data contains the atmospheric pressure and temperature around the robot.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide barometer data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToBarometer(
        const std::function<void(const creos_messages::Barometer&)>& callback) = 0;

    /**
     * @brief Subscribe to range sensor data.
     * @qualifier Vertex
     *
     * The range data contains the distance to an object in front of the sensor.
     *
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide downward lidar data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToRangeSensor(
        creos_messages::RangeSensorId range_sensor_id,
        const std::function<void(const creos_messages::Range&)>& callback) = 0;

    /**
     * @brief Subscribe to the IMU sensor data.
     * @qualifier Vertex
     *
     * The IMU sensor data contains the acceleration, angular velocity and orientation of the robot.
     *
     * @param imu_id The id of the IMU to subscribe to.
     * @param callback The callback function that will be called when new data is available.
     * @return SubscriptionId The id of the subscription.
     * @throws creos::UnsupportedError if the robot does not provide IMU sensor data.
     * @throws creos::SubscriptionError if the subscription failed.
     */
    virtual SubscriptionId subscribeToImu(const creos_messages::ImuId imu_id,
                                          const std::function<void(const creos_messages::Imu&)>& callback) = 0;
};

}  // namespace creos
