// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 June 19
 * Author: Robbert-Jan de Jager
 *
 * Main header file for the CreOS client library.
 ****************************************************************************/
#pragma once

#include <creos/client_global.hpp>
#include <creos/diagnostics_interface.hpp>
#include <creos/errors.hpp>
#include <creos/power_management_interface.hpp>
#include <creos/sensors_interface.hpp>
#include <creos/setpoint_control_interface.hpp>
#include <creos/subscription.hpp>
#include <creos/system_info_interface.hpp>
#include <creos/transforms_interface.hpp>
#include <memory>
#include <string_view>

/**
 * @namespace creos
 * @brief The main namespace for the CreOS client library.
 */
namespace creos {

/**
 * @page client CreOS C++ Client library
 * @brief The CreOS %Client library is used to interact with Avular robots
 *
 * @section cpp_getting_started Getting started
 * To get started with the CreOS %Client library, you need to first install the
 * library as described in the \ref Installation section. After that, you can
 * add the following to your CMakeLists.txt file to link the library to your
 * CMake target:
 *
 * \dontinclude hello_world/CMakeLists.txt
 * \skipline find_package(creos_client REQUIRED)
 * \skipline add_executable(
 * \skipline target_link_libraries(
 *
 * After that, you can start using the library by including the main header
 * file, and creating an instance of the Client class:
 *
 * \dontinclude hello_world/main.cpp
 * \skipline #include <creos/client.hpp>
 * \skipline int main() {
 * \until creos::Client client
 *
 * The Client class is the main class of the CreOS %Client library. It enables
 * communication with the CreOS Agent running on the robot. You can supply the
 * host address of the robot to the constructor, as well as a port number to
 * connect to. You can also set the CREOS_HOST and CREOS_PORT environment
 * variables to set the default host and port.
 *
 * @section cpp_interfaces Interfaces
 * The Client provides multiple interface handles, each of which exposing a
 * subset of the connected robot's functionality. The following interfaces are
 * available:
 * <table>
 * <tr><td>\ref creos::ISensorsInterface "Sensors"
 *     <td> \copybrief creos::ISensorsInterface
 * <tr><td>\ref creos::IPowerManagementInterface "Power Management"
 *     <td> \copybrief creos::IPowerManagementInterface
 * <tr><td>\ref creos::ISetpointControlInterface "Setpoint Control"
 *     <td> \copybrief creos::ISetpointControlInterface
 * <tr><td>\ref creos::ITransformsInterface "Transforms"
 *     <td> \copybrief creos::ITransformsInterface
 * <tr><td>\ref creos::ISystemInfoInterface "System Info"
 *     <td> \copybrief creos::ISystemInfoInterface
 * <tr><td>\ref creos::IDiagnosticsInterface "Diagnostics"
 *     <td> \copybrief creos::IDiagnosticsInterface
 * </table>
 *
 * More details about each interface can be found in the documentation of their
 * respective interface class.
 *
 * @subsection cpp_interface_functions Interface functions
 * Each interface provides a set of functions to interact with the
 * \ref data_sinks, \ref data_sources, and \ref callables provided by the robot.
 * These signatures of these functions follow common patterns, based on the type
 * of interaction they provide. The patterns are as follows, where \c * is a
 * wildcard:
 *
 * <table>
 * <tr><th>Concept<th>Function name pattern<th>Description
 * <tr>
 *   <td>\ref data_sinks</td>
 *   <td>\c publish*</td>
 *   <td>These functions take the data to send as their only argument. If
 *       somehow the publication of the data fails, these functions will throw
 *       a \ref creos::PublicationError.</td>
 * </tr>
 * <tr>
 *   <td rowspan="2">\ref data_sources</td>
 *   <td>\c subscribe*</td>
 *   <td>All these functions take a \c callback function as an
 *       argument, which will be called when new data is available. The data is
 *       passed to the callback function as its first and only argument. Some
 *       \ref data_sources provide multiple data streams, e.g. the IMU
 *       interface provides data from multiple IMUs. In these cases, the
 *       function will take an additional \c *id argument to specify which data
 *       stream to subscribe to. If the subscription fails, these functions will
 *       throw a \ref creos::SubscriptionError.</td>
 * </tr>
 * <tr>
 *   <td>\c get*</td>
 *   <td>Convenience functions used to pull information once
 *       from \ref data_sources. They return the data that was pulled. These
 *       functions also take an optional \c timeout_ms argument, which can be
 *       used to time out the request if no data is not received within the
 *       specified amount of milliseconds. If the timeout is reached, these
 *       functions will throw a \ref creos::TimeoutError.</td>
 * </tr>
 * <tr>
 *   <td>\ref callables</td>
 *   <td>\c *</td>
 *   <td>These functions take the callable's required arguments as their
 *       arguments, and return the callable's return value. These functions also
 *       take an optional \c timeout_ms argument, which can be used to time out
 *       the request if the callable does not complete within the specified
 *       amount of milliseconds. If the timeout is reached, these functions will
 *       throw a \ref creos::TimeoutError.</td>
 * </tr>
 * </table>
 *
 * All of these functions use message types as provided in the
 * \ref creos_messages namespace for passing around data.
 *
 * @subsection cpp_compatibility Compatibility
 * Not all robots support all interfaces; if the robot you are a connecting to
 * does not support an interface, the Client will provide a \c nullptr reference
 * when you request the interface. Some specific \ref data_sinks,
 * \ref data_sources, and \ref callables may also not be supported by the robot.
 * In these cases, their respective functions will throw an
 * \ref creos::UnsupportedError.
 */

class ClientImpl;

/**
 * @brief The client class.
 *
 * This class is used to interact with the CreOS Agent.
 */
class CREOS_CLIENT_API Client {
public:
    /**
     * @brief Constructor for the client.
     *
     * This constructor creates a new client object and connects to the specified host and port.
     *
     * @param host The host to connect to.
     * @param port The port to connect to.
     * @throws creos::ConnectionError If the client could not connect to the host.
     */
    Client(std::string_view host, unsigned port);

    /**
     * @brief Constructor for the client.
     *
     * This constructor creates a new client object and connects to the specified host using the
     * default port. You can change the default port by setting the CREOS_PORT environment variable.
     *
     * @param host The host to connect to.
     * @throws creos::ConnectionError If the client could not connect to the host.
     */
    Client(std::string_view host);

    /**
     * @brief Default constructor for the client.
     *
     * This constructor creates a new client object and connects to the default host and port.
     * You can change the default host and port by setting the CREOS_HOST and CREOS_PORT environment
     * variables.
     */
    Client();
    ~Client();

    /**
     * @brief Unsubscribe from a data source.
     * @param id The subscription ID.
     *
     * @throws InvalidArgumentError If the subscription ID is invalid.
     */
    void unsubscribe(SubscriptionId id);

    /**
     * @brief Get the sensors interface.
     *
     * The sensors interface is used to get sensor data from sensors on the robot.
     *
     * @return The sensors interface. It may return \c nullptr if the interface is not available.
     */
    ISensorsInterface* sensors();
    const ISensorsInterface* sensors() const;

    /**
     * @brief Get the power management interface.
     *
     * The power management interface is used to control the power state of the robot. It can be used to put the robot
     * into a low power mode to conserve energy.
     *
     * @return The power management interface. It may return \c nullptr if the interface is not available.
     */
    IPowerManagementInterface* power_management();
    const IPowerManagementInterface* power_management() const;

    /**
     * @brief Get the setpoint control interface.
     *
     * The setpoint control interface is used to send setpoint control commands to the robot.
     *
     * @return The setpoint control interface. It may return \c nullptr if the interface is not available.
     */
    ISetpointControlInterface* setpoint_control();
    const ISetpointControlInterface* setpoint_control() const;

    /**
     * @brief Get the transforms interface.
     *
     * The transforms interface is used to get information about the relationships between different coordinate frames.
     * A coordinate frame is a frame of reference used to define the position and orientation of different parts of the
     * robot.
     *
     * The transformations can be static or dynamic. Static transformations do not change often, like the
     * transformation from the main body of the robot to a fixed sensor. Dynamic transformations can change
     * continuously, like the transformation from the main body of the robot to the tip of a mounted robot arm.
     *
     * @return The transforms interface. It may return \c nullptr if the interface is not available.
     */
    ITransformsInterface* transforms();
    const ITransformsInterface* transforms() const;

    /**
     * @brief Get the system info interface.
     *
     * The system info interface is used to get information about the robot, like the name and serial number.
     *
     * @return The system info interface. It may return \c nullptr if the interface is not available.
     */
    ISystemInfoInterface* system_info();
    const ISystemInfoInterface* system_info() const;

    /**
     * @brief Get the diagnostics interface.
     *
     * The diagnostics interface is used to get diagnostic information from the robot. This information can be used to
     * monitor the health of the robot and detect any issues that may arise.
     *
     * @return The diagnostics interface. It may return \c nullptr if the interface is not available.
     */
    IDiagnosticsInterface* diagnostics();
    const IDiagnosticsInterface* diagnostics() const;

private:
    /// @cond INTERNAL
    friend ClientImpl& getImplFromClient(Client& client);
    friend const ClientImpl& getImplFromClient(const Client& client);
    /// @endcond

    std::unique_ptr<ClientImpl> impl_;

    ClientImpl& impl() { return *impl_; }

    const ClientImpl& impl() const { return *impl_; }
};

}  // namespace creos
