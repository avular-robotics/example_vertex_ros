// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 08
 * Author: Bram Tertoolen
 *
 * @file Generic message constructs that are used in multiple messages.
 ****************************************************************************/
#pragma once

#include <cassert>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

/**
 * @namespace creos_messages Message definitions
 * @brief The messages that are used in the communication between the agent and the client.
 *
 * The messages are defined in the creos_messages namespace.
 */
namespace creos_messages {

/**
 * @brief Point message containing a x, y and z of type double
 */
struct Point {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;

    /**
     * @brief Compare two Point messages
     */
    auto operator<=>(const Point& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Point, x, y, z);

/**
 * @brief Vector3d message containing a x, y and z of type double
 */
struct Vector3d {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;

    /**
     * @brief Compare two Vector3d messages
     */
    auto operator<=>(const Vector3d& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Vector3d, x, y, z);

/**
 * @brief Vector3f message containing a x, y and z of type float
 */
struct Vector3f {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;

    /**
     * @brief Compare two Vector3f messages
     */
    auto operator<=>(const Vector3f& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Vector3f, x, y, z);

/**
 * @brief Quaternion message containing the x, y, z and w components as doubles
 */
struct Quaterniond {
    double x = 0.0;
    double y = 0.0;
    double z = 0.0;
    double w = 1.0;

    /**
     * @brief Compare two Quaterniond messages
     */
    auto operator<=>(const Quaterniond& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Quaterniond, x, y, z, w);

/**
 * @brief Quaternion message containing the x, y, z and w components as floats
 */
struct Quaternionf {
    float x = 0.0f;
    float y = 0.0f;
    float z = 0.0f;
    float w = 1.0f;

    /**
     * @brief Compare two Quaternionf messages
     */
    auto operator<=>(const Quaternionf& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Quaternionf, x, y, z, w);

/**
 * @brief Matrix template for a 2D array of type T
 */
template <typename T, std::size_t n_rows, std::size_t n_cols>
class Matrix {
public:
    /**
     * @brief Default constructor
     * @details Initializes the matrix with zeros
     */
    Matrix() = default;

    /**
     * @brief Constructor from 2D array
     * @param data The 2D array to initialize the matrix with
     */
    Matrix(const std::array<std::array<T, n_cols>, n_rows>& data) : data_(data) {}

    /**
     * @brief Constructor from 1D array
     * @param array The 1D array to initialize the matrix with
     */
    Matrix(const std::array<T, n_rows * n_cols>& array) {
        for (std::size_t i = 0; i < n_rows; ++i) {
            for (std::size_t j = 0; j < n_cols; ++j) {
                data_[i][j] = array[i * n_cols + j];
            }
        }
    }

    /**
     * @brief Constructor from initializer list
     * @param init The initializer list to initialize the matrix with
     */
    Matrix(std::initializer_list<T> init) {
        assert(init.size() == n_rows * n_cols);
        std::size_t i = 0;
        for (const auto& value : init) {
            data_[i / n_cols][i % n_cols] = value;
            ++i;
        }
    }

    /**
     * @brief Constructor from initializer list of initializer lists
     * @param init The initializer list of initializer lists to initialize the matrix with
     */
    Matrix(std::initializer_list<std::initializer_list<T>> init) {
        assert(init.size() == n_rows);
        std::size_t i = 0;
        for (const auto& row : init) {
            assert(row.size() == n_cols);
            std::copy(row.begin(), row.end(), data_[i].begin());
            ++i;
        }
    }

    /**
     * @brief Transform constructor from another type of array
     * @tparam U The type of the input array
     * @param array The array to initialize the matrix with
     */
    template <typename U>
    Matrix(const std::array<U, n_rows * n_cols>& array) {
        for (std::size_t i = 0; i < n_rows; ++i) {
            for (std::size_t j = 0; j < n_cols; ++j) {
                data_[i][j] = static_cast<T>(array[i * n_cols + j]);
            }
        }
    }

    /**
     * @brief Convert the matrix to a 1D array
     * @return The 1D array representation of the matrix
     */
    std::array<T, n_rows * n_cols> toArray() const {
        std::array<T, n_rows * n_cols> array;
        for (std::size_t i = 0; i < n_rows; ++i) {
            for (std::size_t j = 0; j < n_cols; ++j) {
                array[i * n_cols + j] = data_[i][j];
            }
        }
        return array;
    }

    /**
     * @brief Transform the matrix to another type of array
     */
    template <typename U>
    std::array<U, n_rows * n_cols> transformToArray() const {
        std::array<U, n_rows * n_cols> array;
        for (std::size_t i = 0; i < n_rows; ++i) {
            for (std::size_t j = 0; j < n_cols; ++j) {
                array[i * n_cols + j] = static_cast<U>(data_[i][j]);
            }
        }
        return array;
    }

    /**
     * @brief Access the elements of the matrix
     * @param index The index of the row
     * @return The row of the matrix
     */
    std::array<T, n_cols>& operator[](std::size_t index) { return data_[index]; }

    /**
     * @brief Access the elements of the matrix
     * @param index The index of the row
     * @return The row of the matrix
     */
    const std::array<T, n_cols>& operator[](std::size_t index) const { return data_[index]; }

    /**
     * @brief Compare two Matrix messages
     */
    auto operator<=>(const Matrix& other) const = default;

    /**
     * @brief Returns a constant iterator to the beginning of the matrix
     * @return Constant iterator to the beginning of the matrix
     */
    auto begin() const { return data_.begin(); }

    /**
     * @brief Returns a constant iterator to the end of the matrix
     * @return Constant iterator to the end of the matrix
     */
    auto end() const { return data_.end(); }

private:
    std::array<std::array<T, n_cols>, n_rows> data_;
};

// to_json function for Matrix
template <typename T, std::size_t n_rows, std::size_t n_cols>
void to_json(nlohmann::json& j, const Matrix<T, n_rows, n_cols>& matrix) {
    j = nlohmann::json::array();
    for (const auto& row : matrix) {
        j.push_back(row);
    }
}

// from_json function for Matrix
template <typename T, std::size_t n_rows, std::size_t n_cols>
void from_json(const nlohmann::json& j, Matrix<T, n_rows, n_cols>& matrix) {
    for (std::size_t i = 0; i < n_rows; ++i) {
        for (std::size_t k = 0; k < n_cols; ++k) {
            matrix[i][k] = j[i][k].get<T>();
        }
    }
}

/**
 * @brief Matrix template for a 2D array of doubles
 */
template <std::size_t n_rows, std::size_t n_cols>
using Matrixd = Matrix<double, n_rows, n_cols>;

/**
 * @brief Matrix template for a 2D array of floats
 */
template <std::size_t n_rows, std::size_t n_cols>
using Matrixf = Matrix<float, n_rows, n_cols>;

}  // namespace creos_messages
