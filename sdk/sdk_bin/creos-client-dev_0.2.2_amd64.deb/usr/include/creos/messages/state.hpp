// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 16
 * Author: Niels Rood
 *
 * @file Messages representing the overall state of the robot
 ****************************************************************************/
#pragma once

#include <nlohmann/json.hpp>
#include <string>
#include <variant>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief The state of the robot
 */
struct State {
    enum class Ready {
        kUnknown = -1,  ///< The ready state is unknown.
        kNotReady,      ///< The robot is not ready to perform operations. e.g. when the robot is booting.
        kPreArm,  ///< The robot is in a safety state where checks are being performed. User interaction may be required.
        kActive,    ///< The robot is ready to perform operations.
        kWaiting,   ///< The robot is operational, but waiting for user input.
        kFailsafe,  ///< A safety system has been triggered, and the robot is in a failsafe state.
        kError,  ///< The robot has a platform error and is not able to perform operations. This should not be used for soft-failures like failed to plan a path, but for things like hardware failure or software crash. User interaction is probably required.
    };

    /**
     * @brief The moment in time when the state was last updated
     */
    creos::RobotClock::time_point time;

    /**
     * @brief The ready state of the robot
     */
    Ready ready_state = Ready::kUnknown;

    /**
     * @brief A textual description of the current action the robot is performing
     */
    std::string current_action;

    /**
     * @brief Compare two messages
     */
    auto operator<=>(const State& other) const = default;
};

NLOHMANN_JSON_SERIALIZE_ENUM(State::Ready, {
                                               {State::Ready::kUnknown, "unknown"},
                                               {State::Ready::kNotReady, "not_ready"},
                                               {State::Ready::kPreArm, "pre_arm"},
                                               {State::Ready::kActive, "active"},
                                               {State::Ready::kWaiting, "waiting"},
                                               {State::Ready::kFailsafe, "failsafe"},
                                               {State::Ready::kError, "error"},
                                           })

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(State, time, ready_state, current_action)

}  // namespace creos_messages
