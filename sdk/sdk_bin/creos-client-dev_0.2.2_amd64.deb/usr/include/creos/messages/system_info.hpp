// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 31
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the SystemInfo message.
 ****************************************************************************/
#pragma once

#include <nlohmann/json.hpp>
#include <string>

namespace creos_messages {

/**
 * @brief A component with its version
 */
struct ComponentVersion {
    enum Type {
        kUnknown,    ///< Unknown type
        kOs,         ///< Operating system
        kContainer,  ///< Container
    };

    std::string name;      ///< The name of the component
    std::string version;   ///< The version of the component
    Type type = kUnknown;  ///< The type of the component

    auto operator<=>(const ComponentVersion&) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(ComponentVersion, name, version, type)

/**
 * @brief System info message containing information about the connected system
 */
struct SystemInfo {

    std::string name;      ///< The human readable name of the robot
    std::string hostname;  ///< The hostname of the robot, to be used for network communication
    std::string serial;    ///< The serial number of the robot
    std::string platform;  ///< What robot platform this is. e.g. "Origin" or "Vertex"

    std::vector<ComponentVersion> component_versions;  ///< A list of components with their versions

    auto operator<=>(const SystemInfo&) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(SystemInfo, name, hostname, serial, platform, component_versions)

}  // namespace creos_messages
