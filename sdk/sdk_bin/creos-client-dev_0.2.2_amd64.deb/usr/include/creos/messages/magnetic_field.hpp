// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 22
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the magnetic field message.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief Magnetic field message containing the magnetic field strength
 */
struct MagneticField {

    /**
     * Timestamp of the magnetic field
     */
    creos::RobotClock::time_point timestamp;

    /**
     * Frame id of the magnetic field
     */
    std::string frame_id;

    /**
     * Strength of the magnetic field in the x, y and z direction in tesla [T]
     */
    Vector3f field = {0, 0, 0};

    /**
     * @brief Covariance matrix of the magnetic field
     */
    Matrixf<3, 3> covariance;

    /**
     * @brief Compare two Pose messages
     */
    auto operator<=>(const MagneticField& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(MagneticField, timestamp, field, covariance)

/**
 * @brief The MagneticFieldId enum contains the different magnetic field sensors that can be used.
 */
enum class MagneticFieldId {
    kBody,  ///< Magnetic field sensor on the body of the robot
};

}  // namespace creos_messages

DEFINE_ENUM_STRING_CONVERSIONS(creos_messages::MagneticFieldId, {{creos_messages::MagneticFieldId::kBody, "body"}})
