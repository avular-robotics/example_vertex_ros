// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 22
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the range message.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

#include "generic.hpp"

namespace creos_messages {

/**
 * @brief Range message containing the range measurement of a sensor
 */
struct Range {

    enum Type {
        kUnknown = -1,
        kUltrasonic = 0,
        kInfrared,
    };

    /**
     * @brief Timestamp of the range measurement
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the sensor
     */
    std::string frame_id;

    /**
     * @brief Type of the range sensor
     */
    Type type = kUnknown;

    /**
     * @brief Range measurement [m]
     */
    float range = 0;

    /**
     * @brief Field of view of the sensor [rad]
     */
    float field_of_view = 0;

    /**
     * @brief minimum range of the sensor [m]
     */
    float min_range = 0;

    /**
     * @brief maximum range of the sensor [m]
     */
    float max_range = INFINITY;

    /**
     * @brief Compare two messages
     */
    auto operator<=>(const Range& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Range, timestamp, type, range, field_of_view, min_range, max_range)

/**
 * @brief Range sensor id
 */
enum class RangeSensorId {
    kDownwardsLidar = 0,  ///< Downwards facing lidar
};

}  // namespace creos_messages

DEFINE_ENUM_STRING_CONVERSIONS(creos_messages::RangeSensorId,
                               {{creos_messages::RangeSensorId::kDownwardsLidar, "downwards_lidar"}})
