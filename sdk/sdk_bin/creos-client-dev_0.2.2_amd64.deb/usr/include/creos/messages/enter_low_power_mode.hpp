#pragma once

#include <stdint.h>
#include <creos/robot_clock.hpp>
#include <nlohmann/detail/macro_scope.hpp>
#include <nlohmann/json.hpp>

/**
 * @brief The messages that are used in the communication between the agent and the client.
 */
namespace creos_messages::enter_low_power_mode {

/**
 * @brief The Request message contains the request to enter low power mode.
 */
struct Request {
    /**
     * @brief At what time the robot should exit low power mode.
     *
     * Set to 0 to disable automatic exit of low power mode.
     * Else, specify a time in seconds since epoch in UTC.
     */
    creos::RobotClock::time_point wake_up_time = creos::RobotClock::time_point{std::chrono::nanoseconds{0}};
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Request, wake_up_time)

}  // namespace creos_messages::enter_low_power_mode
