// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 August 21
 * Author: Robbert-Jan de Jager
 *
 * Error message to communicate that contains an error code and a message.
 ****************************************************************************/
#pragma once

#include <nlohmann/json.hpp>

namespace creos_messages {

/**
 * @brief Error codes that indicate what went wrong.
 */
enum class ErrorCode {
    kUnknown = 0,         ///< Unknown error
    kSuccess = 1,         ///< Success (no error)
    kTimeout = 2,         ///< The request timed out
    kTransportError = 3,  ///< There was an error while transporting the message to the other side
    kInvalidRequest = 4,  ///< The request was invalid, probably indicates a bug in the client
    kNotExecuted = 5,     ///< The request was not executed. Try looking at the message for more information
};

/**
 * @brief Error message to communicate that contains an error code and a message.
 */
struct Error {
    /**
     * @brief The error code.
     */
    ErrorCode code;

    /**
     * @brief The error message.
     */
    std::string message;

    /**
     * @brief Compare two Error messages
     */
    auto operator<=>(const Error& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Error, code, message)
}  // namespace creos_messages
