// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 October 1
 * Author: Niels Rood
 *
 * @file SDK information message containing information about the entire interface
 ****************************************************************************/
#pragma once

#include <compare>
#include <nlohmann/json.hpp>

#include "interface_group_info.hpp"

namespace creos_messages {

/**
 * @brief SDK information message containing information about the entire interface
 */
struct InterfaceInfo {

    /**
     * @brief Version of the interface
     */
    std::string version;

    /**
     * @brief Interface groups of the interface
     */
    std::vector<InterfaceGroupInfo> interface_groups;

    /**
     * @brief Compare two InterfaceInfo object messages
     */
    auto operator<=>(const InterfaceInfo& other) const = default;

    /**
     * @brief Check if two InterfaceInfo object messages are equal
     */
    bool operator==(const InterfaceInfo& other) const { return version == other.version; };

    /**
     * @brief Check if two InterfaceInfo object messages are not equal
     */
    bool operator!=(const InterfaceInfo& other) const { return !(*this == other); };
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(InterfaceInfo, version, interface_groups)

}  // namespace creos_messages
