// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 December 12
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the PublicationAttachment message.
 ****************************************************************************/
#pragma once

#include <array>
#include <compare>
#include <nlohmann/json.hpp>

namespace creos_messages::detail {
/**
 * @brief PublicationAttachment message contains additional information that is attached to a publication.
 */
struct PublicationAttachment {

    std::string src;        ///< The source of the data
    std::string data_type;  ///< The type of the data
    int data_kind;          ///< The kind of the data

    /**
     * @brief Compare two PublicationAttachment messages
     */
    auto operator<=>(const PublicationAttachment& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(PublicationAttachment, src, data_type, data_kind)

}  // namespace creos_messages::detail
