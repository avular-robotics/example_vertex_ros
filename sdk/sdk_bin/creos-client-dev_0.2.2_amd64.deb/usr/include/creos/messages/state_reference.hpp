// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 23
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the state reference message.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

#include "accel.hpp"
#include "generic.hpp"
#include "pose.hpp"
#include "twist.hpp"

namespace creos_messages {

/**
 * @brief State reference message containing the pose, velocity and acceleration of the robot
 */
struct StateReference {
    enum class TranslationMode {
        kUnknown,      // Unknown translation mode.
        kPosition,     // Position reference (velocity and acceleration can be provided as feed-forward).
        kVelocity,     // Velocity reference (acceleration can be provided as feed-forward).
        kAcceleration  // Acceleration reference.
    };

    enum class OrientationMode {
        kUnknown,          // Unknown orientation mode.
        kAttitude,         // Attitude reference (angular velocity and accelerations can be provided as feed-forward).
        kAngularVelocity,  // Angular rate reference (angular acceleration can be provided as feed-forward).
        kAngularAcceleration  // Angular acceleration reference.
    };

    /**
     * @brief Timestamp of the state reference
     */
    creos::RobotClock::time_point timestamp;

    /**
     * @brief Frame id of the state reference
     */
    std::string frame_id;

    /**
     * @brief Pose of the robot
     */
    creos_messages::Pose pose;

    /**
     * @brief Velocity of the robot
     */
    creos_messages::Twist velocity;

    /**
     * @brief Acceleration of the robot
     */
    creos_messages::Accel acceleration;

    /**
     * @brief Translation mode of the state reference
     */
    TranslationMode translation_mode = TranslationMode::kUnknown;

    /**
     * @brief Orientation mode of the state reference
     */
    OrientationMode orientation_mode = OrientationMode::kUnknown;

    auto operator<=>(const StateReference& other) const = default;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(StateReference, timestamp, frame_id, pose, velocity, acceleration, translation_mode,
                                   orientation_mode)

}  // namespace creos_messages
