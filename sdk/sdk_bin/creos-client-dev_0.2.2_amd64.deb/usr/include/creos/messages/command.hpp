// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 July 23
 * Author: Robbert-Jan de Jager
 *
 * Implementation of the command message.
 ****************************************************************************/
#pragma once

#include <array>
#include <creos/robot_clock.hpp>
#include <nlohmann/json.hpp>

namespace creos_messages {

/**
 * @brief Command message containing the command to send to the robot
 */
struct Command {
    enum class Action {
        kUnknown,
        kArm,
        kDisarm,
        kTakeOff,
        kLand,
        kEmergencyLand,
        kKillSwitch,
        kAbortCurrentAction,
    };

    /**
     * @brief Construct action
     */
    Action action = Action::kUnknown;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(Command, action)

/**
 * @brief Command message containing the command to send to the robot, with a timestamp
 */
struct CommandStamped : public Command {
    /**
     * @brief Timestamp of the command
     */
    creos::RobotClock::time_point timestamp;
};

NLOHMANN_DEFINE_TYPE_NON_INTRUSIVE(CommandStamped, action, timestamp)

}  // namespace creos_messages
