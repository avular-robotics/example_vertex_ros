// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 November 08
 * Author: Robbert-Jan de Jager
 *
 * Implementation of helper methods to convert between enums and strings.
 ****************************************************************************/
#pragma once

#include <type_traits>

namespace creos {

/**
 * @brief Convert an enum value to a string.
 *
 * @tparam T The enum type.
 * @param value The enum value.
 * @return std::string The string representation of the enum value.
 * @throws std::invalid_argument If the enum value is not found.
 */
template <typename T>
std::string to_string(T value) = delete;

/**
 * @brief Convert a string to an enum value.
 *
 * @tparam T The enum type.
 * @param str The string representation of the enum value.
 * @return T The enum value.
 * @throws std::invalid_argument If the string is not found.
 */
template <typename T>
T from_string(const std::string_view& str) = delete;

template <>
inline std::string to_string(const std::string_view& value) {
    return std::string(value);
}

/**
 * @brief Define the string conversions for an enum type.
 *
 * @param EnumType The enum type.
 * @param ... The enum values and their string representations.
 *
 * Example:
 * @code
 * enum class MyEnum {
 *    kValue1,
 *   kValue2,
 * };
 *
 * DEFINE_ENUM_STRING_CONVERSIONS(MyEnum, {{MyEnum::kValue1, "value1"}, {MyEnum::kValue2, "value2"}});
 * @endcode
 */
#define DEFINE_ENUM_STRING_CONVERSIONS(EnumType, ...)                                                    \
    template <>                                                                                          \
    inline std::string creos::to_string(EnumType value) {                                                \
        static_assert(std::is_enum_v<EnumType>, "EnumType must be an enum");                             \
        static const std::pair<EnumType, std::string> m[] = __VA_ARGS__;                                 \
        auto it = std::find_if(std::begin(m), std::end(m),                                               \
                               [value](const auto& ej_pair) -> bool { return ej_pair.first == value; }); \
        if (it == std::end(m)) {                                                                         \
            throw std::invalid_argument("Invalid enum value");                                           \
        }                                                                                                \
        return it->second;                                                                               \
    }                                                                                                    \
                                                                                                         \
    template <>                                                                                          \
    inline EnumType creos::from_string(const std::string_view& str) {                                    \
        static_assert(std::is_enum_v<EnumType>, "EnumType must be an enum");                             \
        static const std::pair<EnumType, std::string> m[] = __VA_ARGS__;                                 \
        auto it = std::find_if(std::begin(m), std::end(m),                                               \
                               [str](const auto& ej_pair) -> bool { return ej_pair.second == str; });    \
        if (it == std::end(m)) {                                                                         \
            throw std::invalid_argument("Invalid enum value");                                           \
        }                                                                                                \
        return it->first;                                                                                \
    }

}  // namespace creos
