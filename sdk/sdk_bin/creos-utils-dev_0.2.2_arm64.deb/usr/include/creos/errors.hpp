// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 June 21
 * Author: Robbert-Jan de Jager
 *
 * @file This header file declares the possible errors that can occur in the CreOS
 * client library.
 *
 ****************************************************************************/
#pragma once

#include <creos/messages/error.hpp>
#include <creos/utils_global.hpp>
#include <exception>
#include <source_location>
#include <string>

namespace creos {

/**
 * @brief Exception class for the CreOS client library.
 *
 * This class is used to throw exceptions in the CreOS client library.
 */
class CREOS_UTILS_API Exception : public std::exception {
public:
    Exception(const std::string& message) : message_(message) {}

    Exception(const Exception& other) : message_(other.message_) {}

    virtual ~Exception() = default;

    /**
   * @brief Returns the error message.
   */
    const char* what() const noexcept override { return message_.c_str(); }

private:
    std::string message_;
};

/**
 * @brief Connection error.
 *
 * This error is thrown when a connection to the CreOS server could not be
 * established, or there was an error communicating with the server.
 */
class CREOS_UTILS_API ConnectionError : public Exception {
public:
    ConnectionError(const std::string& message) : Exception(message) {}

    ~ConnectionError() override = default;
};

/**
 * @brief The function is not implemented.
 */
class CREOS_UTILS_API NotImplementedError : public Exception {
public:
    NotImplementedError(const std::string& message = std::source_location::current().function_name())
        : Exception(message) {}

    ~NotImplementedError() override = default;
};

/**
 * @brief Invalid argument error.
 */
class CREOS_UTILS_API InvalidArgumentError : public Exception {
public:
    InvalidArgumentError(const std::string& message) : Exception(message) {}

    ~InvalidArgumentError() override = default;
};

/**
 * @brief Timeout error.
 *
 * This error is thrown when a timeout occurs.
 */
class CREOS_UTILS_API TimeoutError : public Exception {
public:
    TimeoutError(const std::string& message) : Exception(message) {}

    ~TimeoutError() override = default;
};

/**
 * @brief Value that indicates an error.
 */
using ErrorCode = creos_messages::ErrorCode;

/**
 * @brief Service call failure.
 *
 * This error is thrown when a service call fails.
 */
class CREOS_UTILS_API ServiceCallError : public Exception {
public:
    ServiceCallError(ErrorCode code, const std::string& message) : Exception(message), code_(code) {}

    ~ServiceCallError() override = default;

    ErrorCode code() const { return code_; }

private:
    ErrorCode code_{ErrorCode::kUnknown};
};

/**
 * @brief A part of the API is not supported by the connected robot.
 */
class CREOS_UTILS_API UnsupportedError : public Exception {
public:
    UnsupportedError(const std::string& message) : Exception(message) {}

    ~UnsupportedError() override = default;
};

/**
 * @brief Something already exists when trying to create it.
 */
class CREOS_UTILS_API AlreadyExistsError : public Exception {
public:
    AlreadyExistsError(const std::string& message) : Exception(message) {}

    ~AlreadyExistsError() override = default;
};

/**
 * @brief An error occurred while publishing data.
 */
class CREOS_UTILS_API PublicationError : public Exception {
public:
    PublicationError(const std::string& message) : Exception(message) {}

    ~PublicationError() override = default;
};

/**
 * @brief An error occurred while subscribing to data.
 */
class CREOS_UTILS_API SubscriptionError : public Exception {
public:
    SubscriptionError(const std::string& message) : Exception(message) {}

    ~SubscriptionError() override = default;
};

}  // namespace creos
