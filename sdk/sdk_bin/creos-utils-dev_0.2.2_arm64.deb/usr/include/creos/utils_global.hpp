// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 June 19
 * Author: Robbert-Jan de Jager
 *
 * Common header file for the CreOS library.
 ****************************************************************************/
#pragma once

// Define the export/import macro for the library
// Shared libraries on linux by default export all symbols. This can cause
// problems when linking with other shared libraries that have the same symbol
// names. To prevent this, we use the visibility attribute to only export the
// symbols that we want to export.
// On Windows, this is the default behavior.
// The CREOS_UTILS_API macro must be added to all classes and functions that
// need to be exported from the library. This macro will set the visibility of
// the symbol to be public.
// In practice when building the library we must export the symbol, but users
// of the library must import the symbol. The CREOS_UTILS_EXPORTS macro
// controls this behavior.

#ifdef WIN32

#ifdef CREOS_UTILS_EXPORTS
#define CREOS_UTILS_API __declspec(dllexport)
#else
#define CREOS_UTILS_API __declspec(dllimport)
#endif

#else

#ifdef CREOS_UTILS_EXPORTS
#define CREOS_UTILS_API __attribute__((visibility("default")))
#else
#define CREOS_UTILS_API
#endif

#endif
