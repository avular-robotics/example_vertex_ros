// Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
// You may use this code under the terms of the Avular
// Software End-User License Agreement.
//
// You should have received a copy of the Avular
// Software End-User License Agreement license with
// this file, or download it from: avular.com/eula
//
/*****************************************************************************
 * Created on: 2024 August 21
 * Author: Robbert-Jan de Jager
 *
 * Helpers to get information about functions.
 ****************************************************************************/
#pragma once

namespace creos {
template <typename T>
struct function_traits {
private:
    using call_type = function_traits<decltype(&T::operator())>;

public:
    using return_type = typename call_type::return_type;
    using arguments = typename call_type::arguments;
    static constexpr std::size_t arity = call_type::arity;

    template <std::size_t N>
    struct arg {
        static_assert(N < arity, "error: invalid parameter index.");
        using type = typename call_type::template arg<N>::type;
    };
};

template <typename T>
struct function_traits<T&> : function_traits<T> {};

template <typename T>
struct function_traits<T&&> : function_traits<T> {};

// Function pointer
template <typename R, typename... Args>
struct function_traits<R (*)(Args...)> : function_traits<R(Args...)> {};

// Member function pointer
template <typename C, typename R, typename... Args>
struct function_traits<R (C::*)(Args...)> : function_traits<R(Args...)> {};

// Const member function pointer
template <typename C, typename R, typename... Args>
struct function_traits<R (C::*)(Args...) const> : function_traits<R(Args...)> {};

template <typename R, typename... Args>
struct function_traits<R(Args...)> {
    using return_type = R;
    using arguments = std::tuple<Args...>;
    static constexpr std::size_t arity = sizeof...(Args);

    template <std::size_t N>
    struct arg {
        static_assert(N < arity, "error: invalid parameter index.");
        using type = typename std::tuple_element<N, std::tuple<Args...>>::type;
    };
};

template <typename T, typename = void()>
struct get_arg0 {
    using type = void;
};

template <typename T>
    requires(function_traits<T>::arity > 0)
struct get_arg0<T> {
    using type = typename function_traits<T>::template arg<0>::type;
};

template <typename T>
using get_arg0_t = get_arg0<T>::type;

// Test cases for function_traits
static_assert(std::is_same_v<function_traits<void(int, double)>::return_type, void>);
static_assert(std::is_same_v<function_traits<void(int, double)>::arguments, std::tuple<int, double>>);
static_assert(function_traits<void(int, double)>::arity == 2);
static_assert(std::is_same_v<function_traits<void(int, double)>::arg<0>::type, int>);
static_assert(std::is_same_v<function_traits<void(int, double)>::arg<1>::type, double>);
static_assert(std::is_same_v<function_traits<decltype([](int, double) { return 0; })>::return_type, int>);
static_assert(
    std::is_same_v<function_traits<decltype([](int, double) { return 0; })>::arguments, std::tuple<int, double>>);
static_assert(function_traits<decltype([](int, double) { return 0; })>::arity == 2);
static_assert(std::is_same_v<function_traits<decltype([](int, double) { return 0; })>::arg<0>::type, int>);
static_assert(std::is_same_v<function_traits<decltype([](int, double) { return 0; })>::arg<1>::type, double>);
static_assert(std::is_same_v<function_traits<std::function<void(int, double)>>::return_type, void>);
static_assert(std::is_same_v<function_traits<std::function<void(int, double)>>::arguments, std::tuple<int, double>>);
static_assert(function_traits<std::function<void(int, double)>>::arity == 2);
static_assert(std::is_same_v<function_traits<std::function<void(int, double)>>::arg<0>::type, int>);
static_assert(std::is_same_v<function_traits<std::function<void(int, double)>>::arg<1>::type, double>);
static_assert(std::is_same_v<function_traits<void (*)(int, double)>::return_type, void>);
static_assert(std::is_same_v<function_traits<void (*)(int, double)>::arguments, std::tuple<int, double>>);
static_assert(function_traits<void (*)(int, double)>::arity == 2);
static_assert(std::is_same_v<function_traits<void (*)(int, double)>::arg<0>::type, int>);
static_assert(std::is_same_v<function_traits<void (*)(int, double)>::arg<1>::type, double>);

}  // namespace creos
