// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from creos_sdk_msgs:msg/SystemInfo.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__BUILDER_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "creos_sdk_msgs/msg/detail/system_info__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace creos_sdk_msgs
{

namespace msg
{

namespace builder
{

class Init_SystemInfo_component_versions
{
public:
  explicit Init_SystemInfo_component_versions(::creos_sdk_msgs::msg::SystemInfo & msg)
  : msg_(msg)
  {}
  ::creos_sdk_msgs::msg::SystemInfo component_versions(::creos_sdk_msgs::msg::SystemInfo::_component_versions_type arg)
  {
    msg_.component_versions = std::move(arg);
    return std::move(msg_);
  }

private:
  ::creos_sdk_msgs::msg::SystemInfo msg_;
};

class Init_SystemInfo_platform
{
public:
  explicit Init_SystemInfo_platform(::creos_sdk_msgs::msg::SystemInfo & msg)
  : msg_(msg)
  {}
  Init_SystemInfo_component_versions platform(::creos_sdk_msgs::msg::SystemInfo::_platform_type arg)
  {
    msg_.platform = std::move(arg);
    return Init_SystemInfo_component_versions(msg_);
  }

private:
  ::creos_sdk_msgs::msg::SystemInfo msg_;
};

class Init_SystemInfo_serial
{
public:
  explicit Init_SystemInfo_serial(::creos_sdk_msgs::msg::SystemInfo & msg)
  : msg_(msg)
  {}
  Init_SystemInfo_platform serial(::creos_sdk_msgs::msg::SystemInfo::_serial_type arg)
  {
    msg_.serial = std::move(arg);
    return Init_SystemInfo_platform(msg_);
  }

private:
  ::creos_sdk_msgs::msg::SystemInfo msg_;
};

class Init_SystemInfo_hostname
{
public:
  explicit Init_SystemInfo_hostname(::creos_sdk_msgs::msg::SystemInfo & msg)
  : msg_(msg)
  {}
  Init_SystemInfo_serial hostname(::creos_sdk_msgs::msg::SystemInfo::_hostname_type arg)
  {
    msg_.hostname = std::move(arg);
    return Init_SystemInfo_serial(msg_);
  }

private:
  ::creos_sdk_msgs::msg::SystemInfo msg_;
};

class Init_SystemInfo_name
{
public:
  Init_SystemInfo_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SystemInfo_hostname name(::creos_sdk_msgs::msg::SystemInfo::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_SystemInfo_hostname(msg_);
  }

private:
  ::creos_sdk_msgs::msg::SystemInfo msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::msg::SystemInfo>()
{
  return creos_sdk_msgs::msg::builder::Init_SystemInfo_name();
}

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__BUILDER_HPP_
