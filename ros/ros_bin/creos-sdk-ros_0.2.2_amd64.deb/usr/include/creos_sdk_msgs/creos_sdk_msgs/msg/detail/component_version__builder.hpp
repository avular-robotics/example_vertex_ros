// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from creos_sdk_msgs:msg/ComponentVersion.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__BUILDER_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "creos_sdk_msgs/msg/detail/component_version__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace creos_sdk_msgs
{

namespace msg
{

namespace builder
{

class Init_ComponentVersion_type
{
public:
  explicit Init_ComponentVersion_type(::creos_sdk_msgs::msg::ComponentVersion & msg)
  : msg_(msg)
  {}
  ::creos_sdk_msgs::msg::ComponentVersion type(::creos_sdk_msgs::msg::ComponentVersion::_type_type arg)
  {
    msg_.type = std::move(arg);
    return std::move(msg_);
  }

private:
  ::creos_sdk_msgs::msg::ComponentVersion msg_;
};

class Init_ComponentVersion_version
{
public:
  explicit Init_ComponentVersion_version(::creos_sdk_msgs::msg::ComponentVersion & msg)
  : msg_(msg)
  {}
  Init_ComponentVersion_type version(::creos_sdk_msgs::msg::ComponentVersion::_version_type arg)
  {
    msg_.version = std::move(arg);
    return Init_ComponentVersion_type(msg_);
  }

private:
  ::creos_sdk_msgs::msg::ComponentVersion msg_;
};

class Init_ComponentVersion_name
{
public:
  Init_ComponentVersion_name()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_ComponentVersion_version name(::creos_sdk_msgs::msg::ComponentVersion::_name_type arg)
  {
    msg_.name = std::move(arg);
    return Init_ComponentVersion_version(msg_);
  }

private:
  ::creos_sdk_msgs::msg::ComponentVersion msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::msg::ComponentVersion>()
{
  return creos_sdk_msgs::msg::builder::Init_ComponentVersion_name();
}

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__BUILDER_HPP_
