// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from creos_sdk_msgs:msg/ControlSource.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__STRUCT_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__creos_sdk_msgs__msg__ControlSource __attribute__((deprecated))
#else
# define DEPRECATED__creos_sdk_msgs__msg__ControlSource __declspec(deprecated)
#endif

namespace creos_sdk_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct ControlSource_
{
  using Type = ControlSource_<ContainerAllocator>;

  explicit ControlSource_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->source = 0;
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->source = 0;
    }
  }

  explicit ControlSource_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::DEFAULTS_ONLY == _init)
    {
      this->source = 0;
    } else if (rosidl_runtime_cpp::MessageInitialization::ZERO == _init) {
      this->source = 0;
    }
  }

  // field types and members
  using _source_type =
    int8_t;
  _source_type source;

  // setters for named parameter idiom
  Type & set__source(
    const int8_t & _arg)
  {
    this->source = _arg;
    return *this;
  }

  // constant declarations
  static constexpr int8_t UNKNOWN =
    -1;
  static constexpr int8_t DISABLED =
    0;
  static constexpr int8_t MANUAL =
    1;
  static constexpr int8_t AUTONOMOUS =
    2;
  static constexpr int8_t USER =
    3;

  // pointer types
  using RawPtr =
    creos_sdk_msgs::msg::ControlSource_<ContainerAllocator> *;
  using ConstRawPtr =
    const creos_sdk_msgs::msg::ControlSource_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<creos_sdk_msgs::msg::ControlSource_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<creos_sdk_msgs::msg::ControlSource_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::msg::ControlSource_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::msg::ControlSource_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::msg::ControlSource_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::msg::ControlSource_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<creos_sdk_msgs::msg::ControlSource_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<creos_sdk_msgs::msg::ControlSource_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__creos_sdk_msgs__msg__ControlSource
    std::shared_ptr<creos_sdk_msgs::msg::ControlSource_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__creos_sdk_msgs__msg__ControlSource
    std::shared_ptr<creos_sdk_msgs::msg::ControlSource_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const ControlSource_ & other) const
  {
    if (this->source != other.source) {
      return false;
    }
    return true;
  }
  bool operator!=(const ControlSource_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct ControlSource_

// alias to use template instance with default allocator
using ControlSource =
  creos_sdk_msgs::msg::ControlSource_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t ControlSource_<ContainerAllocator>::UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t ControlSource_<ContainerAllocator>::DISABLED;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t ControlSource_<ContainerAllocator>::MANUAL;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t ControlSource_<ContainerAllocator>::AUTONOMOUS;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr int8_t ControlSource_<ContainerAllocator>::USER;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__STRUCT_HPP_
