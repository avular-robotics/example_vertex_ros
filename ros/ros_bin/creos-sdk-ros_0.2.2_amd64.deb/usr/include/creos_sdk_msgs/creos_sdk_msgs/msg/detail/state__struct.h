// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:msg/State.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__STATE__STRUCT_H_
#define CREOS_SDK_MSGS__MSG__DETAIL__STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNKNOWN'.
/**
  * Ready state of the robot
  * The state is unknown
 */
enum
{
  creos_sdk_msgs__msg__State__UNKNOWN = -1
};

/// Constant 'NOT_READY'.
/**
  * The robot is not ready to perform operations, e.g. when the robot is booting.
 */
enum
{
  creos_sdk_msgs__msg__State__NOT_READY = 0
};

/// Constant 'PRE_ARM'.
/**
  * The robot is in a safety state where checks are being performed. User interaction may be required.
 */
enum
{
  creos_sdk_msgs__msg__State__PRE_ARM = 1
};

/// Constant 'ACTIVE'.
/**
  * The robot is ready to perform operations.
 */
enum
{
  creos_sdk_msgs__msg__State__ACTIVE = 2
};

/// Constant 'WAITING'.
/**
  * The robot is operational, but waiting for user input.
 */
enum
{
  creos_sdk_msgs__msg__State__WAITING = 3
};

/// Constant 'FAILSAFE'.
/**
  * A safety system has been triggered, and the robot is in a failsafe state like an emergency stop.
 */
enum
{
  creos_sdk_msgs__msg__State__FAILSAFE = 4
};

/// Constant 'ERROR'.
/**
  * The robot has a fatal error and is not able to perform operations. User interaction is required.
 */
enum
{
  creos_sdk_msgs__msg__State__ERROR = 5
};

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'current_action'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/State in the package creos_sdk_msgs.
/**
  * Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
  * You may use this code under the terms of the Avular
  * Software End-User License Agreement.
  *
  * You should have received a copy of the Avular
  * Software End-User License Agreement license with
  * this file, or download it from: avular.com/eula
 */
typedef struct creos_sdk_msgs__msg__State
{
  /// The time when the state was updated
  builtin_interfaces__msg__Time stamp;
  /// The current state of the robot
  int8_t ready_state;
  /// A textual description of the action that the robot is currently performing
  rosidl_runtime_c__String current_action;
} creos_sdk_msgs__msg__State;

// Struct for a sequence of creos_sdk_msgs__msg__State.
typedef struct creos_sdk_msgs__msg__State__Sequence
{
  creos_sdk_msgs__msg__State * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__msg__State__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__STATE__STRUCT_H_
