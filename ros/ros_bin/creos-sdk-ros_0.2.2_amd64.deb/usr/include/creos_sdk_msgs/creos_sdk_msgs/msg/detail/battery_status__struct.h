﻿// NOLINT: This file starts with a BOM since it contain non-ASCII characters
// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:msg/BatteryStatus.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__STRUCT_H_
#define CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'ALERT_CELL_UNDERVOLTAGE'.
/**
  * Battery alert constants
 */
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_CELL_UNDERVOLTAGE = 1ul
};

/// Constant 'ALERT_CELL_OVERVOLTAGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_CELL_OVERVOLTAGE = 2ul
};

/// Constant 'ALERT_OVERCURRENT_CHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_OVERCURRENT_CHARGE = 4ul
};

/// Constant 'ALERT_OVERCURRENT_DISCHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_OVERCURRENT_DISCHARGE = 8ul
};

/// Constant 'ALERT_OVERLOAD_DISCHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_OVERLOAD_DISCHARGE = 16ul
};

/// Constant 'ALERT_OVERLOAD_DISCHARGE_LATCH'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_OVERLOAD_DISCHARGE_LATCH = 32ul
};

/// Constant 'ALERT_SHORT_CIRCUIT_DISCHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_SHORT_CIRCUIT_DISCHARGE = 64ul
};

/// Constant 'ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH = 128ul
};

/// Constant 'ALERT_OVERTEMPERATURE_CHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_OVERTEMPERATURE_CHARGE = 256ul
};

/// Constant 'ALERT_OVERTEMPERATURE_DISCHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_OVERTEMPERATURE_DISCHARGE = 512ul
};

/// Constant 'ALERT_UNDERTEMPERATURE_CHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_UNDERTEMPERATURE_CHARGE = 1024ul
};

/// Constant 'ALERT_UNDERTEMPERATURE_DISCHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_UNDERTEMPERATURE_DISCHARGE = 2048ul
};

/// Constant 'ALERT_AFE_ALERT'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_AFE_ALERT = 4096ul
};

/// Constant 'ALERT_PRECHARGE_TIMEOUT_SUSPEND'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_PRECHARGE_TIMEOUT_SUSPEND = 262144ul
};

/// Constant 'ALERT_OVERCHARGE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__ALERT_OVERCHARGE = 1048576ul
};

/// Constant 'STATE_UNKNOWN'.
/**
  * Battery state constants
 */
enum
{
  creos_sdk_msgs__msg__BatteryStatus__STATE_UNKNOWN = 0
};

/// Constant 'STATE_OFFLINE'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__STATE_OFFLINE = 1
};

/// Constant 'STATE_CHARGING'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__STATE_CHARGING = 2
};

/// Constant 'STATE_DISCHARGING'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__STATE_DISCHARGING = 3
};

/// Constant 'STATE_BALANCING'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__STATE_BALANCING = 4
};

/// Constant 'STATE_ERROR'.
enum
{
  creos_sdk_msgs__msg__BatteryStatus__STATE_ERROR = 5
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'cell_information'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in msg/BatteryStatus in the package creos_sdk_msgs.
/**
  * Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
  * You may use this code under the terms of the Avular
  * Software End-User License Agreement.
  *
  * You should have received a copy of the Avular
  * Software End-User License Agreement license with
  * this file, or download it from: avular.com/eula
 */
typedef struct creos_sdk_msgs__msg__BatteryStatus
{
  std_msgs__msg__Header header;
  /// V
  float voltage;
  /// °C
  float temperature;
  /// 0-1
  float state_of_charge;
  /// 0-1
  float state_of_health;
  /// Cell voltage
  rosidl_runtime_c__float__Sequence cell_information;
  /// Battery alert status
  uint32_t alerts;
  /// Battery state
  uint8_t state;
} creos_sdk_msgs__msg__BatteryStatus;

// Struct for a sequence of creos_sdk_msgs__msg__BatteryStatus.
typedef struct creos_sdk_msgs__msg__BatteryStatus__Sequence
{
  creos_sdk_msgs__msg__BatteryStatus * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__msg__BatteryStatus__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__STRUCT_H_
