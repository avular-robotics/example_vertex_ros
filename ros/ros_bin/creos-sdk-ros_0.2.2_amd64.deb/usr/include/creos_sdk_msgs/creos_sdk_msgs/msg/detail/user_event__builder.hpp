// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from creos_sdk_msgs:msg/UserEvent.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__USER_EVENT__BUILDER_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__USER_EVENT__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "creos_sdk_msgs/msg/detail/user_event__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace creos_sdk_msgs
{

namespace msg
{

namespace builder
{

class Init_UserEvent_message
{
public:
  explicit Init_UserEvent_message(::creos_sdk_msgs::msg::UserEvent & msg)
  : msg_(msg)
  {}
  ::creos_sdk_msgs::msg::UserEvent message(::creos_sdk_msgs::msg::UserEvent::_message_type arg)
  {
    msg_.message = std::move(arg);
    return std::move(msg_);
  }

private:
  ::creos_sdk_msgs::msg::UserEvent msg_;
};

class Init_UserEvent_component
{
public:
  explicit Init_UserEvent_component(::creos_sdk_msgs::msg::UserEvent & msg)
  : msg_(msg)
  {}
  Init_UserEvent_message component(::creos_sdk_msgs::msg::UserEvent::_component_type arg)
  {
    msg_.component = std::move(arg);
    return Init_UserEvent_message(msg_);
  }

private:
  ::creos_sdk_msgs::msg::UserEvent msg_;
};

class Init_UserEvent_display_method
{
public:
  explicit Init_UserEvent_display_method(::creos_sdk_msgs::msg::UserEvent & msg)
  : msg_(msg)
  {}
  Init_UserEvent_component display_method(::creos_sdk_msgs::msg::UserEvent::_display_method_type arg)
  {
    msg_.display_method = std::move(arg);
    return Init_UserEvent_component(msg_);
  }

private:
  ::creos_sdk_msgs::msg::UserEvent msg_;
};

class Init_UserEvent_severity
{
public:
  explicit Init_UserEvent_severity(::creos_sdk_msgs::msg::UserEvent & msg)
  : msg_(msg)
  {}
  Init_UserEvent_display_method severity(::creos_sdk_msgs::msg::UserEvent::_severity_type arg)
  {
    msg_.severity = std::move(arg);
    return Init_UserEvent_display_method(msg_);
  }

private:
  ::creos_sdk_msgs::msg::UserEvent msg_;
};

class Init_UserEvent_source_id
{
public:
  explicit Init_UserEvent_source_id(::creos_sdk_msgs::msg::UserEvent & msg)
  : msg_(msg)
  {}
  Init_UserEvent_severity source_id(::creos_sdk_msgs::msg::UserEvent::_source_id_type arg)
  {
    msg_.source_id = std::move(arg);
    return Init_UserEvent_severity(msg_);
  }

private:
  ::creos_sdk_msgs::msg::UserEvent msg_;
};

class Init_UserEvent_stamp
{
public:
  Init_UserEvent_stamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_UserEvent_source_id stamp(::creos_sdk_msgs::msg::UserEvent::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return Init_UserEvent_source_id(msg_);
  }

private:
  ::creos_sdk_msgs::msg::UserEvent msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::msg::UserEvent>()
{
  return creos_sdk_msgs::msg::builder::Init_UserEvent_stamp();
}

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__USER_EVENT__BUILDER_HPP_
