// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from creos_sdk_msgs:msg/BatteryStatus.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__STRUCT_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__creos_sdk_msgs__msg__BatteryStatus __attribute__((deprecated))
#else
# define DEPRECATED__creos_sdk_msgs__msg__BatteryStatus __declspec(deprecated)
#endif

namespace creos_sdk_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct BatteryStatus_
{
  using Type = BatteryStatus_<ContainerAllocator>;

  explicit BatteryStatus_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->voltage = 0.0f;
      this->temperature = 0.0f;
      this->state_of_charge = 0.0f;
      this->state_of_health = 0.0f;
      this->alerts = 0ul;
      this->state = 0;
    }
  }

  explicit BatteryStatus_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : header(_alloc, _init)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->voltage = 0.0f;
      this->temperature = 0.0f;
      this->state_of_charge = 0.0f;
      this->state_of_health = 0.0f;
      this->alerts = 0ul;
      this->state = 0;
    }
  }

  // field types and members
  using _header_type =
    std_msgs::msg::Header_<ContainerAllocator>;
  _header_type header;
  using _voltage_type =
    float;
  _voltage_type voltage;
  using _temperature_type =
    float;
  _temperature_type temperature;
  using _state_of_charge_type =
    float;
  _state_of_charge_type state_of_charge;
  using _state_of_health_type =
    float;
  _state_of_health_type state_of_health;
  using _cell_information_type =
    std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>>;
  _cell_information_type cell_information;
  using _alerts_type =
    uint32_t;
  _alerts_type alerts;
  using _state_type =
    uint8_t;
  _state_type state;

  // setters for named parameter idiom
  Type & set__header(
    const std_msgs::msg::Header_<ContainerAllocator> & _arg)
  {
    this->header = _arg;
    return *this;
  }
  Type & set__voltage(
    const float & _arg)
  {
    this->voltage = _arg;
    return *this;
  }
  Type & set__temperature(
    const float & _arg)
  {
    this->temperature = _arg;
    return *this;
  }
  Type & set__state_of_charge(
    const float & _arg)
  {
    this->state_of_charge = _arg;
    return *this;
  }
  Type & set__state_of_health(
    const float & _arg)
  {
    this->state_of_health = _arg;
    return *this;
  }
  Type & set__cell_information(
    const std::vector<float, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<float>> & _arg)
  {
    this->cell_information = _arg;
    return *this;
  }
  Type & set__alerts(
    const uint32_t & _arg)
  {
    this->alerts = _arg;
    return *this;
  }
  Type & set__state(
    const uint8_t & _arg)
  {
    this->state = _arg;
    return *this;
  }

  // constant declarations
  static constexpr uint32_t ALERT_CELL_UNDERVOLTAGE =
    1u;
  static constexpr uint32_t ALERT_CELL_OVERVOLTAGE =
    2u;
  static constexpr uint32_t ALERT_OVERCURRENT_CHARGE =
    4u;
  static constexpr uint32_t ALERT_OVERCURRENT_DISCHARGE =
    8u;
  static constexpr uint32_t ALERT_OVERLOAD_DISCHARGE =
    16u;
  static constexpr uint32_t ALERT_OVERLOAD_DISCHARGE_LATCH =
    32u;
  static constexpr uint32_t ALERT_SHORT_CIRCUIT_DISCHARGE =
    64u;
  static constexpr uint32_t ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH =
    128u;
  static constexpr uint32_t ALERT_OVERTEMPERATURE_CHARGE =
    256u;
  static constexpr uint32_t ALERT_OVERTEMPERATURE_DISCHARGE =
    512u;
  static constexpr uint32_t ALERT_UNDERTEMPERATURE_CHARGE =
    1024u;
  static constexpr uint32_t ALERT_UNDERTEMPERATURE_DISCHARGE =
    2048u;
  static constexpr uint32_t ALERT_AFE_ALERT =
    4096u;
  static constexpr uint32_t ALERT_PRECHARGE_TIMEOUT_SUSPEND =
    262144u;
  static constexpr uint32_t ALERT_OVERCHARGE =
    1048576u;
  static constexpr uint8_t STATE_UNKNOWN =
    0u;
  static constexpr uint8_t STATE_OFFLINE =
    1u;
  static constexpr uint8_t STATE_CHARGING =
    2u;
  static constexpr uint8_t STATE_DISCHARGING =
    3u;
  static constexpr uint8_t STATE_BALANCING =
    4u;
  static constexpr uint8_t STATE_ERROR =
    5u;

  // pointer types
  using RawPtr =
    creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator> *;
  using ConstRawPtr =
    const creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__creos_sdk_msgs__msg__BatteryStatus
    std::shared_ptr<creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__creos_sdk_msgs__msg__BatteryStatus
    std::shared_ptr<creos_sdk_msgs::msg::BatteryStatus_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const BatteryStatus_ & other) const
  {
    if (this->header != other.header) {
      return false;
    }
    if (this->voltage != other.voltage) {
      return false;
    }
    if (this->temperature != other.temperature) {
      return false;
    }
    if (this->state_of_charge != other.state_of_charge) {
      return false;
    }
    if (this->state_of_health != other.state_of_health) {
      return false;
    }
    if (this->cell_information != other.cell_information) {
      return false;
    }
    if (this->alerts != other.alerts) {
      return false;
    }
    if (this->state != other.state) {
      return false;
    }
    return true;
  }
  bool operator!=(const BatteryStatus_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct BatteryStatus_

// alias to use template instance with default allocator
using BatteryStatus =
  creos_sdk_msgs::msg::BatteryStatus_<std::allocator<void>>;

// constant definitions
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_CELL_UNDERVOLTAGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_CELL_OVERVOLTAGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_OVERCURRENT_CHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_OVERCURRENT_DISCHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_OVERLOAD_DISCHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_OVERLOAD_DISCHARGE_LATCH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_SHORT_CIRCUIT_DISCHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_OVERTEMPERATURE_CHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_OVERTEMPERATURE_DISCHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_UNDERTEMPERATURE_CHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_UNDERTEMPERATURE_DISCHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_AFE_ALERT;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_PRECHARGE_TIMEOUT_SUSPEND;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint32_t BatteryStatus_<ContainerAllocator>::ALERT_OVERCHARGE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BatteryStatus_<ContainerAllocator>::STATE_UNKNOWN;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BatteryStatus_<ContainerAllocator>::STATE_OFFLINE;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BatteryStatus_<ContainerAllocator>::STATE_CHARGING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BatteryStatus_<ContainerAllocator>::STATE_DISCHARGING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BatteryStatus_<ContainerAllocator>::STATE_BALANCING;
#endif  // __cplusplus < 201703L
#if __cplusplus < 201703L
// static constexpr member variable definitions are only needed in C++14 and below, deprecated in C++17
template<typename ContainerAllocator>
constexpr uint8_t BatteryStatus_<ContainerAllocator>::STATE_ERROR;
#endif  // __cplusplus < 201703L

}  // namespace msg

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__STRUCT_HPP_
