// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:msg/UserEvent.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__USER_EVENT__STRUCT_H_
#define CREOS_SDK_MSGS__MSG__DETAIL__USER_EVENT__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'TRACE'.
/**
  * Event severity, how serious is the event
 */
enum
{
  creos_sdk_msgs__msg__UserEvent__TRACE = 0
};

/// Constant 'INFO'.
enum
{
  creos_sdk_msgs__msg__UserEvent__INFO = 1
};

/// Constant 'WARN'.
enum
{
  creos_sdk_msgs__msg__UserEvent__WARN = 2
};

/// Constant 'ERROR'.
enum
{
  creos_sdk_msgs__msg__UserEvent__ERROR = 3
};

/// Constant 'FATAL'.
/**
  * Fatal error which causes system failure
 */
enum
{
  creos_sdk_msgs__msg__UserEvent__FATAL = 4
};

/// Constant 'LOG'.
/**
  * What is the intended display method
  * Show in a log
 */
enum
{
  creos_sdk_msgs__msg__UserEvent__LOG = 0
};

/// Constant 'NOTIFICATION'.
/**
  * Show a notification popup
 */
enum
{
  creos_sdk_msgs__msg__UserEvent__NOTIFICATION = 1
};

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"
// Member 'source_id'
// Member 'component'
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/UserEvent in the package creos_sdk_msgs.
/**
  * Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
  * You may use this code under the terms of the Avular
  * Software End-User License Agreement.
  *
  * You should have received a copy of the Avular
  * Software End-User License Agreement license with
  * this file, or download it from: avular.com/eula
 */
typedef struct creos_sdk_msgs__msg__UserEvent
{
  /// The time when the event occurred
  builtin_interfaces__msg__Time stamp;
  /// The id of the source that triggered the event
  rosidl_runtime_c__String source_id;
  /// The event severity
  uint8_t severity;
  /// The intended display method
  uint8_t display_method;
  /// The component that triggered the event
  rosidl_runtime_c__String component;
  /// The message that is displayed
  rosidl_runtime_c__String message;
} creos_sdk_msgs__msg__UserEvent;

// Struct for a sequence of creos_sdk_msgs__msg__UserEvent.
typedef struct creos_sdk_msgs__msg__UserEvent__Sequence
{
  creos_sdk_msgs__msg__UserEvent * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__msg__UserEvent__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__USER_EVENT__STRUCT_H_
