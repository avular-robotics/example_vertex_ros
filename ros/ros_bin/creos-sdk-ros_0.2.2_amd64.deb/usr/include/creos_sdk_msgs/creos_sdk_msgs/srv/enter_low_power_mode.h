// generated from rosidl_generator_c/resource/idl.h.em
// with input from creos_sdk_msgs:srv/EnterLowPowerMode.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__ENTER_LOW_POWER_MODE_H_
#define CREOS_SDK_MSGS__SRV__ENTER_LOW_POWER_MODE_H_

#include "creos_sdk_msgs/srv/detail/enter_low_power_mode__struct.h"
#include "creos_sdk_msgs/srv/detail/enter_low_power_mode__functions.h"
#include "creos_sdk_msgs/srv/detail/enter_low_power_mode__type_support.h"

#endif  // CREOS_SDK_MSGS__SRV__ENTER_LOW_POWER_MODE_H_
