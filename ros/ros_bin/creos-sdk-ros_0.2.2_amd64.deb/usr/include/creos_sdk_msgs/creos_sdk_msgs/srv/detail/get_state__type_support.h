// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from creos_sdk_msgs:srv/GetState.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__DETAIL__GET_STATE__TYPE_SUPPORT_H_
#define CREOS_SDK_MSGS__SRV__DETAIL__GET_STATE__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "creos_sdk_msgs/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_creos_sdk_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  creos_sdk_msgs,
  srv,
  GetState_Request
)();

// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_creos_sdk_msgs
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  creos_sdk_msgs,
  srv,
  GetState_Response
)();

#include "rosidl_runtime_c/service_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_creos_sdk_msgs
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_c,
  creos_sdk_msgs,
  srv,
  GetState
)();

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__SRV__DETAIL__GET_STATE__TYPE_SUPPORT_H_
