// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:srv/SendCommand.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__DETAIL__SEND_COMMAND__STRUCT_H_
#define CREOS_SDK_MSGS__SRV__DETAIL__SEND_COMMAND__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'ARM'.
/**
  * Send a command to be executed to the robot
  * Arm the robot
 */
enum
{
  creos_sdk_msgs__srv__SendCommand_Request__ARM = 1
};

/// Constant 'DISARM'.
/**
  * Disarm the robot
 */
enum
{
  creos_sdk_msgs__srv__SendCommand_Request__DISARM = 2
};

/// Constant 'TAKE_OFF'.
/**
  * Take off
 */
enum
{
  creos_sdk_msgs__srv__SendCommand_Request__TAKE_OFF = 3
};

/// Constant 'LAND'.
/**
  * Initiate landing
 */
enum
{
  creos_sdk_msgs__srv__SendCommand_Request__LAND = 4
};

/// Constant 'EMERGENCY_LAND'.
/**
  * Initiate emergency landing
 */
enum
{
  creos_sdk_msgs__srv__SendCommand_Request__EMERGENCY_LAND = 5
};

/// Constant 'KILL_SWITCH'.
/**
  * Kill the power to the motors
 */
enum
{
  creos_sdk_msgs__srv__SendCommand_Request__KILL_SWITCH = 6
};

/// Constant 'ABORT'.
/**
  * Abort the current action
 */
enum
{
  creos_sdk_msgs__srv__SendCommand_Request__ABORT = 7
};

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in srv/SendCommand in the package creos_sdk_msgs.
typedef struct creos_sdk_msgs__srv__SendCommand_Request
{
  /// The time at which the command was sent
  builtin_interfaces__msg__Time stamp;
  /// The action to be executed
  int8_t action;
} creos_sdk_msgs__srv__SendCommand_Request;

// Struct for a sequence of creos_sdk_msgs__srv__SendCommand_Request.
typedef struct creos_sdk_msgs__srv__SendCommand_Request__Sequence
{
  creos_sdk_msgs__srv__SendCommand_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__srv__SendCommand_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/SendCommand in the package creos_sdk_msgs.
typedef struct creos_sdk_msgs__srv__SendCommand_Response
{
  /// indicate successful run of triggered service
  bool success;
  /// informational, e.g. for error messages
  rosidl_runtime_c__String message;
} creos_sdk_msgs__srv__SendCommand_Response;

// Struct for a sequence of creos_sdk_msgs__srv__SendCommand_Response.
typedef struct creos_sdk_msgs__srv__SendCommand_Response__Sequence
{
  creos_sdk_msgs__srv__SendCommand_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__srv__SendCommand_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__SRV__DETAIL__SEND_COMMAND__STRUCT_H_
