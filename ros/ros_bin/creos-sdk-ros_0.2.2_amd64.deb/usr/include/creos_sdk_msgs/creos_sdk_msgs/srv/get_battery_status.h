// generated from rosidl_generator_c/resource/idl.h.em
// with input from creos_sdk_msgs:srv/GetBatteryStatus.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__GET_BATTERY_STATUS_H_
#define CREOS_SDK_MSGS__SRV__GET_BATTERY_STATUS_H_

#include "creos_sdk_msgs/srv/detail/get_battery_status__struct.h"
#include "creos_sdk_msgs/srv/detail/get_battery_status__functions.h"
#include "creos_sdk_msgs/srv/detail/get_battery_status__type_support.h"

#endif  // CREOS_SDK_MSGS__SRV__GET_BATTERY_STATUS_H_
