// generated from rosidl_generator_c/resource/idl.h.em
// with input from creos_sdk_msgs:srv/GetControlSource.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__GET_CONTROL_SOURCE_H_
#define CREOS_SDK_MSGS__SRV__GET_CONTROL_SOURCE_H_

#include "creos_sdk_msgs/srv/detail/get_control_source__struct.h"
#include "creos_sdk_msgs/srv/detail/get_control_source__functions.h"
#include "creos_sdk_msgs/srv/detail/get_control_source__type_support.h"

#endif  // CREOS_SDK_MSGS__SRV__GET_CONTROL_SOURCE_H_
