# generated from rosidl_generator_py/resource/_idl.py.em
# with input from creos_sdk_msgs:msg/BatteryStatus.idl
# generated code does not contain a copyright notice


# Import statements for member types

# Member 'cell_information'
import array  # noqa: E402, I100

import builtins  # noqa: E402, I100

import math  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_BatteryStatus(type):
    """Metaclass of message 'BatteryStatus'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'ALERT_CELL_UNDERVOLTAGE': 1,
        'ALERT_CELL_OVERVOLTAGE': 2,
        'ALERT_OVERCURRENT_CHARGE': 4,
        'ALERT_OVERCURRENT_DISCHARGE': 8,
        'ALERT_OVERLOAD_DISCHARGE': 16,
        'ALERT_OVERLOAD_DISCHARGE_LATCH': 32,
        'ALERT_SHORT_CIRCUIT_DISCHARGE': 64,
        'ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH': 128,
        'ALERT_OVERTEMPERATURE_CHARGE': 256,
        'ALERT_OVERTEMPERATURE_DISCHARGE': 512,
        'ALERT_UNDERTEMPERATURE_CHARGE': 1024,
        'ALERT_UNDERTEMPERATURE_DISCHARGE': 2048,
        'ALERT_AFE_ALERT': 4096,
        'ALERT_PRECHARGE_TIMEOUT_SUSPEND': 262144,
        'ALERT_OVERCHARGE': 1048576,
        'STATE_UNKNOWN': 0,
        'STATE_OFFLINE': 1,
        'STATE_CHARGING': 2,
        'STATE_DISCHARGING': 3,
        'STATE_BALANCING': 4,
        'STATE_ERROR': 5,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('creos_sdk_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'creos_sdk_msgs.msg.BatteryStatus')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__battery_status
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__battery_status
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__battery_status
            cls._TYPE_SUPPORT = module.type_support_msg__msg__battery_status
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__battery_status

            from std_msgs.msg import Header
            if Header.__class__._TYPE_SUPPORT is None:
                Header.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'ALERT_CELL_UNDERVOLTAGE': cls.__constants['ALERT_CELL_UNDERVOLTAGE'],
            'ALERT_CELL_OVERVOLTAGE': cls.__constants['ALERT_CELL_OVERVOLTAGE'],
            'ALERT_OVERCURRENT_CHARGE': cls.__constants['ALERT_OVERCURRENT_CHARGE'],
            'ALERT_OVERCURRENT_DISCHARGE': cls.__constants['ALERT_OVERCURRENT_DISCHARGE'],
            'ALERT_OVERLOAD_DISCHARGE': cls.__constants['ALERT_OVERLOAD_DISCHARGE'],
            'ALERT_OVERLOAD_DISCHARGE_LATCH': cls.__constants['ALERT_OVERLOAD_DISCHARGE_LATCH'],
            'ALERT_SHORT_CIRCUIT_DISCHARGE': cls.__constants['ALERT_SHORT_CIRCUIT_DISCHARGE'],
            'ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH': cls.__constants['ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH'],
            'ALERT_OVERTEMPERATURE_CHARGE': cls.__constants['ALERT_OVERTEMPERATURE_CHARGE'],
            'ALERT_OVERTEMPERATURE_DISCHARGE': cls.__constants['ALERT_OVERTEMPERATURE_DISCHARGE'],
            'ALERT_UNDERTEMPERATURE_CHARGE': cls.__constants['ALERT_UNDERTEMPERATURE_CHARGE'],
            'ALERT_UNDERTEMPERATURE_DISCHARGE': cls.__constants['ALERT_UNDERTEMPERATURE_DISCHARGE'],
            'ALERT_AFE_ALERT': cls.__constants['ALERT_AFE_ALERT'],
            'ALERT_PRECHARGE_TIMEOUT_SUSPEND': cls.__constants['ALERT_PRECHARGE_TIMEOUT_SUSPEND'],
            'ALERT_OVERCHARGE': cls.__constants['ALERT_OVERCHARGE'],
            'STATE_UNKNOWN': cls.__constants['STATE_UNKNOWN'],
            'STATE_OFFLINE': cls.__constants['STATE_OFFLINE'],
            'STATE_CHARGING': cls.__constants['STATE_CHARGING'],
            'STATE_DISCHARGING': cls.__constants['STATE_DISCHARGING'],
            'STATE_BALANCING': cls.__constants['STATE_BALANCING'],
            'STATE_ERROR': cls.__constants['STATE_ERROR'],
        }

    @property
    def ALERT_CELL_UNDERVOLTAGE(self):
        """Message constant 'ALERT_CELL_UNDERVOLTAGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_CELL_UNDERVOLTAGE']

    @property
    def ALERT_CELL_OVERVOLTAGE(self):
        """Message constant 'ALERT_CELL_OVERVOLTAGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_CELL_OVERVOLTAGE']

    @property
    def ALERT_OVERCURRENT_CHARGE(self):
        """Message constant 'ALERT_OVERCURRENT_CHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_OVERCURRENT_CHARGE']

    @property
    def ALERT_OVERCURRENT_DISCHARGE(self):
        """Message constant 'ALERT_OVERCURRENT_DISCHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_OVERCURRENT_DISCHARGE']

    @property
    def ALERT_OVERLOAD_DISCHARGE(self):
        """Message constant 'ALERT_OVERLOAD_DISCHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_OVERLOAD_DISCHARGE']

    @property
    def ALERT_OVERLOAD_DISCHARGE_LATCH(self):
        """Message constant 'ALERT_OVERLOAD_DISCHARGE_LATCH'."""
        return Metaclass_BatteryStatus.__constants['ALERT_OVERLOAD_DISCHARGE_LATCH']

    @property
    def ALERT_SHORT_CIRCUIT_DISCHARGE(self):
        """Message constant 'ALERT_SHORT_CIRCUIT_DISCHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_SHORT_CIRCUIT_DISCHARGE']

    @property
    def ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH(self):
        """Message constant 'ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH'."""
        return Metaclass_BatteryStatus.__constants['ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH']

    @property
    def ALERT_OVERTEMPERATURE_CHARGE(self):
        """Message constant 'ALERT_OVERTEMPERATURE_CHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_OVERTEMPERATURE_CHARGE']

    @property
    def ALERT_OVERTEMPERATURE_DISCHARGE(self):
        """Message constant 'ALERT_OVERTEMPERATURE_DISCHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_OVERTEMPERATURE_DISCHARGE']

    @property
    def ALERT_UNDERTEMPERATURE_CHARGE(self):
        """Message constant 'ALERT_UNDERTEMPERATURE_CHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_UNDERTEMPERATURE_CHARGE']

    @property
    def ALERT_UNDERTEMPERATURE_DISCHARGE(self):
        """Message constant 'ALERT_UNDERTEMPERATURE_DISCHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_UNDERTEMPERATURE_DISCHARGE']

    @property
    def ALERT_AFE_ALERT(self):
        """Message constant 'ALERT_AFE_ALERT'."""
        return Metaclass_BatteryStatus.__constants['ALERT_AFE_ALERT']

    @property
    def ALERT_PRECHARGE_TIMEOUT_SUSPEND(self):
        """Message constant 'ALERT_PRECHARGE_TIMEOUT_SUSPEND'."""
        return Metaclass_BatteryStatus.__constants['ALERT_PRECHARGE_TIMEOUT_SUSPEND']

    @property
    def ALERT_OVERCHARGE(self):
        """Message constant 'ALERT_OVERCHARGE'."""
        return Metaclass_BatteryStatus.__constants['ALERT_OVERCHARGE']

    @property
    def STATE_UNKNOWN(self):
        """Message constant 'STATE_UNKNOWN'."""
        return Metaclass_BatteryStatus.__constants['STATE_UNKNOWN']

    @property
    def STATE_OFFLINE(self):
        """Message constant 'STATE_OFFLINE'."""
        return Metaclass_BatteryStatus.__constants['STATE_OFFLINE']

    @property
    def STATE_CHARGING(self):
        """Message constant 'STATE_CHARGING'."""
        return Metaclass_BatteryStatus.__constants['STATE_CHARGING']

    @property
    def STATE_DISCHARGING(self):
        """Message constant 'STATE_DISCHARGING'."""
        return Metaclass_BatteryStatus.__constants['STATE_DISCHARGING']

    @property
    def STATE_BALANCING(self):
        """Message constant 'STATE_BALANCING'."""
        return Metaclass_BatteryStatus.__constants['STATE_BALANCING']

    @property
    def STATE_ERROR(self):
        """Message constant 'STATE_ERROR'."""
        return Metaclass_BatteryStatus.__constants['STATE_ERROR']


class BatteryStatus(metaclass=Metaclass_BatteryStatus):
    """
    Message class 'BatteryStatus'.

    Constants:
      ALERT_CELL_UNDERVOLTAGE
      ALERT_CELL_OVERVOLTAGE
      ALERT_OVERCURRENT_CHARGE
      ALERT_OVERCURRENT_DISCHARGE
      ALERT_OVERLOAD_DISCHARGE
      ALERT_OVERLOAD_DISCHARGE_LATCH
      ALERT_SHORT_CIRCUIT_DISCHARGE
      ALERT_SHORT_CIRCUIT_DISCHARGE_LATCH
      ALERT_OVERTEMPERATURE_CHARGE
      ALERT_OVERTEMPERATURE_DISCHARGE
      ALERT_UNDERTEMPERATURE_CHARGE
      ALERT_UNDERTEMPERATURE_DISCHARGE
      ALERT_AFE_ALERT
      ALERT_PRECHARGE_TIMEOUT_SUSPEND
      ALERT_OVERCHARGE
      STATE_UNKNOWN
      STATE_OFFLINE
      STATE_CHARGING
      STATE_DISCHARGING
      STATE_BALANCING
      STATE_ERROR
    """

    __slots__ = [
        '_header',
        '_voltage',
        '_temperature',
        '_state_of_charge',
        '_state_of_health',
        '_cell_information',
        '_alerts',
        '_state',
    ]

    _fields_and_field_types = {
        'header': 'std_msgs/Header',
        'voltage': 'float',
        'temperature': 'float',
        'state_of_charge': 'float',
        'state_of_health': 'float',
        'cell_information': 'sequence<float>',
        'alerts': 'uint32',
        'state': 'uint8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['std_msgs', 'msg'], 'Header'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.BasicType('float'),  # noqa: E501
        rosidl_parser.definition.UnboundedSequence(rosidl_parser.definition.BasicType('float')),  # noqa: E501
        rosidl_parser.definition.BasicType('uint32'),  # noqa: E501
        rosidl_parser.definition.BasicType('uint8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from std_msgs.msg import Header
        self.header = kwargs.get('header', Header())
        self.voltage = kwargs.get('voltage', float())
        self.temperature = kwargs.get('temperature', float())
        self.state_of_charge = kwargs.get('state_of_charge', float())
        self.state_of_health = kwargs.get('state_of_health', float())
        self.cell_information = array.array('f', kwargs.get('cell_information', []))
        self.alerts = kwargs.get('alerts', int())
        self.state = kwargs.get('state', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.header != other.header:
            return False
        if self.voltage != other.voltage:
            return False
        if self.temperature != other.temperature:
            return False
        if self.state_of_charge != other.state_of_charge:
            return False
        if self.state_of_health != other.state_of_health:
            return False
        if self.cell_information != other.cell_information:
            return False
        if self.alerts != other.alerts:
            return False
        if self.state != other.state:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def header(self):
        """Message field 'header'."""
        return self._header

    @header.setter
    def header(self, value):
        if __debug__:
            from std_msgs.msg import Header
            assert \
                isinstance(value, Header), \
                "The 'header' field must be a sub message of type 'Header'"
        self._header = value

    @builtins.property
    def voltage(self):
        """Message field 'voltage'."""
        return self._voltage

    @voltage.setter
    def voltage(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'voltage' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'voltage' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._voltage = value

    @builtins.property
    def temperature(self):
        """Message field 'temperature'."""
        return self._temperature

    @temperature.setter
    def temperature(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'temperature' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'temperature' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._temperature = value

    @builtins.property
    def state_of_charge(self):
        """Message field 'state_of_charge'."""
        return self._state_of_charge

    @state_of_charge.setter
    def state_of_charge(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'state_of_charge' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'state_of_charge' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._state_of_charge = value

    @builtins.property
    def state_of_health(self):
        """Message field 'state_of_health'."""
        return self._state_of_health

    @state_of_health.setter
    def state_of_health(self, value):
        if __debug__:
            assert \
                isinstance(value, float), \
                "The 'state_of_health' field must be of type 'float'"
            assert not (value < -3.402823466e+38 or value > 3.402823466e+38) or math.isinf(value), \
                "The 'state_of_health' field must be a float in [-3.402823466e+38, 3.402823466e+38]"
        self._state_of_health = value

    @builtins.property
    def cell_information(self):
        """Message field 'cell_information'."""
        return self._cell_information

    @cell_information.setter
    def cell_information(self, value):
        if isinstance(value, array.array):
            assert value.typecode == 'f', \
                "The 'cell_information' array.array() must have the type code of 'f'"
            self._cell_information = value
            return
        if __debug__:
            from collections.abc import Sequence
            from collections.abc import Set
            from collections import UserList
            from collections import UserString
            assert \
                ((isinstance(value, Sequence) or
                  isinstance(value, Set) or
                  isinstance(value, UserList)) and
                 not isinstance(value, str) and
                 not isinstance(value, UserString) and
                 all(isinstance(v, float) for v in value) and
                 all(not (val < -3.402823466e+38 or val > 3.402823466e+38) or math.isinf(val) for val in value)), \
                "The 'cell_information' field must be a set or sequence and each value of type 'float' and each float in [-340282346600000016151267322115014000640.000000, 340282346600000016151267322115014000640.000000]"
        self._cell_information = array.array('f', value)

    @builtins.property
    def alerts(self):
        """Message field 'alerts'."""
        return self._alerts

    @alerts.setter
    def alerts(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'alerts' field must be of type 'int'"
            assert value >= 0 and value < 4294967296, \
                "The 'alerts' field must be an unsigned integer in [0, 4294967295]"
        self._alerts = value

    @builtins.property
    def state(self):
        """Message field 'state'."""
        return self._state

    @state.setter
    def state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'state' field must be of type 'int'"
            assert value >= 0 and value < 256, \
                "The 'state' field must be an unsigned integer in [0, 255]"
        self._state = value
