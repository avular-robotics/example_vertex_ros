# generated from rosidl_generator_py/resource/_idl.py.em
# with input from creos_sdk_msgs:msg/State.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_State(type):
    """Metaclass of message 'State'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'UNKNOWN': -1,
        'NOT_READY': 0,
        'PRE_ARM': 1,
        'ACTIVE': 2,
        'WAITING': 3,
        'FAILSAFE': 4,
        'ERROR': 5,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('creos_sdk_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'creos_sdk_msgs.msg.State')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__state
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__state
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__state
            cls._TYPE_SUPPORT = module.type_support_msg__msg__state
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__state

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'UNKNOWN': cls.__constants['UNKNOWN'],
            'NOT_READY': cls.__constants['NOT_READY'],
            'PRE_ARM': cls.__constants['PRE_ARM'],
            'ACTIVE': cls.__constants['ACTIVE'],
            'WAITING': cls.__constants['WAITING'],
            'FAILSAFE': cls.__constants['FAILSAFE'],
            'ERROR': cls.__constants['ERROR'],
            'READY_STATE__DEFAULT': -1,
            'CURRENT_ACTION__DEFAULT': 'unknown',
        }

    @property
    def UNKNOWN(self):
        """Message constant 'UNKNOWN'."""
        return Metaclass_State.__constants['UNKNOWN']

    @property
    def NOT_READY(self):
        """Message constant 'NOT_READY'."""
        return Metaclass_State.__constants['NOT_READY']

    @property
    def PRE_ARM(self):
        """Message constant 'PRE_ARM'."""
        return Metaclass_State.__constants['PRE_ARM']

    @property
    def ACTIVE(self):
        """Message constant 'ACTIVE'."""
        return Metaclass_State.__constants['ACTIVE']

    @property
    def WAITING(self):
        """Message constant 'WAITING'."""
        return Metaclass_State.__constants['WAITING']

    @property
    def FAILSAFE(self):
        """Message constant 'FAILSAFE'."""
        return Metaclass_State.__constants['FAILSAFE']

    @property
    def ERROR(self):
        """Message constant 'ERROR'."""
        return Metaclass_State.__constants['ERROR']

    @property
    def READY_STATE__DEFAULT(cls):
        """Return default value for message field 'ready_state'."""
        return -1

    @property
    def CURRENT_ACTION__DEFAULT(cls):
        """Return default value for message field 'current_action'."""
        return 'unknown'


class State(metaclass=Metaclass_State):
    """
    Message class 'State'.

    Constants:
      UNKNOWN
      NOT_READY
      PRE_ARM
      ACTIVE
      WAITING
      FAILSAFE
      ERROR
    """

    __slots__ = [
        '_stamp',
        '_ready_state',
        '_current_action',
    ]

    _fields_and_field_types = {
        'stamp': 'builtin_interfaces/Time',
        'ready_state': 'int8',
        'current_action': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from builtin_interfaces.msg import Time
        self.stamp = kwargs.get('stamp', Time())
        self.ready_state = kwargs.get(
            'ready_state', State.READY_STATE__DEFAULT)
        self.current_action = kwargs.get(
            'current_action', State.CURRENT_ACTION__DEFAULT)

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.stamp != other.stamp:
            return False
        if self.ready_state != other.ready_state:
            return False
        if self.current_action != other.current_action:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def stamp(self):
        """Message field 'stamp'."""
        return self._stamp

    @stamp.setter
    def stamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'stamp' field must be a sub message of type 'Time'"
        self._stamp = value

    @builtins.property
    def ready_state(self):
        """Message field 'ready_state'."""
        return self._ready_state

    @ready_state.setter
    def ready_state(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'ready_state' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'ready_state' field must be an integer in [-128, 127]"
        self._ready_state = value

    @builtins.property
    def current_action(self):
        """Message field 'current_action'."""
        return self._current_action

    @current_action.setter
    def current_action(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'current_action' field must be of type 'str'"
        self._current_action = value
