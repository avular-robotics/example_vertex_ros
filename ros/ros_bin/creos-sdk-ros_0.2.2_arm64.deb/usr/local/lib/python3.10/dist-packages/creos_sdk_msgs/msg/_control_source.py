# generated from rosidl_generator_py/resource/_idl.py.em
# with input from creos_sdk_msgs:msg/ControlSource.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_ControlSource(type):
    """Metaclass of message 'ControlSource'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'UNKNOWN': -1,
        'DISABLED': 0,
        'MANUAL': 1,
        'AUTONOMOUS': 2,
        'USER': 3,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('creos_sdk_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'creos_sdk_msgs.msg.ControlSource')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__msg__control_source
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__msg__control_source
            cls._CONVERT_TO_PY = module.convert_to_py_msg__msg__control_source
            cls._TYPE_SUPPORT = module.type_support_msg__msg__control_source
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__msg__control_source

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'UNKNOWN': cls.__constants['UNKNOWN'],
            'DISABLED': cls.__constants['DISABLED'],
            'MANUAL': cls.__constants['MANUAL'],
            'AUTONOMOUS': cls.__constants['AUTONOMOUS'],
            'USER': cls.__constants['USER'],
            'SOURCE__DEFAULT': 0,
        }

    @property
    def UNKNOWN(self):
        """Message constant 'UNKNOWN'."""
        return Metaclass_ControlSource.__constants['UNKNOWN']

    @property
    def DISABLED(self):
        """Message constant 'DISABLED'."""
        return Metaclass_ControlSource.__constants['DISABLED']

    @property
    def MANUAL(self):
        """Message constant 'MANUAL'."""
        return Metaclass_ControlSource.__constants['MANUAL']

    @property
    def AUTONOMOUS(self):
        """Message constant 'AUTONOMOUS'."""
        return Metaclass_ControlSource.__constants['AUTONOMOUS']

    @property
    def USER(self):
        """Message constant 'USER'."""
        return Metaclass_ControlSource.__constants['USER']

    @property
    def SOURCE__DEFAULT(cls):
        """Return default value for message field 'source'."""
        return 0


class ControlSource(metaclass=Metaclass_ControlSource):
    """
    Message class 'ControlSource'.

    Constants:
      UNKNOWN
      DISABLED
      MANUAL
      AUTONOMOUS
      USER
    """

    __slots__ = [
        '_source',
    ]

    _fields_and_field_types = {
        'source': 'int8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.source = kwargs.get(
            'source', ControlSource.SOURCE__DEFAULT)

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.source != other.source:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def source(self):
        """Message field 'source'."""
        return self._source

    @source.setter
    def source(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'source' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'source' field must be an integer in [-128, 127]"
        self._source = value
