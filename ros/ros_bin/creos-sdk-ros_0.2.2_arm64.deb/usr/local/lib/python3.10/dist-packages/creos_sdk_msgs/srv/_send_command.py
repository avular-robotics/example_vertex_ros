# generated from rosidl_generator_py/resource/_idl.py.em
# with input from creos_sdk_msgs:srv/SendCommand.idl
# generated code does not contain a copyright notice


# Import statements for member types

import builtins  # noqa: E402, I100

import rosidl_parser.definition  # noqa: E402, I100


class Metaclass_SendCommand_Request(type):
    """Metaclass of message 'SendCommand_Request'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
        'ARM': 1,
        'DISARM': 2,
        'TAKE_OFF': 3,
        'LAND': 4,
        'EMERGENCY_LAND': 5,
        'KILL_SWITCH': 6,
        'ABORT': 7,
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('creos_sdk_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'creos_sdk_msgs.srv.SendCommand_Request')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__send_command__request
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__send_command__request
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__send_command__request
            cls._TYPE_SUPPORT = module.type_support_msg__srv__send_command__request
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__send_command__request

            from builtin_interfaces.msg import Time
            if Time.__class__._TYPE_SUPPORT is None:
                Time.__class__.__import_type_support__()

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
            'ARM': cls.__constants['ARM'],
            'DISARM': cls.__constants['DISARM'],
            'TAKE_OFF': cls.__constants['TAKE_OFF'],
            'LAND': cls.__constants['LAND'],
            'EMERGENCY_LAND': cls.__constants['EMERGENCY_LAND'],
            'KILL_SWITCH': cls.__constants['KILL_SWITCH'],
            'ABORT': cls.__constants['ABORT'],
        }

    @property
    def ARM(self):
        """Message constant 'ARM'."""
        return Metaclass_SendCommand_Request.__constants['ARM']

    @property
    def DISARM(self):
        """Message constant 'DISARM'."""
        return Metaclass_SendCommand_Request.__constants['DISARM']

    @property
    def TAKE_OFF(self):
        """Message constant 'TAKE_OFF'."""
        return Metaclass_SendCommand_Request.__constants['TAKE_OFF']

    @property
    def LAND(self):
        """Message constant 'LAND'."""
        return Metaclass_SendCommand_Request.__constants['LAND']

    @property
    def EMERGENCY_LAND(self):
        """Message constant 'EMERGENCY_LAND'."""
        return Metaclass_SendCommand_Request.__constants['EMERGENCY_LAND']

    @property
    def KILL_SWITCH(self):
        """Message constant 'KILL_SWITCH'."""
        return Metaclass_SendCommand_Request.__constants['KILL_SWITCH']

    @property
    def ABORT(self):
        """Message constant 'ABORT'."""
        return Metaclass_SendCommand_Request.__constants['ABORT']


class SendCommand_Request(metaclass=Metaclass_SendCommand_Request):
    """
    Message class 'SendCommand_Request'.

    Constants:
      ARM
      DISARM
      TAKE_OFF
      LAND
      EMERGENCY_LAND
      KILL_SWITCH
      ABORT
    """

    __slots__ = [
        '_stamp',
        '_action',
    ]

    _fields_and_field_types = {
        'stamp': 'builtin_interfaces/Time',
        'action': 'int8',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.NamespacedType(['builtin_interfaces', 'msg'], 'Time'),  # noqa: E501
        rosidl_parser.definition.BasicType('int8'),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        from builtin_interfaces.msg import Time
        self.stamp = kwargs.get('stamp', Time())
        self.action = kwargs.get('action', int())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.stamp != other.stamp:
            return False
        if self.action != other.action:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def stamp(self):
        """Message field 'stamp'."""
        return self._stamp

    @stamp.setter
    def stamp(self, value):
        if __debug__:
            from builtin_interfaces.msg import Time
            assert \
                isinstance(value, Time), \
                "The 'stamp' field must be a sub message of type 'Time'"
        self._stamp = value

    @builtins.property
    def action(self):
        """Message field 'action'."""
        return self._action

    @action.setter
    def action(self, value):
        if __debug__:
            assert \
                isinstance(value, int), \
                "The 'action' field must be of type 'int'"
            assert value >= -128 and value < 128, \
                "The 'action' field must be an integer in [-128, 127]"
        self._action = value


# Import statements for member types

# already imported above
# import builtins

# already imported above
# import rosidl_parser.definition


class Metaclass_SendCommand_Response(type):
    """Metaclass of message 'SendCommand_Response'."""

    _CREATE_ROS_MESSAGE = None
    _CONVERT_FROM_PY = None
    _CONVERT_TO_PY = None
    _DESTROY_ROS_MESSAGE = None
    _TYPE_SUPPORT = None

    __constants = {
    }

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('creos_sdk_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'creos_sdk_msgs.srv.SendCommand_Response')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._CREATE_ROS_MESSAGE = module.create_ros_message_msg__srv__send_command__response
            cls._CONVERT_FROM_PY = module.convert_from_py_msg__srv__send_command__response
            cls._CONVERT_TO_PY = module.convert_to_py_msg__srv__send_command__response
            cls._TYPE_SUPPORT = module.type_support_msg__srv__send_command__response
            cls._DESTROY_ROS_MESSAGE = module.destroy_ros_message_msg__srv__send_command__response

    @classmethod
    def __prepare__(cls, name, bases, **kwargs):
        # list constant names here so that they appear in the help text of
        # the message class under "Data and other attributes defined here:"
        # as well as populate each message instance
        return {
        }


class SendCommand_Response(metaclass=Metaclass_SendCommand_Response):
    """Message class 'SendCommand_Response'."""

    __slots__ = [
        '_success',
        '_message',
    ]

    _fields_and_field_types = {
        'success': 'boolean',
        'message': 'string',
    }

    SLOT_TYPES = (
        rosidl_parser.definition.BasicType('boolean'),  # noqa: E501
        rosidl_parser.definition.UnboundedString(),  # noqa: E501
    )

    def __init__(self, **kwargs):
        assert all('_' + key in self.__slots__ for key in kwargs.keys()), \
            'Invalid arguments passed to constructor: %s' % \
            ', '.join(sorted(k for k in kwargs.keys() if '_' + k not in self.__slots__))
        self.success = kwargs.get('success', bool())
        self.message = kwargs.get('message', str())

    def __repr__(self):
        typename = self.__class__.__module__.split('.')
        typename.pop()
        typename.append(self.__class__.__name__)
        args = []
        for s, t in zip(self.__slots__, self.SLOT_TYPES):
            field = getattr(self, s)
            fieldstr = repr(field)
            # We use Python array type for fields that can be directly stored
            # in them, and "normal" sequences for everything else.  If it is
            # a type that we store in an array, strip off the 'array' portion.
            if (
                isinstance(t, rosidl_parser.definition.AbstractSequence) and
                isinstance(t.value_type, rosidl_parser.definition.BasicType) and
                t.value_type.typename in ['float', 'double', 'int8', 'uint8', 'int16', 'uint16', 'int32', 'uint32', 'int64', 'uint64']
            ):
                if len(field) == 0:
                    fieldstr = '[]'
                else:
                    assert fieldstr.startswith('array(')
                    prefix = "array('X', "
                    suffix = ')'
                    fieldstr = fieldstr[len(prefix):-len(suffix)]
            args.append(s[1:] + '=' + fieldstr)
        return '%s(%s)' % ('.'.join(typename), ', '.join(args))

    def __eq__(self, other):
        if not isinstance(other, self.__class__):
            return False
        if self.success != other.success:
            return False
        if self.message != other.message:
            return False
        return True

    @classmethod
    def get_fields_and_field_types(cls):
        from copy import copy
        return copy(cls._fields_and_field_types)

    @builtins.property
    def success(self):
        """Message field 'success'."""
        return self._success

    @success.setter
    def success(self, value):
        if __debug__:
            assert \
                isinstance(value, bool), \
                "The 'success' field must be of type 'bool'"
        self._success = value

    @builtins.property
    def message(self):
        """Message field 'message'."""
        return self._message

    @message.setter
    def message(self, value):
        if __debug__:
            assert \
                isinstance(value, str), \
                "The 'message' field must be of type 'str'"
        self._message = value


class Metaclass_SendCommand(type):
    """Metaclass of service 'SendCommand'."""

    _TYPE_SUPPORT = None

    @classmethod
    def __import_type_support__(cls):
        try:
            from rosidl_generator_py import import_type_support
            module = import_type_support('creos_sdk_msgs')
        except ImportError:
            import logging
            import traceback
            logger = logging.getLogger(
                'creos_sdk_msgs.srv.SendCommand')
            logger.debug(
                'Failed to import needed modules for type support:\n' +
                traceback.format_exc())
        else:
            cls._TYPE_SUPPORT = module.type_support_srv__srv__send_command

            from creos_sdk_msgs.srv import _send_command
            if _send_command.Metaclass_SendCommand_Request._TYPE_SUPPORT is None:
                _send_command.Metaclass_SendCommand_Request.__import_type_support__()
            if _send_command.Metaclass_SendCommand_Response._TYPE_SUPPORT is None:
                _send_command.Metaclass_SendCommand_Response.__import_type_support__()


class SendCommand(metaclass=Metaclass_SendCommand):
    from creos_sdk_msgs.srv._send_command import SendCommand_Request as Request
    from creos_sdk_msgs.srv._send_command import SendCommand_Response as Response

    def __init__(self):
        raise NotImplementedError('Service classes can not be instantiated')
