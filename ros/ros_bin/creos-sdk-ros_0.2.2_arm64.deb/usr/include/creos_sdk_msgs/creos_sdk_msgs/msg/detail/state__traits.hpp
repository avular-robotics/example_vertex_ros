// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from creos_sdk_msgs:msg/State.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__STATE__TRAITS_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__STATE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "creos_sdk_msgs/msg/detail/state__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'stamp'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace creos_sdk_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const State & msg,
  std::ostream & out)
{
  out << "{";
  // member: stamp
  {
    out << "stamp: ";
    to_flow_style_yaml(msg.stamp, out);
    out << ", ";
  }

  // member: ready_state
  {
    out << "ready_state: ";
    rosidl_generator_traits::value_to_yaml(msg.ready_state, out);
    out << ", ";
  }

  // member: current_action
  {
    out << "current_action: ";
    rosidl_generator_traits::value_to_yaml(msg.current_action, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const State & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: stamp
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "stamp:\n";
    to_block_style_yaml(msg.stamp, out, indentation + 2);
  }

  // member: ready_state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "ready_state: ";
    rosidl_generator_traits::value_to_yaml(msg.ready_state, out);
    out << "\n";
  }

  // member: current_action
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "current_action: ";
    rosidl_generator_traits::value_to_yaml(msg.current_action, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const State & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace creos_sdk_msgs

namespace rosidl_generator_traits
{

[[deprecated("use creos_sdk_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const creos_sdk_msgs::msg::State & msg,
  std::ostream & out, size_t indentation = 0)
{
  creos_sdk_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use creos_sdk_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const creos_sdk_msgs::msg::State & msg)
{
  return creos_sdk_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<creos_sdk_msgs::msg::State>()
{
  return "creos_sdk_msgs::msg::State";
}

template<>
inline const char * name<creos_sdk_msgs::msg::State>()
{
  return "creos_sdk_msgs/msg/State";
}

template<>
struct has_fixed_size<creos_sdk_msgs::msg::State>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<creos_sdk_msgs::msg::State>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<creos_sdk_msgs::msg::State>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__STATE__TRAITS_HPP_
