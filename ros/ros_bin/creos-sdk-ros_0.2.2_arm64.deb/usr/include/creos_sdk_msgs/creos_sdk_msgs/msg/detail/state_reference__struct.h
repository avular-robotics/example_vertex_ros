// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:msg/StateReference.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__STATE_REFERENCE__STRUCT_H_
#define CREOS_SDK_MSGS__MSG__DETAIL__STATE_REFERENCE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'TRANSLATION_MODE_UNKNOWN'.
/**
  * The state reference message contains a reference that the robot should follow
  * The translation mode is unknown
 */
enum
{
  creos_sdk_msgs__msg__StateReference__TRANSLATION_MODE_UNKNOWN = 0
};

/// Constant 'TRANSLATION_MODE_POSITION'.
/**
  * Position reference (velocity and acceleration can be provided as feed-forward).
 */
enum
{
  creos_sdk_msgs__msg__StateReference__TRANSLATION_MODE_POSITION = 1
};

/// Constant 'TRANSLATION_MODE_VELOCITY'.
/**
  * Velocity reference (acceleration can be provided as feed-forward).
 */
enum
{
  creos_sdk_msgs__msg__StateReference__TRANSLATION_MODE_VELOCITY = 2
};

/// Constant 'TRANSLATION_MODE_ACCELERATION'.
/**
  * Acceleration reference.
 */
enum
{
  creos_sdk_msgs__msg__StateReference__TRANSLATION_MODE_ACCELERATION = 3
};

/// Constant 'ORIENTATION_MODE_UNKNOWN'.
/**
  * The orientation mode is unknown
 */
enum
{
  creos_sdk_msgs__msg__StateReference__ORIENTATION_MODE_UNKNOWN = 0
};

/// Constant 'ORIENTATION_MODE_ATTITUDE'.
/**
  * Attitude reference (angular velocity and acceleration can be provided as feed-forward).
 */
enum
{
  creos_sdk_msgs__msg__StateReference__ORIENTATION_MODE_ATTITUDE = 1
};

/// Constant 'ORIENTATION_MODE_ANGULAR_VELOCITY'.
/**
  * Angular velocity reference (acceleration can be provided as feed-forward).
 */
enum
{
  creos_sdk_msgs__msg__StateReference__ORIENTATION_MODE_ANGULAR_VELOCITY = 2
};

/// Constant 'ORIENTATION_MODE_ANGULAR_ACCELERATION'.
/**
  * Angular acceleration reference.
 */
enum
{
  creos_sdk_msgs__msg__StateReference__ORIENTATION_MODE_ANGULAR_ACCELERATION = 3
};

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__struct.h"
// Member 'pose'
#include "geometry_msgs/msg/detail/pose__struct.h"
// Member 'twist'
#include "geometry_msgs/msg/detail/twist__struct.h"
// Member 'accel'
#include "geometry_msgs/msg/detail/accel__struct.h"

/// Struct defined in msg/StateReference in the package creos_sdk_msgs.
/**
  * Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
  * You may use this code under the terms of the Avular
  * Software End-User License Agreement.
  *
  * You should have received a copy of the Avular
  * Software End-User License Agreement license with
  * this file, or download it from: avular.com/eula
 */
typedef struct creos_sdk_msgs__msg__StateReference
{
  /// The header of the message
  std_msgs__msg__Header header;
  /// The pose reference
  geometry_msgs__msg__Pose pose;
  /// The twist reference
  geometry_msgs__msg__Twist twist;
  /// The acceleration reference
  geometry_msgs__msg__Accel accel;
  /// The translation mode
  int8_t translation_mode;
  /// The orientation mode
  int8_t orientation_mode;
} creos_sdk_msgs__msg__StateReference;

// Struct for a sequence of creos_sdk_msgs__msg__StateReference.
typedef struct creos_sdk_msgs__msg__StateReference__Sequence
{
  creos_sdk_msgs__msg__StateReference * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__msg__StateReference__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__STATE_REFERENCE__STRUCT_H_
