// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from creos_sdk_msgs:msg/State.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__STATE__BUILDER_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__STATE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "creos_sdk_msgs/msg/detail/state__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace creos_sdk_msgs
{

namespace msg
{

namespace builder
{

class Init_State_current_action
{
public:
  explicit Init_State_current_action(::creos_sdk_msgs::msg::State & msg)
  : msg_(msg)
  {}
  ::creos_sdk_msgs::msg::State current_action(::creos_sdk_msgs::msg::State::_current_action_type arg)
  {
    msg_.current_action = std::move(arg);
    return std::move(msg_);
  }

private:
  ::creos_sdk_msgs::msg::State msg_;
};

class Init_State_ready_state
{
public:
  explicit Init_State_ready_state(::creos_sdk_msgs::msg::State & msg)
  : msg_(msg)
  {}
  Init_State_current_action ready_state(::creos_sdk_msgs::msg::State::_ready_state_type arg)
  {
    msg_.ready_state = std::move(arg);
    return Init_State_current_action(msg_);
  }

private:
  ::creos_sdk_msgs::msg::State msg_;
};

class Init_State_stamp
{
public:
  Init_State_stamp()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_State_ready_state stamp(::creos_sdk_msgs::msg::State::_stamp_type arg)
  {
    msg_.stamp = std::move(arg);
    return Init_State_ready_state(msg_);
  }

private:
  ::creos_sdk_msgs::msg::State msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::msg::State>()
{
  return creos_sdk_msgs::msg::builder::Init_State_stamp();
}

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__STATE__BUILDER_HPP_
