// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from creos_sdk_msgs:msg/SystemInfo.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


// Include directives for member types
// Member 'component_versions'
#include "creos_sdk_msgs/msg/detail/component_version__struct.hpp"

#ifndef _WIN32
# define DEPRECATED__creos_sdk_msgs__msg__SystemInfo __attribute__((deprecated))
#else
# define DEPRECATED__creos_sdk_msgs__msg__SystemInfo __declspec(deprecated)
#endif

namespace creos_sdk_msgs
{

namespace msg
{

// message struct
template<class ContainerAllocator>
struct SystemInfo_
{
  using Type = SystemInfo_<ContainerAllocator>;

  explicit SystemInfo_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->hostname = "";
      this->serial = "";
      this->platform = "";
    }
  }

  explicit SystemInfo_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : name(_alloc),
    hostname(_alloc),
    serial(_alloc),
    platform(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->name = "";
      this->hostname = "";
      this->serial = "";
      this->platform = "";
    }
  }

  // field types and members
  using _name_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _name_type name;
  using _hostname_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _hostname_type hostname;
  using _serial_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _serial_type serial;
  using _platform_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _platform_type platform;
  using _component_versions_type =
    std::vector<creos_sdk_msgs::msg::ComponentVersion_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<creos_sdk_msgs::msg::ComponentVersion_<ContainerAllocator>>>;
  _component_versions_type component_versions;

  // setters for named parameter idiom
  Type & set__name(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->name = _arg;
    return *this;
  }
  Type & set__hostname(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->hostname = _arg;
    return *this;
  }
  Type & set__serial(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->serial = _arg;
    return *this;
  }
  Type & set__platform(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->platform = _arg;
    return *this;
  }
  Type & set__component_versions(
    const std::vector<creos_sdk_msgs::msg::ComponentVersion_<ContainerAllocator>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<creos_sdk_msgs::msg::ComponentVersion_<ContainerAllocator>>> & _arg)
  {
    this->component_versions = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator> *;
  using ConstRawPtr =
    const creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__creos_sdk_msgs__msg__SystemInfo
    std::shared_ptr<creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__creos_sdk_msgs__msg__SystemInfo
    std::shared_ptr<creos_sdk_msgs::msg::SystemInfo_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SystemInfo_ & other) const
  {
    if (this->name != other.name) {
      return false;
    }
    if (this->hostname != other.hostname) {
      return false;
    }
    if (this->serial != other.serial) {
      return false;
    }
    if (this->platform != other.platform) {
      return false;
    }
    if (this->component_versions != other.component_versions) {
      return false;
    }
    return true;
  }
  bool operator!=(const SystemInfo_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SystemInfo_

// alias to use template instance with default allocator
using SystemInfo =
  creos_sdk_msgs::msg::SystemInfo_<std::allocator<void>>;

// constant definitions

}  // namespace msg

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_HPP_
