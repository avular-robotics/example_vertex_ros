// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from creos_sdk_msgs:msg/StateReference.idl
// generated code does not contain a copyright notice
#include "creos_sdk_msgs/msg/detail/state_reference__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"


// Include directives for member types
// Member `header`
#include "std_msgs/msg/detail/header__functions.h"
// Member `pose`
#include "geometry_msgs/msg/detail/pose__functions.h"
// Member `twist`
#include "geometry_msgs/msg/detail/twist__functions.h"
// Member `accel`
#include "geometry_msgs/msg/detail/accel__functions.h"

bool
creos_sdk_msgs__msg__StateReference__init(creos_sdk_msgs__msg__StateReference * msg)
{
  if (!msg) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__init(&msg->header)) {
    creos_sdk_msgs__msg__StateReference__fini(msg);
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__init(&msg->pose)) {
    creos_sdk_msgs__msg__StateReference__fini(msg);
    return false;
  }
  // twist
  if (!geometry_msgs__msg__Twist__init(&msg->twist)) {
    creos_sdk_msgs__msg__StateReference__fini(msg);
    return false;
  }
  // accel
  if (!geometry_msgs__msg__Accel__init(&msg->accel)) {
    creos_sdk_msgs__msg__StateReference__fini(msg);
    return false;
  }
  // translation_mode
  // orientation_mode
  return true;
}

void
creos_sdk_msgs__msg__StateReference__fini(creos_sdk_msgs__msg__StateReference * msg)
{
  if (!msg) {
    return;
  }
  // header
  std_msgs__msg__Header__fini(&msg->header);
  // pose
  geometry_msgs__msg__Pose__fini(&msg->pose);
  // twist
  geometry_msgs__msg__Twist__fini(&msg->twist);
  // accel
  geometry_msgs__msg__Accel__fini(&msg->accel);
  // translation_mode
  // orientation_mode
}

bool
creos_sdk_msgs__msg__StateReference__are_equal(const creos_sdk_msgs__msg__StateReference * lhs, const creos_sdk_msgs__msg__StateReference * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__are_equal(
      &(lhs->header), &(rhs->header)))
  {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__are_equal(
      &(lhs->pose), &(rhs->pose)))
  {
    return false;
  }
  // twist
  if (!geometry_msgs__msg__Twist__are_equal(
      &(lhs->twist), &(rhs->twist)))
  {
    return false;
  }
  // accel
  if (!geometry_msgs__msg__Accel__are_equal(
      &(lhs->accel), &(rhs->accel)))
  {
    return false;
  }
  // translation_mode
  if (lhs->translation_mode != rhs->translation_mode) {
    return false;
  }
  // orientation_mode
  if (lhs->orientation_mode != rhs->orientation_mode) {
    return false;
  }
  return true;
}

bool
creos_sdk_msgs__msg__StateReference__copy(
  const creos_sdk_msgs__msg__StateReference * input,
  creos_sdk_msgs__msg__StateReference * output)
{
  if (!input || !output) {
    return false;
  }
  // header
  if (!std_msgs__msg__Header__copy(
      &(input->header), &(output->header)))
  {
    return false;
  }
  // pose
  if (!geometry_msgs__msg__Pose__copy(
      &(input->pose), &(output->pose)))
  {
    return false;
  }
  // twist
  if (!geometry_msgs__msg__Twist__copy(
      &(input->twist), &(output->twist)))
  {
    return false;
  }
  // accel
  if (!geometry_msgs__msg__Accel__copy(
      &(input->accel), &(output->accel)))
  {
    return false;
  }
  // translation_mode
  output->translation_mode = input->translation_mode;
  // orientation_mode
  output->orientation_mode = input->orientation_mode;
  return true;
}

creos_sdk_msgs__msg__StateReference *
creos_sdk_msgs__msg__StateReference__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__msg__StateReference * msg = (creos_sdk_msgs__msg__StateReference *)allocator.allocate(sizeof(creos_sdk_msgs__msg__StateReference), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(creos_sdk_msgs__msg__StateReference));
  bool success = creos_sdk_msgs__msg__StateReference__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
creos_sdk_msgs__msg__StateReference__destroy(creos_sdk_msgs__msg__StateReference * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    creos_sdk_msgs__msg__StateReference__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
creos_sdk_msgs__msg__StateReference__Sequence__init(creos_sdk_msgs__msg__StateReference__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__msg__StateReference * data = NULL;

  if (size) {
    data = (creos_sdk_msgs__msg__StateReference *)allocator.zero_allocate(size, sizeof(creos_sdk_msgs__msg__StateReference), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = creos_sdk_msgs__msg__StateReference__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        creos_sdk_msgs__msg__StateReference__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
creos_sdk_msgs__msg__StateReference__Sequence__fini(creos_sdk_msgs__msg__StateReference__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      creos_sdk_msgs__msg__StateReference__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

creos_sdk_msgs__msg__StateReference__Sequence *
creos_sdk_msgs__msg__StateReference__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__msg__StateReference__Sequence * array = (creos_sdk_msgs__msg__StateReference__Sequence *)allocator.allocate(sizeof(creos_sdk_msgs__msg__StateReference__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = creos_sdk_msgs__msg__StateReference__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
creos_sdk_msgs__msg__StateReference__Sequence__destroy(creos_sdk_msgs__msg__StateReference__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    creos_sdk_msgs__msg__StateReference__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
creos_sdk_msgs__msg__StateReference__Sequence__are_equal(const creos_sdk_msgs__msg__StateReference__Sequence * lhs, const creos_sdk_msgs__msg__StateReference__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!creos_sdk_msgs__msg__StateReference__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
creos_sdk_msgs__msg__StateReference__Sequence__copy(
  const creos_sdk_msgs__msg__StateReference__Sequence * input,
  creos_sdk_msgs__msg__StateReference__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(creos_sdk_msgs__msg__StateReference);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    creos_sdk_msgs__msg__StateReference * data =
      (creos_sdk_msgs__msg__StateReference *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!creos_sdk_msgs__msg__StateReference__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          creos_sdk_msgs__msg__StateReference__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!creos_sdk_msgs__msg__StateReference__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
