// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from creos_sdk_msgs:msg/BatteryStatus.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__TRAITS_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "creos_sdk_msgs/msg/detail/battery_status__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'header'
#include "std_msgs/msg/detail/header__traits.hpp"

namespace creos_sdk_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const BatteryStatus & msg,
  std::ostream & out)
{
  out << "{";
  // member: header
  {
    out << "header: ";
    to_flow_style_yaml(msg.header, out);
    out << ", ";
  }

  // member: voltage
  {
    out << "voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.voltage, out);
    out << ", ";
  }

  // member: temperature
  {
    out << "temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.temperature, out);
    out << ", ";
  }

  // member: state_of_charge
  {
    out << "state_of_charge: ";
    rosidl_generator_traits::value_to_yaml(msg.state_of_charge, out);
    out << ", ";
  }

  // member: state_of_health
  {
    out << "state_of_health: ";
    rosidl_generator_traits::value_to_yaml(msg.state_of_health, out);
    out << ", ";
  }

  // member: cell_information
  {
    if (msg.cell_information.size() == 0) {
      out << "cell_information: []";
    } else {
      out << "cell_information: [";
      size_t pending_items = msg.cell_information.size();
      for (auto item : msg.cell_information) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
    out << ", ";
  }

  // member: alerts
  {
    out << "alerts: ";
    rosidl_generator_traits::value_to_yaml(msg.alerts, out);
    out << ", ";
  }

  // member: state
  {
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const BatteryStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: header
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "header:\n";
    to_block_style_yaml(msg.header, out, indentation + 2);
  }

  // member: voltage
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "voltage: ";
    rosidl_generator_traits::value_to_yaml(msg.voltage, out);
    out << "\n";
  }

  // member: temperature
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "temperature: ";
    rosidl_generator_traits::value_to_yaml(msg.temperature, out);
    out << "\n";
  }

  // member: state_of_charge
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state_of_charge: ";
    rosidl_generator_traits::value_to_yaml(msg.state_of_charge, out);
    out << "\n";
  }

  // member: state_of_health
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state_of_health: ";
    rosidl_generator_traits::value_to_yaml(msg.state_of_health, out);
    out << "\n";
  }

  // member: cell_information
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.cell_information.size() == 0) {
      out << "cell_information: []\n";
    } else {
      out << "cell_information:\n";
      for (auto item : msg.cell_information) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }

  // member: alerts
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "alerts: ";
    rosidl_generator_traits::value_to_yaml(msg.alerts, out);
    out << "\n";
  }

  // member: state
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "state: ";
    rosidl_generator_traits::value_to_yaml(msg.state, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const BatteryStatus & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace creos_sdk_msgs

namespace rosidl_generator_traits
{

[[deprecated("use creos_sdk_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const creos_sdk_msgs::msg::BatteryStatus & msg,
  std::ostream & out, size_t indentation = 0)
{
  creos_sdk_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use creos_sdk_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const creos_sdk_msgs::msg::BatteryStatus & msg)
{
  return creos_sdk_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<creos_sdk_msgs::msg::BatteryStatus>()
{
  return "creos_sdk_msgs::msg::BatteryStatus";
}

template<>
inline const char * name<creos_sdk_msgs::msg::BatteryStatus>()
{
  return "creos_sdk_msgs/msg/BatteryStatus";
}

template<>
struct has_fixed_size<creos_sdk_msgs::msg::BatteryStatus>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<creos_sdk_msgs::msg::BatteryStatus>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<creos_sdk_msgs::msg::BatteryStatus>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__TRAITS_HPP_
