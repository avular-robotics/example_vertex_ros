// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from creos_sdk_msgs:msg/BatteryStatus.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__BUILDER_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "creos_sdk_msgs/msg/detail/battery_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace creos_sdk_msgs
{

namespace msg
{

namespace builder
{

class Init_BatteryStatus_state
{
public:
  explicit Init_BatteryStatus_state(::creos_sdk_msgs::msg::BatteryStatus & msg)
  : msg_(msg)
  {}
  ::creos_sdk_msgs::msg::BatteryStatus state(::creos_sdk_msgs::msg::BatteryStatus::_state_type arg)
  {
    msg_.state = std::move(arg);
    return std::move(msg_);
  }

private:
  ::creos_sdk_msgs::msg::BatteryStatus msg_;
};

class Init_BatteryStatus_alerts
{
public:
  explicit Init_BatteryStatus_alerts(::creos_sdk_msgs::msg::BatteryStatus & msg)
  : msg_(msg)
  {}
  Init_BatteryStatus_state alerts(::creos_sdk_msgs::msg::BatteryStatus::_alerts_type arg)
  {
    msg_.alerts = std::move(arg);
    return Init_BatteryStatus_state(msg_);
  }

private:
  ::creos_sdk_msgs::msg::BatteryStatus msg_;
};

class Init_BatteryStatus_cell_information
{
public:
  explicit Init_BatteryStatus_cell_information(::creos_sdk_msgs::msg::BatteryStatus & msg)
  : msg_(msg)
  {}
  Init_BatteryStatus_alerts cell_information(::creos_sdk_msgs::msg::BatteryStatus::_cell_information_type arg)
  {
    msg_.cell_information = std::move(arg);
    return Init_BatteryStatus_alerts(msg_);
  }

private:
  ::creos_sdk_msgs::msg::BatteryStatus msg_;
};

class Init_BatteryStatus_state_of_health
{
public:
  explicit Init_BatteryStatus_state_of_health(::creos_sdk_msgs::msg::BatteryStatus & msg)
  : msg_(msg)
  {}
  Init_BatteryStatus_cell_information state_of_health(::creos_sdk_msgs::msg::BatteryStatus::_state_of_health_type arg)
  {
    msg_.state_of_health = std::move(arg);
    return Init_BatteryStatus_cell_information(msg_);
  }

private:
  ::creos_sdk_msgs::msg::BatteryStatus msg_;
};

class Init_BatteryStatus_state_of_charge
{
public:
  explicit Init_BatteryStatus_state_of_charge(::creos_sdk_msgs::msg::BatteryStatus & msg)
  : msg_(msg)
  {}
  Init_BatteryStatus_state_of_health state_of_charge(::creos_sdk_msgs::msg::BatteryStatus::_state_of_charge_type arg)
  {
    msg_.state_of_charge = std::move(arg);
    return Init_BatteryStatus_state_of_health(msg_);
  }

private:
  ::creos_sdk_msgs::msg::BatteryStatus msg_;
};

class Init_BatteryStatus_temperature
{
public:
  explicit Init_BatteryStatus_temperature(::creos_sdk_msgs::msg::BatteryStatus & msg)
  : msg_(msg)
  {}
  Init_BatteryStatus_state_of_charge temperature(::creos_sdk_msgs::msg::BatteryStatus::_temperature_type arg)
  {
    msg_.temperature = std::move(arg);
    return Init_BatteryStatus_state_of_charge(msg_);
  }

private:
  ::creos_sdk_msgs::msg::BatteryStatus msg_;
};

class Init_BatteryStatus_voltage
{
public:
  explicit Init_BatteryStatus_voltage(::creos_sdk_msgs::msg::BatteryStatus & msg)
  : msg_(msg)
  {}
  Init_BatteryStatus_temperature voltage(::creos_sdk_msgs::msg::BatteryStatus::_voltage_type arg)
  {
    msg_.voltage = std::move(arg);
    return Init_BatteryStatus_temperature(msg_);
  }

private:
  ::creos_sdk_msgs::msg::BatteryStatus msg_;
};

class Init_BatteryStatus_header
{
public:
  Init_BatteryStatus_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_BatteryStatus_voltage header(::creos_sdk_msgs::msg::BatteryStatus::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_BatteryStatus_voltage(msg_);
  }

private:
  ::creos_sdk_msgs::msg::BatteryStatus msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::msg::BatteryStatus>()
{
  return creos_sdk_msgs::msg::builder::Init_BatteryStatus_header();
}

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__BATTERY_STATUS__BUILDER_HPP_
