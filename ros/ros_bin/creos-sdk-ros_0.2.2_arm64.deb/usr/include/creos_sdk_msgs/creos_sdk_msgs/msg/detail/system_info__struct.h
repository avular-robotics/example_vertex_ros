// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:msg/SystemInfo.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_H_
#define CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'name'
// Member 'hostname'
// Member 'serial'
// Member 'platform'
#include "rosidl_runtime_c/string.h"
// Member 'component_versions'
#include "creos_sdk_msgs/msg/detail/component_version__struct.h"

/// Struct defined in msg/SystemInfo in the package creos_sdk_msgs.
/**
  * Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
  * You may use this code under the terms of the Avular
  * Software End-User License Agreement.
  *
  * You should have received a copy of the Avular
  * Software End-User License Agreement license with
  * this file, or download it from: avular.com/eula
 */
typedef struct creos_sdk_msgs__msg__SystemInfo
{
  /// The name of the Robot
  rosidl_runtime_c__String name;
  /// The hostname of the robot
  rosidl_runtime_c__String hostname;
  /// The serial number number of the robot
  rosidl_runtime_c__String serial;
  /// The platform of the robot
  rosidl_runtime_c__String platform;
  /// List of version components and their version
  creos_sdk_msgs__msg__ComponentVersion__Sequence component_versions;
} creos_sdk_msgs__msg__SystemInfo;

// Struct for a sequence of creos_sdk_msgs__msg__SystemInfo.
typedef struct creos_sdk_msgs__msg__SystemInfo__Sequence
{
  creos_sdk_msgs__msg__SystemInfo * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__msg__SystemInfo__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__SYSTEM_INFO__STRUCT_H_
