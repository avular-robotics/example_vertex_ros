// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:msg/ComponentVersion.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__STRUCT_H_
#define CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNKNOWN_TYPE'.
/**
  * The component version is a message that contains version information about a component in the system.
  * The type of the component can be one of the following:
 */
enum
{
  creos_sdk_msgs__msg__ComponentVersion__UNKNOWN_TYPE = 0
};

/// Constant 'OS'.
enum
{
  creos_sdk_msgs__msg__ComponentVersion__OS = 1
};

/// Constant 'CONTAINER'.
enum
{
  creos_sdk_msgs__msg__ComponentVersion__CONTAINER = 2
};

// Include directives for member types
// Member 'name'
// Member 'version'
#include "rosidl_runtime_c/string.h"

/// Struct defined in msg/ComponentVersion in the package creos_sdk_msgs.
/**
  * Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
  * You may use this code under the terms of the Avular
  * Software End-User License Agreement.
  *
  * You should have received a copy of the Avular
  * Software End-User License Agreement license with
  * this file, or download it from: avular.com/eula
 */
typedef struct creos_sdk_msgs__msg__ComponentVersion
{
  /// The Name of the component
  rosidl_runtime_c__String name;
  /// The version of the component
  rosidl_runtime_c__String version;
  /// The type of the component
  uint8_t type;
} creos_sdk_msgs__msg__ComponentVersion;

// Struct for a sequence of creos_sdk_msgs__msg__ComponentVersion.
typedef struct creos_sdk_msgs__msg__ComponentVersion__Sequence
{
  creos_sdk_msgs__msg__ComponentVersion * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__msg__ComponentVersion__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__STRUCT_H_
