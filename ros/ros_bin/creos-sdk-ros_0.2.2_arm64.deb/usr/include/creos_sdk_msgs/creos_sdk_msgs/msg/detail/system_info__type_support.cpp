// generated from rosidl_typesupport_introspection_cpp/resource/idl__type_support.cpp.em
// with input from creos_sdk_msgs:msg/SystemInfo.idl
// generated code does not contain a copyright notice

#include "array"
#include "cstddef"
#include "string"
#include "vector"
#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_cpp/message_type_support.hpp"
#include "rosidl_typesupport_interface/macros.h"
#include "creos_sdk_msgs/msg/detail/system_info__struct.hpp"
#include "rosidl_typesupport_introspection_cpp/field_types.hpp"
#include "rosidl_typesupport_introspection_cpp/identifier.hpp"
#include "rosidl_typesupport_introspection_cpp/message_introspection.hpp"
#include "rosidl_typesupport_introspection_cpp/message_type_support_decl.hpp"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

namespace creos_sdk_msgs
{

namespace msg
{

namespace rosidl_typesupport_introspection_cpp
{

void SystemInfo_init_function(
  void * message_memory, rosidl_runtime_cpp::MessageInitialization _init)
{
  new (message_memory) creos_sdk_msgs::msg::SystemInfo(_init);
}

void SystemInfo_fini_function(void * message_memory)
{
  auto typed_message = static_cast<creos_sdk_msgs::msg::SystemInfo *>(message_memory);
  typed_message->~SystemInfo();
}

size_t size_function__SystemInfo__component_versions(const void * untyped_member)
{
  const auto * member = reinterpret_cast<const std::vector<creos_sdk_msgs::msg::ComponentVersion> *>(untyped_member);
  return member->size();
}

const void * get_const_function__SystemInfo__component_versions(const void * untyped_member, size_t index)
{
  const auto & member =
    *reinterpret_cast<const std::vector<creos_sdk_msgs::msg::ComponentVersion> *>(untyped_member);
  return &member[index];
}

void * get_function__SystemInfo__component_versions(void * untyped_member, size_t index)
{
  auto & member =
    *reinterpret_cast<std::vector<creos_sdk_msgs::msg::ComponentVersion> *>(untyped_member);
  return &member[index];
}

void fetch_function__SystemInfo__component_versions(
  const void * untyped_member, size_t index, void * untyped_value)
{
  const auto & item = *reinterpret_cast<const creos_sdk_msgs::msg::ComponentVersion *>(
    get_const_function__SystemInfo__component_versions(untyped_member, index));
  auto & value = *reinterpret_cast<creos_sdk_msgs::msg::ComponentVersion *>(untyped_value);
  value = item;
}

void assign_function__SystemInfo__component_versions(
  void * untyped_member, size_t index, const void * untyped_value)
{
  auto & item = *reinterpret_cast<creos_sdk_msgs::msg::ComponentVersion *>(
    get_function__SystemInfo__component_versions(untyped_member, index));
  const auto & value = *reinterpret_cast<const creos_sdk_msgs::msg::ComponentVersion *>(untyped_value);
  item = value;
}

void resize_function__SystemInfo__component_versions(void * untyped_member, size_t size)
{
  auto * member =
    reinterpret_cast<std::vector<creos_sdk_msgs::msg::ComponentVersion> *>(untyped_member);
  member->resize(size);
}

static const ::rosidl_typesupport_introspection_cpp::MessageMember SystemInfo_message_member_array[5] = {
  {
    "name",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(creos_sdk_msgs::msg::SystemInfo, name),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "hostname",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(creos_sdk_msgs::msg::SystemInfo, hostname),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "serial",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(creos_sdk_msgs::msg::SystemInfo, serial),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "platform",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_STRING,  // type
    0,  // upper bound of string
    nullptr,  // members of sub message
    false,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(creos_sdk_msgs::msg::SystemInfo, platform),  // bytes offset in struct
    nullptr,  // default value
    nullptr,  // size() function pointer
    nullptr,  // get_const(index) function pointer
    nullptr,  // get(index) function pointer
    nullptr,  // fetch(index, &value) function pointer
    nullptr,  // assign(index, value) function pointer
    nullptr  // resize(index) function pointer
  },
  {
    "component_versions",  // name
    ::rosidl_typesupport_introspection_cpp::ROS_TYPE_MESSAGE,  // type
    0,  // upper bound of string
    ::rosidl_typesupport_introspection_cpp::get_message_type_support_handle<creos_sdk_msgs::msg::ComponentVersion>(),  // members of sub message
    true,  // is array
    0,  // array size
    false,  // is upper bound
    offsetof(creos_sdk_msgs::msg::SystemInfo, component_versions),  // bytes offset in struct
    nullptr,  // default value
    size_function__SystemInfo__component_versions,  // size() function pointer
    get_const_function__SystemInfo__component_versions,  // get_const(index) function pointer
    get_function__SystemInfo__component_versions,  // get(index) function pointer
    fetch_function__SystemInfo__component_versions,  // fetch(index, &value) function pointer
    assign_function__SystemInfo__component_versions,  // assign(index, value) function pointer
    resize_function__SystemInfo__component_versions  // resize(index) function pointer
  }
};

static const ::rosidl_typesupport_introspection_cpp::MessageMembers SystemInfo_message_members = {
  "creos_sdk_msgs::msg",  // message namespace
  "SystemInfo",  // message name
  5,  // number of fields
  sizeof(creos_sdk_msgs::msg::SystemInfo),
  SystemInfo_message_member_array,  // message members
  SystemInfo_init_function,  // function to initialize message memory (memory has to be allocated)
  SystemInfo_fini_function  // function to terminate message instance (will not free memory)
};

static const rosidl_message_type_support_t SystemInfo_message_type_support_handle = {
  ::rosidl_typesupport_introspection_cpp::typesupport_identifier,
  &SystemInfo_message_members,
  get_message_typesupport_handle_function,
};

}  // namespace rosidl_typesupport_introspection_cpp

}  // namespace msg

}  // namespace creos_sdk_msgs


namespace rosidl_typesupport_introspection_cpp
{

template<>
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
get_message_type_support_handle<creos_sdk_msgs::msg::SystemInfo>()
{
  return &::creos_sdk_msgs::msg::rosidl_typesupport_introspection_cpp::SystemInfo_message_type_support_handle;
}

}  // namespace rosidl_typesupport_introspection_cpp

#ifdef __cplusplus
extern "C"
{
#endif

ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, creos_sdk_msgs, msg, SystemInfo)() {
  return &::creos_sdk_msgs::msg::rosidl_typesupport_introspection_cpp::SystemInfo_message_type_support_handle;
}

#ifdef __cplusplus
}
#endif
