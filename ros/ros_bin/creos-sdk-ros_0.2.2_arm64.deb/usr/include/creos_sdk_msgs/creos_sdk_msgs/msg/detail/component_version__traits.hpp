// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from creos_sdk_msgs:msg/ComponentVersion.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__TRAITS_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "creos_sdk_msgs/msg/detail/component_version__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace creos_sdk_msgs
{

namespace msg
{

inline void to_flow_style_yaml(
  const ComponentVersion & msg,
  std::ostream & out)
{
  out << "{";
  // member: name
  {
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << ", ";
  }

  // member: version
  {
    out << "version: ";
    rosidl_generator_traits::value_to_yaml(msg.version, out);
    out << ", ";
  }

  // member: type
  {
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const ComponentVersion & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: name
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "name: ";
    rosidl_generator_traits::value_to_yaml(msg.name, out);
    out << "\n";
  }

  // member: version
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "version: ";
    rosidl_generator_traits::value_to_yaml(msg.version, out);
    out << "\n";
  }

  // member: type
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "type: ";
    rosidl_generator_traits::value_to_yaml(msg.type, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const ComponentVersion & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace msg

}  // namespace creos_sdk_msgs

namespace rosidl_generator_traits
{

[[deprecated("use creos_sdk_msgs::msg::to_block_style_yaml() instead")]]
inline void to_yaml(
  const creos_sdk_msgs::msg::ComponentVersion & msg,
  std::ostream & out, size_t indentation = 0)
{
  creos_sdk_msgs::msg::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use creos_sdk_msgs::msg::to_yaml() instead")]]
inline std::string to_yaml(const creos_sdk_msgs::msg::ComponentVersion & msg)
{
  return creos_sdk_msgs::msg::to_yaml(msg);
}

template<>
inline const char * data_type<creos_sdk_msgs::msg::ComponentVersion>()
{
  return "creos_sdk_msgs::msg::ComponentVersion";
}

template<>
inline const char * name<creos_sdk_msgs::msg::ComponentVersion>()
{
  return "creos_sdk_msgs/msg/ComponentVersion";
}

template<>
struct has_fixed_size<creos_sdk_msgs::msg::ComponentVersion>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<creos_sdk_msgs::msg::ComponentVersion>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<creos_sdk_msgs::msg::ComponentVersion>
  : std::true_type {};

}  // namespace rosidl_generator_traits

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__TRAITS_HPP_
