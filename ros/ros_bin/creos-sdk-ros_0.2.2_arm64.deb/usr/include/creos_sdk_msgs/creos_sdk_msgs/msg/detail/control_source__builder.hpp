// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from creos_sdk_msgs:msg/ControlSource.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__BUILDER_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "creos_sdk_msgs/msg/detail/control_source__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace creos_sdk_msgs
{

namespace msg
{

namespace builder
{

class Init_ControlSource_source
{
public:
  Init_ControlSource_source()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  ::creos_sdk_msgs::msg::ControlSource source(::creos_sdk_msgs::msg::ControlSource::_source_type arg)
  {
    msg_.source = std::move(arg);
    return std::move(msg_);
  }

private:
  ::creos_sdk_msgs::msg::ControlSource msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::msg::ControlSource>()
{
  return creos_sdk_msgs::msg::builder::Init_ControlSource_source();
}

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__BUILDER_HPP_
