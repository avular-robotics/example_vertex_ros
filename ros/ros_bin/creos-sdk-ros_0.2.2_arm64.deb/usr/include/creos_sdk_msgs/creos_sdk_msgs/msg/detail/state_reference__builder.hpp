// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from creos_sdk_msgs:msg/StateReference.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__STATE_REFERENCE__BUILDER_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__STATE_REFERENCE__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "creos_sdk_msgs/msg/detail/state_reference__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace creos_sdk_msgs
{

namespace msg
{

namespace builder
{

class Init_StateReference_orientation_mode
{
public:
  explicit Init_StateReference_orientation_mode(::creos_sdk_msgs::msg::StateReference & msg)
  : msg_(msg)
  {}
  ::creos_sdk_msgs::msg::StateReference orientation_mode(::creos_sdk_msgs::msg::StateReference::_orientation_mode_type arg)
  {
    msg_.orientation_mode = std::move(arg);
    return std::move(msg_);
  }

private:
  ::creos_sdk_msgs::msg::StateReference msg_;
};

class Init_StateReference_translation_mode
{
public:
  explicit Init_StateReference_translation_mode(::creos_sdk_msgs::msg::StateReference & msg)
  : msg_(msg)
  {}
  Init_StateReference_orientation_mode translation_mode(::creos_sdk_msgs::msg::StateReference::_translation_mode_type arg)
  {
    msg_.translation_mode = std::move(arg);
    return Init_StateReference_orientation_mode(msg_);
  }

private:
  ::creos_sdk_msgs::msg::StateReference msg_;
};

class Init_StateReference_accel
{
public:
  explicit Init_StateReference_accel(::creos_sdk_msgs::msg::StateReference & msg)
  : msg_(msg)
  {}
  Init_StateReference_translation_mode accel(::creos_sdk_msgs::msg::StateReference::_accel_type arg)
  {
    msg_.accel = std::move(arg);
    return Init_StateReference_translation_mode(msg_);
  }

private:
  ::creos_sdk_msgs::msg::StateReference msg_;
};

class Init_StateReference_twist
{
public:
  explicit Init_StateReference_twist(::creos_sdk_msgs::msg::StateReference & msg)
  : msg_(msg)
  {}
  Init_StateReference_accel twist(::creos_sdk_msgs::msg::StateReference::_twist_type arg)
  {
    msg_.twist = std::move(arg);
    return Init_StateReference_accel(msg_);
  }

private:
  ::creos_sdk_msgs::msg::StateReference msg_;
};

class Init_StateReference_pose
{
public:
  explicit Init_StateReference_pose(::creos_sdk_msgs::msg::StateReference & msg)
  : msg_(msg)
  {}
  Init_StateReference_twist pose(::creos_sdk_msgs::msg::StateReference::_pose_type arg)
  {
    msg_.pose = std::move(arg);
    return Init_StateReference_twist(msg_);
  }

private:
  ::creos_sdk_msgs::msg::StateReference msg_;
};

class Init_StateReference_header
{
public:
  Init_StateReference_header()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_StateReference_pose header(::creos_sdk_msgs::msg::StateReference::_header_type arg)
  {
    msg_.header = std::move(arg);
    return Init_StateReference_pose(msg_);
  }

private:
  ::creos_sdk_msgs::msg::StateReference msg_;
};

}  // namespace builder

}  // namespace msg

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::msg::StateReference>()
{
  return creos_sdk_msgs::msg::builder::Init_StateReference_header();
}

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__STATE_REFERENCE__BUILDER_HPP_
