// generated from rosidl_generator_c/resource/idl.h.em
// with input from creos_sdk_msgs:msg/StateReference.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__STATE_REFERENCE_H_
#define CREOS_SDK_MSGS__MSG__STATE_REFERENCE_H_

#include "creos_sdk_msgs/msg/detail/state_reference__struct.h"
#include "creos_sdk_msgs/msg/detail/state_reference__functions.h"
#include "creos_sdk_msgs/msg/detail/state_reference__type_support.h"

#endif  // CREOS_SDK_MSGS__MSG__STATE_REFERENCE_H_
