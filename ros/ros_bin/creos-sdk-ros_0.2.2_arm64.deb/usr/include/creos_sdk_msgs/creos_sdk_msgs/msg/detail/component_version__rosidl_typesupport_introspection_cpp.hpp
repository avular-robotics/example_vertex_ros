// generated from rosidl_typesupport_introspection_cpp/resource/idl__rosidl_typesupport_introspection_cpp.h.em
// with input from creos_sdk_msgs:msg/ComponentVersion.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
#define CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_


#include "rosidl_runtime_c/message_type_support_struct.h"
#include "rosidl_typesupport_interface/macros.h"
#include "rosidl_typesupport_introspection_cpp/visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

// TODO(dirk-thomas) these visibility macros should be message package specific
ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_PUBLIC
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(rosidl_typesupport_introspection_cpp, creos_sdk_msgs, msg, ComponentVersion)();

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__COMPONENT_VERSION__ROSIDL_TYPESUPPORT_INTROSPECTION_CPP_HPP_
