// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:msg/ControlSource.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__STRUCT_H_
#define CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Constant 'UNKNOWN'.
/**
  * The control source message containing the control source of the system
  * The control source can be one of the following:
  * The control source is unknown, may be an error
 */
enum
{
  creos_sdk_msgs__msg__ControlSource__UNKNOWN = -1
};

/// Constant 'DISABLED'.
/**
  * The robot is not controlled
 */
enum
{
  creos_sdk_msgs__msg__ControlSource__DISABLED = 0
};

/// Constant 'MANUAL'.
/**
  * The robot is controlled with a remote control
 */
enum
{
  creos_sdk_msgs__msg__ControlSource__MANUAL = 1
};

/// Constant 'AUTONOMOUS'.
/**
  * The robot is controlled autonomously
 */
enum
{
  creos_sdk_msgs__msg__ControlSource__AUTONOMOUS = 2
};

/// Constant 'USER'.
/**
  * The robot is controlled by the user API
 */
enum
{
  creos_sdk_msgs__msg__ControlSource__USER = 3
};

/// Struct defined in msg/ControlSource in the package creos_sdk_msgs.
/**
  * Copyright (C) 2024 Avular Holding B.V. - All Rights Reserved
  * You may use this code under the terms of the Avular
  * Software End-User License Agreement.
  *
  * You should have received a copy of the Avular
  * Software End-User License Agreement license with
  * this file, or download it from: avular.com/eula
 */
typedef struct creos_sdk_msgs__msg__ControlSource
{
  /// The current control source of the system
  int8_t source;
} creos_sdk_msgs__msg__ControlSource;

// Struct for a sequence of creos_sdk_msgs__msg__ControlSource.
typedef struct creos_sdk_msgs__msg__ControlSource__Sequence
{
  creos_sdk_msgs__msg__ControlSource * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__msg__ControlSource__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__MSG__DETAIL__CONTROL_SOURCE__STRUCT_H_
