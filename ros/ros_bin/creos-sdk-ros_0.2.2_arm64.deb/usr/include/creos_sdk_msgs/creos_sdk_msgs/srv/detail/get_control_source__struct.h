// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:srv/GetControlSource.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__DETAIL__GET_CONTROL_SOURCE__STRUCT_H_
#define CREOS_SDK_MSGS__SRV__DETAIL__GET_CONTROL_SOURCE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/GetControlSource in the package creos_sdk_msgs.
typedef struct creos_sdk_msgs__srv__GetControlSource_Request
{
  uint8_t structure_needs_at_least_one_member;
} creos_sdk_msgs__srv__GetControlSource_Request;

// Struct for a sequence of creos_sdk_msgs__srv__GetControlSource_Request.
typedef struct creos_sdk_msgs__srv__GetControlSource_Request__Sequence
{
  creos_sdk_msgs__srv__GetControlSource_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__srv__GetControlSource_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/GetControlSource in the package creos_sdk_msgs.
typedef struct creos_sdk_msgs__srv__GetControlSource_Response
{
  /// The current control source of the system, as defined in the ControlSource message
  int8_t source;
  /// informational, e.g. for error messages
  rosidl_runtime_c__String message;
} creos_sdk_msgs__srv__GetControlSource_Response;

// Struct for a sequence of creos_sdk_msgs__srv__GetControlSource_Response.
typedef struct creos_sdk_msgs__srv__GetControlSource_Response__Sequence
{
  creos_sdk_msgs__srv__GetControlSource_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__srv__GetControlSource_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__SRV__DETAIL__GET_CONTROL_SOURCE__STRUCT_H_
