// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from creos_sdk_msgs:srv/GetBatteryStatus.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__DETAIL__GET_BATTERY_STATUS__BUILDER_HPP_
#define CREOS_SDK_MSGS__SRV__DETAIL__GET_BATTERY_STATUS__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "creos_sdk_msgs/srv/detail/get_battery_status__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace creos_sdk_msgs
{

namespace srv
{


}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::srv::GetBatteryStatus_Request>()
{
  return ::creos_sdk_msgs::srv::GetBatteryStatus_Request(rosidl_runtime_cpp::MessageInitialization::ZERO);
}

}  // namespace creos_sdk_msgs


namespace creos_sdk_msgs
{

namespace srv
{

namespace builder
{

class Init_GetBatteryStatus_Response_status
{
public:
  explicit Init_GetBatteryStatus_Response_status(::creos_sdk_msgs::srv::GetBatteryStatus_Response & msg)
  : msg_(msg)
  {}
  ::creos_sdk_msgs::srv::GetBatteryStatus_Response status(::creos_sdk_msgs::srv::GetBatteryStatus_Response::_status_type arg)
  {
    msg_.status = std::move(arg);
    return std::move(msg_);
  }

private:
  ::creos_sdk_msgs::srv::GetBatteryStatus_Response msg_;
};

class Init_GetBatteryStatus_Response_message
{
public:
  explicit Init_GetBatteryStatus_Response_message(::creos_sdk_msgs::srv::GetBatteryStatus_Response & msg)
  : msg_(msg)
  {}
  Init_GetBatteryStatus_Response_status message(::creos_sdk_msgs::srv::GetBatteryStatus_Response::_message_type arg)
  {
    msg_.message = std::move(arg);
    return Init_GetBatteryStatus_Response_status(msg_);
  }

private:
  ::creos_sdk_msgs::srv::GetBatteryStatus_Response msg_;
};

class Init_GetBatteryStatus_Response_success
{
public:
  Init_GetBatteryStatus_Response_success()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_GetBatteryStatus_Response_message success(::creos_sdk_msgs::srv::GetBatteryStatus_Response::_success_type arg)
  {
    msg_.success = std::move(arg);
    return Init_GetBatteryStatus_Response_message(msg_);
  }

private:
  ::creos_sdk_msgs::srv::GetBatteryStatus_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::creos_sdk_msgs::srv::GetBatteryStatus_Response>()
{
  return creos_sdk_msgs::srv::builder::Init_GetBatteryStatus_Response_success();
}

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__SRV__DETAIL__GET_BATTERY_STATUS__BUILDER_HPP_
