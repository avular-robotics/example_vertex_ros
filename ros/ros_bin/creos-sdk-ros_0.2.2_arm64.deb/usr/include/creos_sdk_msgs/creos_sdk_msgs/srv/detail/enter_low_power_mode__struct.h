// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:srv/EnterLowPowerMode.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_H_
#define CREOS_SDK_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'wake_up_time'
#include "builtin_interfaces/msg/detail/time__struct.h"

/// Struct defined in srv/EnterLowPowerMode in the package creos_sdk_msgs.
typedef struct creos_sdk_msgs__srv__EnterLowPowerMode_Request
{
  /// Request to enter low power mode
  /// Time to wake up at, in seconds since epoch in UTC time. If wake_up_time is 0, then
  /// we will sleep until exit_low_power_mode is called or the robot is woken by event.
  builtin_interfaces__msg__Time wake_up_time;
} creos_sdk_msgs__srv__EnterLowPowerMode_Request;

// Struct for a sequence of creos_sdk_msgs__srv__EnterLowPowerMode_Request.
typedef struct creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence
{
  creos_sdk_msgs__srv__EnterLowPowerMode_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"

/// Struct defined in srv/EnterLowPowerMode in the package creos_sdk_msgs.
typedef struct creos_sdk_msgs__srv__EnterLowPowerMode_Response
{
  /// indicate successful run of triggered service
  bool success;
  /// informational, e.g. for error messages
  rosidl_runtime_c__String message;
} creos_sdk_msgs__srv__EnterLowPowerMode_Response;

// Struct for a sequence of creos_sdk_msgs__srv__EnterLowPowerMode_Response.
typedef struct creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence
{
  creos_sdk_msgs__srv__EnterLowPowerMode_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__STRUCT_H_
