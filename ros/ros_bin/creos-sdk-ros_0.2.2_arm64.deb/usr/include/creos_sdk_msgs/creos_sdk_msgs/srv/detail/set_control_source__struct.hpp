// generated from rosidl_generator_cpp/resource/idl__struct.hpp.em
// with input from creos_sdk_msgs:srv/SetControlSource.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__DETAIL__SET_CONTROL_SOURCE__STRUCT_HPP_
#define CREOS_SDK_MSGS__SRV__DETAIL__SET_CONTROL_SOURCE__STRUCT_HPP_

#include <algorithm>
#include <array>
#include <memory>
#include <string>
#include <vector>

#include "rosidl_runtime_cpp/bounded_vector.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


#ifndef _WIN32
# define DEPRECATED__creos_sdk_msgs__srv__SetControlSource_Request __attribute__((deprecated))
#else
# define DEPRECATED__creos_sdk_msgs__srv__SetControlSource_Request __declspec(deprecated)
#endif

namespace creos_sdk_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetControlSource_Request_
{
  using Type = SetControlSource_Request_<ContainerAllocator>;

  explicit SetControlSource_Request_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->source = 0;
    }
  }

  explicit SetControlSource_Request_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    (void)_alloc;
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->source = 0;
    }
  }

  // field types and members
  using _source_type =
    int8_t;
  _source_type source;

  // setters for named parameter idiom
  Type & set__source(
    const int8_t & _arg)
  {
    this->source = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator> *;
  using ConstRawPtr =
    const creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__creos_sdk_msgs__srv__SetControlSource_Request
    std::shared_ptr<creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__creos_sdk_msgs__srv__SetControlSource_Request
    std::shared_ptr<creos_sdk_msgs::srv::SetControlSource_Request_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetControlSource_Request_ & other) const
  {
    if (this->source != other.source) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetControlSource_Request_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetControlSource_Request_

// alias to use template instance with default allocator
using SetControlSource_Request =
  creos_sdk_msgs::srv::SetControlSource_Request_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace creos_sdk_msgs


#ifndef _WIN32
# define DEPRECATED__creos_sdk_msgs__srv__SetControlSource_Response __attribute__((deprecated))
#else
# define DEPRECATED__creos_sdk_msgs__srv__SetControlSource_Response __declspec(deprecated)
#endif

namespace creos_sdk_msgs
{

namespace srv
{

// message struct
template<class ContainerAllocator>
struct SetControlSource_Response_
{
  using Type = SetControlSource_Response_<ContainerAllocator>;

  explicit SetControlSource_Response_(rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  explicit SetControlSource_Response_(const ContainerAllocator & _alloc, rosidl_runtime_cpp::MessageInitialization _init = rosidl_runtime_cpp::MessageInitialization::ALL)
  : message(_alloc)
  {
    if (rosidl_runtime_cpp::MessageInitialization::ALL == _init ||
      rosidl_runtime_cpp::MessageInitialization::ZERO == _init)
    {
      this->success = false;
      this->message = "";
    }
  }

  // field types and members
  using _success_type =
    bool;
  _success_type success;
  using _message_type =
    std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>>;
  _message_type message;

  // setters for named parameter idiom
  Type & set__success(
    const bool & _arg)
  {
    this->success = _arg;
    return *this;
  }
  Type & set__message(
    const std::basic_string<char, std::char_traits<char>, typename std::allocator_traits<ContainerAllocator>::template rebind_alloc<char>> & _arg)
  {
    this->message = _arg;
    return *this;
  }

  // constant declarations

  // pointer types
  using RawPtr =
    creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator> *;
  using ConstRawPtr =
    const creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator> *;
  using SharedPtr =
    std::shared_ptr<creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator>>;
  using ConstSharedPtr =
    std::shared_ptr<creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator> const>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator>>>
  using UniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator>, Deleter>;

  using UniquePtr = UniquePtrWithDeleter<>;

  template<typename Deleter = std::default_delete<
      creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator>>>
  using ConstUniquePtrWithDeleter =
    std::unique_ptr<creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator> const, Deleter>;
  using ConstUniquePtr = ConstUniquePtrWithDeleter<>;

  using WeakPtr =
    std::weak_ptr<creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator>>;
  using ConstWeakPtr =
    std::weak_ptr<creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator> const>;

  // pointer types similar to ROS 1, use SharedPtr / ConstSharedPtr instead
  // NOTE: Can't use 'using' here because GNU C++ can't parse attributes properly
  typedef DEPRECATED__creos_sdk_msgs__srv__SetControlSource_Response
    std::shared_ptr<creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator>>
    Ptr;
  typedef DEPRECATED__creos_sdk_msgs__srv__SetControlSource_Response
    std::shared_ptr<creos_sdk_msgs::srv::SetControlSource_Response_<ContainerAllocator> const>
    ConstPtr;

  // comparison operators
  bool operator==(const SetControlSource_Response_ & other) const
  {
    if (this->success != other.success) {
      return false;
    }
    if (this->message != other.message) {
      return false;
    }
    return true;
  }
  bool operator!=(const SetControlSource_Response_ & other) const
  {
    return !this->operator==(other);
  }
};  // struct SetControlSource_Response_

// alias to use template instance with default allocator
using SetControlSource_Response =
  creos_sdk_msgs::srv::SetControlSource_Response_<std::allocator<void>>;

// constant definitions

}  // namespace srv

}  // namespace creos_sdk_msgs

namespace creos_sdk_msgs
{

namespace srv
{

struct SetControlSource
{
  using Request = creos_sdk_msgs::srv::SetControlSource_Request;
  using Response = creos_sdk_msgs::srv::SetControlSource_Response;
};

}  // namespace srv

}  // namespace creos_sdk_msgs

#endif  // CREOS_SDK_MSGS__SRV__DETAIL__SET_CONTROL_SOURCE__STRUCT_HPP_
