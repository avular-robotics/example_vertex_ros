// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from creos_sdk_msgs:srv/GetState.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__DETAIL__GET_STATE__STRUCT_H_
#define CREOS_SDK_MSGS__SRV__DETAIL__GET_STATE__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

/// Struct defined in srv/GetState in the package creos_sdk_msgs.
typedef struct creos_sdk_msgs__srv__GetState_Request
{
  uint8_t structure_needs_at_least_one_member;
} creos_sdk_msgs__srv__GetState_Request;

// Struct for a sequence of creos_sdk_msgs__srv__GetState_Request.
typedef struct creos_sdk_msgs__srv__GetState_Request__Sequence
{
  creos_sdk_msgs__srv__GetState_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__srv__GetState_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'message'
#include "rosidl_runtime_c/string.h"
// Member 'state'
#include "creos_sdk_msgs/msg/detail/state__struct.h"

/// Struct defined in srv/GetState in the package creos_sdk_msgs.
typedef struct creos_sdk_msgs__srv__GetState_Response
{
  /// indicate successful run of triggered service
  bool success;
  /// informational, e.g. for error messages
  rosidl_runtime_c__String message;
  /// the current state of the robot
  creos_sdk_msgs__msg__State state;
} creos_sdk_msgs__srv__GetState_Response;

// Struct for a sequence of creos_sdk_msgs__srv__GetState_Response.
typedef struct creos_sdk_msgs__srv__GetState_Response__Sequence
{
  creos_sdk_msgs__srv__GetState_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} creos_sdk_msgs__srv__GetState_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // CREOS_SDK_MSGS__SRV__DETAIL__GET_STATE__STRUCT_H_
