// generated from rosidl_generator_c/resource/idl__functions.c.em
// with input from creos_sdk_msgs:srv/EnterLowPowerMode.idl
// generated code does not contain a copyright notice
#include "creos_sdk_msgs/srv/detail/enter_low_power_mode__functions.h"

#include <assert.h>
#include <stdbool.h>
#include <stdlib.h>
#include <string.h>

#include "rcutils/allocator.h"

// Include directives for member types
// Member `wake_up_time`
#include "builtin_interfaces/msg/detail/time__functions.h"

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Request__init(creos_sdk_msgs__srv__EnterLowPowerMode_Request * msg)
{
  if (!msg) {
    return false;
  }
  // wake_up_time
  if (!builtin_interfaces__msg__Time__init(&msg->wake_up_time)) {
    creos_sdk_msgs__srv__EnterLowPowerMode_Request__fini(msg);
    return false;
  }
  return true;
}

void
creos_sdk_msgs__srv__EnterLowPowerMode_Request__fini(creos_sdk_msgs__srv__EnterLowPowerMode_Request * msg)
{
  if (!msg) {
    return;
  }
  // wake_up_time
  builtin_interfaces__msg__Time__fini(&msg->wake_up_time);
}

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Request__are_equal(const creos_sdk_msgs__srv__EnterLowPowerMode_Request * lhs, const creos_sdk_msgs__srv__EnterLowPowerMode_Request * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // wake_up_time
  if (!builtin_interfaces__msg__Time__are_equal(
      &(lhs->wake_up_time), &(rhs->wake_up_time)))
  {
    return false;
  }
  return true;
}

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Request__copy(
  const creos_sdk_msgs__srv__EnterLowPowerMode_Request * input,
  creos_sdk_msgs__srv__EnterLowPowerMode_Request * output)
{
  if (!input || !output) {
    return false;
  }
  // wake_up_time
  if (!builtin_interfaces__msg__Time__copy(
      &(input->wake_up_time), &(output->wake_up_time)))
  {
    return false;
  }
  return true;
}

creos_sdk_msgs__srv__EnterLowPowerMode_Request *
creos_sdk_msgs__srv__EnterLowPowerMode_Request__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__srv__EnterLowPowerMode_Request * msg = (creos_sdk_msgs__srv__EnterLowPowerMode_Request *)allocator.allocate(sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Request), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Request));
  bool success = creos_sdk_msgs__srv__EnterLowPowerMode_Request__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
creos_sdk_msgs__srv__EnterLowPowerMode_Request__destroy(creos_sdk_msgs__srv__EnterLowPowerMode_Request * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    creos_sdk_msgs__srv__EnterLowPowerMode_Request__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence__init(creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__srv__EnterLowPowerMode_Request * data = NULL;

  if (size) {
    data = (creos_sdk_msgs__srv__EnterLowPowerMode_Request *)allocator.zero_allocate(size, sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Request), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = creos_sdk_msgs__srv__EnterLowPowerMode_Request__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        creos_sdk_msgs__srv__EnterLowPowerMode_Request__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence__fini(creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      creos_sdk_msgs__srv__EnterLowPowerMode_Request__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence *
creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence * array = (creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence *)allocator.allocate(sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence__destroy(creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence__are_equal(const creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence * lhs, const creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!creos_sdk_msgs__srv__EnterLowPowerMode_Request__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence__copy(
  const creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence * input,
  creos_sdk_msgs__srv__EnterLowPowerMode_Request__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Request);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    creos_sdk_msgs__srv__EnterLowPowerMode_Request * data =
      (creos_sdk_msgs__srv__EnterLowPowerMode_Request *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!creos_sdk_msgs__srv__EnterLowPowerMode_Request__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          creos_sdk_msgs__srv__EnterLowPowerMode_Request__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!creos_sdk_msgs__srv__EnterLowPowerMode_Request__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}


// Include directives for member types
// Member `message`
#include "rosidl_runtime_c/string_functions.h"

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Response__init(creos_sdk_msgs__srv__EnterLowPowerMode_Response * msg)
{
  if (!msg) {
    return false;
  }
  // success
  // message
  if (!rosidl_runtime_c__String__init(&msg->message)) {
    creos_sdk_msgs__srv__EnterLowPowerMode_Response__fini(msg);
    return false;
  }
  return true;
}

void
creos_sdk_msgs__srv__EnterLowPowerMode_Response__fini(creos_sdk_msgs__srv__EnterLowPowerMode_Response * msg)
{
  if (!msg) {
    return;
  }
  // success
  // message
  rosidl_runtime_c__String__fini(&msg->message);
}

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Response__are_equal(const creos_sdk_msgs__srv__EnterLowPowerMode_Response * lhs, const creos_sdk_msgs__srv__EnterLowPowerMode_Response * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  // success
  if (lhs->success != rhs->success) {
    return false;
  }
  // message
  if (!rosidl_runtime_c__String__are_equal(
      &(lhs->message), &(rhs->message)))
  {
    return false;
  }
  return true;
}

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Response__copy(
  const creos_sdk_msgs__srv__EnterLowPowerMode_Response * input,
  creos_sdk_msgs__srv__EnterLowPowerMode_Response * output)
{
  if (!input || !output) {
    return false;
  }
  // success
  output->success = input->success;
  // message
  if (!rosidl_runtime_c__String__copy(
      &(input->message), &(output->message)))
  {
    return false;
  }
  return true;
}

creos_sdk_msgs__srv__EnterLowPowerMode_Response *
creos_sdk_msgs__srv__EnterLowPowerMode_Response__create()
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__srv__EnterLowPowerMode_Response * msg = (creos_sdk_msgs__srv__EnterLowPowerMode_Response *)allocator.allocate(sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Response), allocator.state);
  if (!msg) {
    return NULL;
  }
  memset(msg, 0, sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Response));
  bool success = creos_sdk_msgs__srv__EnterLowPowerMode_Response__init(msg);
  if (!success) {
    allocator.deallocate(msg, allocator.state);
    return NULL;
  }
  return msg;
}

void
creos_sdk_msgs__srv__EnterLowPowerMode_Response__destroy(creos_sdk_msgs__srv__EnterLowPowerMode_Response * msg)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (msg) {
    creos_sdk_msgs__srv__EnterLowPowerMode_Response__fini(msg);
  }
  allocator.deallocate(msg, allocator.state);
}


bool
creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence__init(creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence * array, size_t size)
{
  if (!array) {
    return false;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__srv__EnterLowPowerMode_Response * data = NULL;

  if (size) {
    data = (creos_sdk_msgs__srv__EnterLowPowerMode_Response *)allocator.zero_allocate(size, sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Response), allocator.state);
    if (!data) {
      return false;
    }
    // initialize all array elements
    size_t i;
    for (i = 0; i < size; ++i) {
      bool success = creos_sdk_msgs__srv__EnterLowPowerMode_Response__init(&data[i]);
      if (!success) {
        break;
      }
    }
    if (i < size) {
      // if initialization failed finalize the already initialized array elements
      for (; i > 0; --i) {
        creos_sdk_msgs__srv__EnterLowPowerMode_Response__fini(&data[i - 1]);
      }
      allocator.deallocate(data, allocator.state);
      return false;
    }
  }
  array->data = data;
  array->size = size;
  array->capacity = size;
  return true;
}

void
creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence__fini(creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence * array)
{
  if (!array) {
    return;
  }
  rcutils_allocator_t allocator = rcutils_get_default_allocator();

  if (array->data) {
    // ensure that data and capacity values are consistent
    assert(array->capacity > 0);
    // finalize all array elements
    for (size_t i = 0; i < array->capacity; ++i) {
      creos_sdk_msgs__srv__EnterLowPowerMode_Response__fini(&array->data[i]);
    }
    allocator.deallocate(array->data, allocator.state);
    array->data = NULL;
    array->size = 0;
    array->capacity = 0;
  } else {
    // ensure that data, size, and capacity values are consistent
    assert(0 == array->size);
    assert(0 == array->capacity);
  }
}

creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence *
creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence__create(size_t size)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence * array = (creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence *)allocator.allocate(sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence), allocator.state);
  if (!array) {
    return NULL;
  }
  bool success = creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence__init(array, size);
  if (!success) {
    allocator.deallocate(array, allocator.state);
    return NULL;
  }
  return array;
}

void
creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence__destroy(creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence * array)
{
  rcutils_allocator_t allocator = rcutils_get_default_allocator();
  if (array) {
    creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence__fini(array);
  }
  allocator.deallocate(array, allocator.state);
}

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence__are_equal(const creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence * lhs, const creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence * rhs)
{
  if (!lhs || !rhs) {
    return false;
  }
  if (lhs->size != rhs->size) {
    return false;
  }
  for (size_t i = 0; i < lhs->size; ++i) {
    if (!creos_sdk_msgs__srv__EnterLowPowerMode_Response__are_equal(&(lhs->data[i]), &(rhs->data[i]))) {
      return false;
    }
  }
  return true;
}

bool
creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence__copy(
  const creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence * input,
  creos_sdk_msgs__srv__EnterLowPowerMode_Response__Sequence * output)
{
  if (!input || !output) {
    return false;
  }
  if (output->capacity < input->size) {
    const size_t allocation_size =
      input->size * sizeof(creos_sdk_msgs__srv__EnterLowPowerMode_Response);
    rcutils_allocator_t allocator = rcutils_get_default_allocator();
    creos_sdk_msgs__srv__EnterLowPowerMode_Response * data =
      (creos_sdk_msgs__srv__EnterLowPowerMode_Response *)allocator.reallocate(
      output->data, allocation_size, allocator.state);
    if (!data) {
      return false;
    }
    // If reallocation succeeded, memory may or may not have been moved
    // to fulfill the allocation request, invalidating output->data.
    output->data = data;
    for (size_t i = output->capacity; i < input->size; ++i) {
      if (!creos_sdk_msgs__srv__EnterLowPowerMode_Response__init(&output->data[i])) {
        // If initialization of any new item fails, roll back
        // all previously initialized items. Existing items
        // in output are to be left unmodified.
        for (; i-- > output->capacity; ) {
          creos_sdk_msgs__srv__EnterLowPowerMode_Response__fini(&output->data[i]);
        }
        return false;
      }
    }
    output->capacity = input->size;
  }
  output->size = input->size;
  for (size_t i = 0; i < input->size; ++i) {
    if (!creos_sdk_msgs__srv__EnterLowPowerMode_Response__copy(
        &(input->data[i]), &(output->data[i])))
    {
      return false;
    }
  }
  return true;
}
