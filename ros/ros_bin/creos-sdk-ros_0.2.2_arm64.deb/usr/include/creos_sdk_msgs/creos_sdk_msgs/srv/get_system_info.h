// generated from rosidl_generator_c/resource/idl.h.em
// with input from creos_sdk_msgs:srv/GetSystemInfo.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__GET_SYSTEM_INFO_H_
#define CREOS_SDK_MSGS__SRV__GET_SYSTEM_INFO_H_

#include "creos_sdk_msgs/srv/detail/get_system_info__struct.h"
#include "creos_sdk_msgs/srv/detail/get_system_info__functions.h"
#include "creos_sdk_msgs/srv/detail/get_system_info__type_support.h"

#endif  // CREOS_SDK_MSGS__SRV__GET_SYSTEM_INFO_H_
