// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from creos_sdk_msgs:srv/EnterLowPowerMode.idl
// generated code does not contain a copyright notice

#ifndef CREOS_SDK_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__TRAITS_HPP_
#define CREOS_SDK_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "creos_sdk_msgs/srv/detail/enter_low_power_mode__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

// Include directives for member types
// Member 'wake_up_time'
#include "builtin_interfaces/msg/detail/time__traits.hpp"

namespace creos_sdk_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const EnterLowPowerMode_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: wake_up_time
  {
    out << "wake_up_time: ";
    to_flow_style_yaml(msg.wake_up_time, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EnterLowPowerMode_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: wake_up_time
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "wake_up_time:\n";
    to_block_style_yaml(msg.wake_up_time, out, indentation + 2);
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EnterLowPowerMode_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace creos_sdk_msgs

namespace rosidl_generator_traits
{

[[deprecated("use creos_sdk_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const creos_sdk_msgs::srv::EnterLowPowerMode_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  creos_sdk_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use creos_sdk_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const creos_sdk_msgs::srv::EnterLowPowerMode_Request & msg)
{
  return creos_sdk_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<creos_sdk_msgs::srv::EnterLowPowerMode_Request>()
{
  return "creos_sdk_msgs::srv::EnterLowPowerMode_Request";
}

template<>
inline const char * name<creos_sdk_msgs::srv::EnterLowPowerMode_Request>()
{
  return "creos_sdk_msgs/srv/EnterLowPowerMode_Request";
}

template<>
struct has_fixed_size<creos_sdk_msgs::srv::EnterLowPowerMode_Request>
  : std::integral_constant<bool, has_fixed_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct has_bounded_size<creos_sdk_msgs::srv::EnterLowPowerMode_Request>
  : std::integral_constant<bool, has_bounded_size<builtin_interfaces::msg::Time>::value> {};

template<>
struct is_message<creos_sdk_msgs::srv::EnterLowPowerMode_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace creos_sdk_msgs
{

namespace srv
{

inline void to_flow_style_yaml(
  const EnterLowPowerMode_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: success
  {
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << ", ";
  }

  // member: message
  {
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const EnterLowPowerMode_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: success
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "success: ";
    rosidl_generator_traits::value_to_yaml(msg.success, out);
    out << "\n";
  }

  // member: message
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "message: ";
    rosidl_generator_traits::value_to_yaml(msg.message, out);
    out << "\n";
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const EnterLowPowerMode_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace creos_sdk_msgs

namespace rosidl_generator_traits
{

[[deprecated("use creos_sdk_msgs::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const creos_sdk_msgs::srv::EnterLowPowerMode_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  creos_sdk_msgs::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use creos_sdk_msgs::srv::to_yaml() instead")]]
inline std::string to_yaml(const creos_sdk_msgs::srv::EnterLowPowerMode_Response & msg)
{
  return creos_sdk_msgs::srv::to_yaml(msg);
}

template<>
inline const char * data_type<creos_sdk_msgs::srv::EnterLowPowerMode_Response>()
{
  return "creos_sdk_msgs::srv::EnterLowPowerMode_Response";
}

template<>
inline const char * name<creos_sdk_msgs::srv::EnterLowPowerMode_Response>()
{
  return "creos_sdk_msgs/srv/EnterLowPowerMode_Response";
}

template<>
struct has_fixed_size<creos_sdk_msgs::srv::EnterLowPowerMode_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<creos_sdk_msgs::srv::EnterLowPowerMode_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<creos_sdk_msgs::srv::EnterLowPowerMode_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<creos_sdk_msgs::srv::EnterLowPowerMode>()
{
  return "creos_sdk_msgs::srv::EnterLowPowerMode";
}

template<>
inline const char * name<creos_sdk_msgs::srv::EnterLowPowerMode>()
{
  return "creos_sdk_msgs/srv/EnterLowPowerMode";
}

template<>
struct has_fixed_size<creos_sdk_msgs::srv::EnterLowPowerMode>
  : std::integral_constant<
    bool,
    has_fixed_size<creos_sdk_msgs::srv::EnterLowPowerMode_Request>::value &&
    has_fixed_size<creos_sdk_msgs::srv::EnterLowPowerMode_Response>::value
  >
{
};

template<>
struct has_bounded_size<creos_sdk_msgs::srv::EnterLowPowerMode>
  : std::integral_constant<
    bool,
    has_bounded_size<creos_sdk_msgs::srv::EnterLowPowerMode_Request>::value &&
    has_bounded_size<creos_sdk_msgs::srv::EnterLowPowerMode_Response>::value
  >
{
};

template<>
struct is_service<creos_sdk_msgs::srv::EnterLowPowerMode>
  : std::true_type
{
};

template<>
struct is_service_request<creos_sdk_msgs::srv::EnterLowPowerMode_Request>
  : std::true_type
{
};

template<>
struct is_service_response<creos_sdk_msgs::srv::EnterLowPowerMode_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // CREOS_SDK_MSGS__SRV__DETAIL__ENTER_LOW_POWER_MODE__TRAITS_HPP_
